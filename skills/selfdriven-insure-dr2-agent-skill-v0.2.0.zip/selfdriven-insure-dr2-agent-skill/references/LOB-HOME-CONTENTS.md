# Line module — Home & Contents (AU)

## Canonical units
Subject = dwelling, location, household exposure profile and optionally individual contents item, with insured/owner role. Model `building` and `contents` separately with a shared property/event graph. Exposure normally a one-year policy period, but record precise days and occupancy changes.

## COPE mapping
- **Construction:** walls, roof, age, materials, floors, refurbishment, roof maintenance, rebuild cost, elevation where relevant.
- **Occupancy:** owner-occupied/tenanted/holiday/unoccupied, use, non-domestic activity; do not infer behaviour from demographics.
- **Protection:** smoke alarms, detectors, extinguishers, security, flood barrier, escape-of-water isolation, maintenance records.
- **Exposure:** flood and bushfire hazard, storm/wind, external fire, nearby structures, local theft exposure, catastrophe accumulation.

## Initial coverage/peril matrix
| Coverage | Peril/event | Primary severity basis | Potential dependencies |
|---|---|---|---|
| Building | fire/bushfire | repair/rebuild and permitted additional costs | location, construction, hazard, fire response |
| Building | flood/storm | damage and reinstatement under policy definition | terrain, floor height, roof, event hazard |
| Building | escape of water | repair, restoration, temporary accommodation where covered | plumbing and shutoff controls |
| Contents | theft | covered replacement/indemnity of contents | locks, occupancy, item limits |
| Contents | fire/flood/storm | covered personal property damage | common event with building loss |
| Additional accommodation | insured physical-damage trigger | cost/duration subject to contract terms | building repair duration |

Do not infer policy flood coverage solely from physical flood hazard. Model accidental damage and valuables only when product terms permit.

## Feature and evidence candidates
Geocoded hazard dataset version (not guessed), rebuild valuation, inspection records, alarm test certification, water sensor operating records, roof inspection, property maintenance dates. Separate declarations from certified observations. Sensitive contents inventories should be minimised.

## Risk improvement candidates
Smoke-alarm maintenance affects relevant fire impacts only if calibrated; verified water shut-off can affect escape-of-water severity; roof strengthening can affect storm vulnerability. Avoid universal 'security score' discounts.

## Test scenarios
1. Same COPE, alarm working vs only declared → same inherent risk, differing evidence eligibility, only approved mitigation effects allowed.
2. Flood zone hazard missing → uncertainty/refer, not zero flood risk.
3. Household unoccupied mid-term → effective-time exposure segmentation; do not rewrite history.
4. Building and contents damaged by same event → one event ID, multiple cover components and no duplicate payments.
5. Excess applies at specified event or claim level, not to expected average loss.
6. Policy excludes a named peril → report physical risk separately from zero contractual covered-loss component.

## Calibration needs
Claims count and payments (incl. nil claims exposure), sums insured, property-years, geospatial event histories, inflation/trend, policy wording, reinsurance and event clustering. Track selection bias, repair cost inflation, and changes to hazard maps.
