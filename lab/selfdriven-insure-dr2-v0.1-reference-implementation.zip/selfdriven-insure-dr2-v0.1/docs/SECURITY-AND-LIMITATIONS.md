# DR² v0.1 — Security, Trust and Product Limitations

## Trust boundaries

1. **Insured declarations:** Unverified statements of protection presence; do not receive credit.
2. **Issuer identity:** Ed25519 public keys provisioned in a local trust registry. The prototype does not perform accreditation, identity proofing, custody evaluation or revocation.
3. **Issuer assertions:** Signatures authenticate that the holder of a registered key signed the payload; they do **not** prove the inspection happened or was accurate.
4. **Decision policy:** The server/operator chooses trusted issuers and methods, not the assessment caller.
5. **Models:** Fire model constants are fixed and hashed but have not been fitted to claims experience.
6. **Output:** A content hash makes changes detectable under the declared encoding, but does not itself create an append-only audit trail or signed authoritative assessment.

## Important known gaps

- No strong user or tenant authentication and no per-asset authorisation.
- Development HTTP server is for localhost only and does not terminate TLS.
- No durable storage, audit log, data retention or recovery system.
- No hardware-backed signing keys, PKI, signing-time proof or revocation checks.
- No detection of compromised-but-still-trusted inspector keys.
- No re-inspection process when genuine sources provide incorrect data.
- No externally verified geo-hazard or property identity mapping.
- No anti-replay challenge beyond evidence identity and validity dates within one assessment input.
- No claims-based actuarial validity, underwriting approvals, pricing guardrails or regulated product disclosures.
- Custom canonicalisation, pending stronger interoperable standard and test vectors.
- No comprehensive numerical stability testing for all runtimes, policies and currencies.

## Suggested pre-production controls

- Operate behind authenticated APIs and tenant-scoped authorisation.
- Enrol approved issuers using independently checked identity and inspection qualifications.
- Use protected signing keys; define revocation, rollover and compromise response.
- Keep signed and independently timestamped issuer statements and immutable assessment records.
- Have a separate human process for conflicting/appealed assessments.
- Implement ingestion-size limits, abuse controls, logging and secure request processing.
- Run privacy, cyber security, penetration testing and appropriate insurer model reviews.
- Never turn unvalidated mitigation multipliers into actual premium credits.

## Advisory

The reference is supplied as a research artifact and contains no real policy, personal or insurance customer data. The generated mock keys are deliberately ephemeral and cannot be treated as any real organisation's credential. It must not be publicly deployed or used for commercial underwriting without substantive further work.
