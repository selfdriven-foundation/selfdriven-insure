# DR² engineering task plan

## Scope
Line/product/jurisdiction, decision use, coverages/perils and policy terms.

## Inputs
Subject and COPE/context profile, evidence/trust policy, event/claims sources, insurer-authorised assumptions.

## Deliverables
Schemas, mappings, model adapters, example events, API, immutable assessment output, explanations, tests, calibration report.

## Work packages
1. Ontology & policy mapping
2. Data collection, evidence and trust registry
3. Peril model/financial terms separation
4. Contract and adversarial tests
5. Out-of-time data validation
6. Governance and shadow-pilot review

## Blocks and sign-offs
No pricing or eligibility claims without insurer and actuarial approvals. Record owners, dates and evidence.
