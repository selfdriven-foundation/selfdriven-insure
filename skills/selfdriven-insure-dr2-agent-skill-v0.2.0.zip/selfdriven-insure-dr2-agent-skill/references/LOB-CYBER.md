# Line module — Cyber

## Canonical units
Subject = legal insured entity, security boundary and connected technology estate; explicit insured business services and third-party dependencies. Exposure normally one policy period, with material state changes recorded with effective time. Keep event clusters across subsidiaries/partners/vendors.

## Cyber context profile (NOT COPE)
- Identity estate: MFA methods, privileged access, federated identity, service accounts.
- Attack surface: internet-facing services, domains, endpoints, APIs, cloud assets, suppliers.
- Asset/patch inventory; EDR and vulnerability remediation coverage; data classification.
- Network controls, backup isolation and restore verification, logging and incident response.
- Business dependency graph for cloud providers, service providers and data flows.
- Revenue and downtime sensitivity, notification and recovery expense assumptions.

## Coverages/events
| Coverage | Event | Loss components |
|---|---|---|
| First-party incident response | ransomware, breach, destructive attack | forensic, legal, recovery, notification costs |
| Cyber business interruption | insured outage or security event | covered lost income/extra expense subject to waiting period |
| Data/privacy liability | alleged covered third-party injury | defence, settlements where insurable and covered |
| Cyber extortion | covered threat | response and insured payment if lawful and covered |
| Contingent BI | covered supplier outage | dependent operation loss |
| Restoration | data/system restoration | eligible technical recovery costs |

## Causal graph
`Vulnerability/Threat × Exposure → SecurityEvent → Compromise/Disruption → BusinessServiceImpact → GrossLoss → InsuredPayment`.

Do not equate a raw vulnerability count, CVSS score, external scan, pen test finding, or lack of security certification with a validated breach probability. Control effectiveness is state- and threat-model-dependent. Event frequency and severity depend on adversarial adaptation and changing environments. Correlated incidents across cloud providers and common software components must be modelled as aggregate events.

## Trust and evidence
A claims-based MFA statement is not proof of coverage across all identities. Evidence sources may include identity-provider policy export, credential rotation, EDR reports, independent restore tests, vulnerability remediation SLA records, and incident simulations. Secrets, customer PII, logs and exploit-sensitive data must be redacted or kept in scoped encrypted stores.

## Test scenarios
1. MFA enforced for employees but not privileged service accounts → coverage gap, no blanket full-control credit.
2. Backup configured but no successful restore test → do not infer recoverability.
3. Shared SaaS outage impacts two insured services → one event, correlated covered losses.
4. CVE exposure patched yesterday vs discovery today → pin effective date and asset inventory completeness.
5. Business interruption 8h with 12h waiting period → policy formula must operate on individual loss event, not mean annual loss.
6. Ransom demand reported but no permitted covered payment → separate gross event cost from insured payable amount.
7. Vendor attestation signed by untrusted key → no verified source status.

## Calibration needs
Entity-years by size/industry/technology estate, incident event taxonomy, near misses (not conflated with claims), reported/paid losses, incurred-but-not-reported and reporting lag, containment time, downtime, shared-cause vendor exposures, changing threat landscape. Expert model challenge and stress testing are mandatory.
