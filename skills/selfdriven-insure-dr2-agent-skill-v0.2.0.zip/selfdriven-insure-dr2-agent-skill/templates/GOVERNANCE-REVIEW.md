# Underwriting model governance review

- Proposed purpose and legal actor:
- Material customer effects:
- Insurer authorisation and roles:
- Data lawful basis, retention, consent and security:
- Fairness, prohibited features and proxy risks:
- Model card and out-of-time validation:
- Adverse event/portfolio accumulation stress:
- Manual intervention and dispute/correction path:
- Model change, monitoring and rollback:
- Security review and evidence anti-fraud controls:
- Decision: `approved_for_shadow_only` / `approved_for_pilot` / `rejected` / `needs_more_evidence`
- Reviewer, authority, signature and date:
