'use strict';
const {LINES} = require('./lines');

class ValidationError extends Error {
  constructor(message, path) { super(message); this.name = 'ValidationError'; this.details = [{path, message}]; }
}
const fail = (p, msg) => { throw new ValidationError(`${p}: ${msg}`, p); };
const obj = (x, p) => { if (!x || typeof x !== 'object' || Array.isArray(x) || Object.getPrototypeOf(x) !== Object.prototype) fail(p, 'expected plain object'); return x; };
const keys = (x, p, allowed, required = allowed) => {
  for (const k of Object.keys(x)) if (!allowed.includes(k)) fail(`${p}.${k}`, 'unknown field');
  for (const k of required) if (!Object.hasOwn(x, k)) fail(`${p}.${k}`, 'required (use null for unknown where permitted)');
};
const str = (x, p) => { if (typeof x !== 'string' || !x.length || x.length > 512) fail(p, 'expected non-empty string of at most 512 chars'); return x; };
const strOrNull = (x, p) => x === null ? x : str(x, p);
const oneOf = (x, p, allowed) => { if (!allowed.includes(x)) fail(p, `expected one of: ${allowed.join(', ')}`); return x; };
const num = (x, p, min, max) => { if (typeof x !== 'number' || !Number.isFinite(x) || x < min || x > max) fail(p, `expected finite number in [${min}, ${max}]`); return x; };
const time = (x, p) => {
  str(x, p);
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(x) || !Number.isFinite(Date.parse(x))) fail(p, 'expected UTC ISO 8601 timestamp ending in Z');
  if (new Date(x).toISOString().slice(0, 19) !== x.slice(0, 19)) fail(p, 'invalid UTC calendar date/time');
  return x;
};

const NA = 'not_applicable';
const DECISION_USES = ['research', 'underwriter_support', 'pricing', 'bind', 'decline', 'vary_or_cancel'];
const ROLES = ['insurer', 'technology_provider', 'broker', 'researcher'];
const AU_STATES = ['NSW', 'VIC', 'QLD', 'WA', 'SA', 'TAS', 'ACT', 'NT'];
const METHODS = ['inspection', 'sensor', 'document_review', 'registry_lookup', 'self_declaration'];
const CREDITABLE_METHODS = METHODS.filter(m => m !== 'self_declaration');
const DEP_KINDS = ['cloud_provider', 'managed_service_provider', 'saas', 'payment_processor', 'other'];
const MAX_AMOUNT = 1e12;

function validateProfile(spec, profile, p) {
  obj(profile, p);
  const groups = {};
  for (const key of Object.keys(spec.factors)) { const [g, a] = key.split('.'); (groups[g] ||= []).push(a); }
  keys(profile, p, Object.keys(groups));
  for (const [g, attrs] of Object.entries(groups)) {
    obj(profile[g], `${p}.${g}`); keys(profile[g], `${p}.${g}`, attrs);
    for (const a of attrs) {
      const f = spec.factors[`${g}.${a}`], v = profile[g][a], fp = `${p}.${g}.${a}`;
      if (v === null) continue; // unknown: explicit, never coerced
      if (v === NA) { if (!f.na) fail(fp, 'not_applicable is not permitted for this factor'); continue; }
      if (f.type === 'int') { if (!Number.isInteger(v)) fail(fp, 'expected integer or null'); num(v, fp, f.min, f.max); }
      else oneOf(v, fp, f.values);
    }
  }
}

function validateSubject(subject) {
  const p = 'subject'; obj(subject, p);
  if (!Object.hasOwn(LINES, subject.line)) fail(`${p}.line`, `expected one of: ${Object.keys(LINES).join(', ')}`);
  const spec = LINES[subject.line];
  const allowed = ['subject_id', 'line', 'jurisdiction', 'ownership', 'profile', 'declared_controls', 'profile_provenance'];
  const required = allowed.slice(0, 6);
  if (spec.dependencies) { allowed.push('dependencies'); required.push('dependencies'); }
  if (spec.sensitive_block) { allowed.push('sensitive'); required.push('sensitive'); }
  keys(subject, p, allowed, required);
  str(subject.subject_id, `${p}.subject_id`);
  obj(subject.jurisdiction, `${p}.jurisdiction`); keys(subject.jurisdiction, `${p}.jurisdiction`, ['country', 'state']);
  if (typeof subject.jurisdiction.country !== 'string' || !/^[A-Z]{2}$/.test(subject.jurisdiction.country)) fail(`${p}.jurisdiction.country`, 'expected ISO 3166-1 alpha-2 code');
  if (subject.jurisdiction.state !== null) {
    if (subject.jurisdiction.country === 'AU') oneOf(subject.jurisdiction.state, `${p}.jurisdiction.state`, AU_STATES);
    else str(subject.jurisdiction.state, `${p}.jurisdiction.state`);
  }
  obj(subject.ownership, `${p}.ownership`); keys(subject.ownership, `${p}.ownership`, ['scope', 'status']);
  oneOf(subject.ownership.scope, `${p}.ownership.scope`, spec.ownership_scopes);
  oneOf(subject.ownership.status, `${p}.ownership.status`, ['undisputed', 'disputed', 'unknown']);
  validateProfile(spec, subject.profile, `${p}.profile`);
  obj(subject.declared_controls, `${p}.declared_controls`); keys(subject.declared_controls, `${p}.declared_controls`, spec.controls);
  for (const c of spec.controls) if (![true, false, null, NA].includes(subject.declared_controls[c])) fail(`${p}.declared_controls.${c}`, 'expected true, false, null (unknown) or "not_applicable"');
  if (subject.profile_provenance !== undefined) {
    obj(subject.profile_provenance, `${p}.profile_provenance`);
    for (const [k, v] of Object.entries(subject.profile_provenance)) {
      if (!Object.hasOwn(spec.factors, k)) fail(`${p}.profile_provenance.${k}`, 'unknown factor');
      obj(v, `${p}.profile_provenance.${k}`); keys(v, `${p}.profile_provenance.${k}`, ['source', 'as_at']);
      str(v.source, `${p}.profile_provenance.${k}.source`); time(v.as_at, `${p}.profile_provenance.${k}.as_at`);
    }
  }
  if (spec.dependencies) {
    if (!Array.isArray(subject.dependencies) || subject.dependencies.length > 200) fail(`${p}.dependencies`, 'expected array of at most 200 dependencies');
    const seen = new Set();
    subject.dependencies.forEach((d, i) => {
      const dp = `${p}.dependencies[${i}]`; obj(d, dp); keys(d, dp, ['dependency_id', 'kind', 'provider_ref', 'criticality']);
      str(d.dependency_id, `${dp}.dependency_id`); oneOf(d.kind, `${dp}.kind`, DEP_KINDS); str(d.provider_ref, `${dp}.provider_ref`);
      oneOf(d.criticality, `${dp}.criticality`, ['low', 'moderate', 'high']);
      if (seen.has(d.dependency_id)) fail(`${dp}.dependency_id`, 'duplicate'); seen.add(d.dependency_id);
    });
  }
  if (spec.sensitive_block) {
    // Data minimisation: references only. No health or age detail is accepted by this engine.
    const sp = `${p}.sensitive`; obj(subject.sensitive, sp);
    keys(subject.sensitive, sp, ['medical_screening_used', 'consent_ref', 'lawful_basis_ref']);
    if (typeof subject.sensitive.medical_screening_used !== 'boolean') fail(`${sp}.medical_screening_used`, 'expected boolean');
    strOrNull(subject.sensitive.consent_ref, `${sp}.consent_ref`); strOrNull(subject.sensitive.lawful_basis_ref, `${sp}.lawful_basis_ref`);
  }
  return spec;
}

function validatePolicyTerms(spec, terms) {
  const p = 'policy_terms'; obj(terms, p);
  keys(terms, p, ['version', 'wording_ref', 'currency', 'period', 'coverages', 'overlap_allocation'], ['version', 'wording_ref', 'currency', 'period', 'coverages']);
  str(terms.version, `${p}.version`); strOrNull(terms.wording_ref, `${p}.wording_ref`); oneOf(terms.currency, `${p}.currency`, ['AUD']);
  obj(terms.period, `${p}.period`); keys(terms.period, `${p}.period`, ['start', 'end']);
  time(terms.period.start, `${p}.period.start`); time(terms.period.end, `${p}.period.end`);
  if (Date.parse(terms.period.end) <= Date.parse(terms.period.start)) fail(`${p}.period.end`, 'must be later than start');
  if (!Array.isArray(terms.coverages) || !terms.coverages.length || terms.coverages.length > 20) fail(`${p}.coverages`, 'expected 1 to 20 coverages');
  const seen = new Set();
  terms.coverages.forEach((c, i) => {
    const cp = `${p}.coverages[${i}]`; obj(c, cp);
    if (!Object.hasOwn(spec.coverages, c.coverage)) fail(`${cp}.coverage`, `expected one of: ${Object.keys(spec.coverages).join(', ')}`);
    if (seen.has(c.coverage)) fail(`${cp}.coverage`, 'duplicate coverage'); seen.add(c.coverage);
    const kind = spec.coverages[c.coverage].exposure;
    const base = ['coverage', 'excess', 'excluded_perils', 'sublimits'];
    const extra = kind === 'sum_insured' ? ['sum_insured'] : kind === 'limit' ? ['limit']
      : ['insured_annual_amount', 'valuation_basis', 'indemnity_period_days', 'waiting_days', 'limit'];
    keys(c, cp, [...base, ...extra]);
    num(c.excess, `${cp}.excess`, 0, MAX_AMOUNT);
    if (!Array.isArray(c.excluded_perils)) fail(`${cp}.excluded_perils`, 'expected array');
    c.excluded_perils.forEach((x, j) => oneOf(x, `${cp}.excluded_perils[${j}]`, spec.perils));
    obj(c.sublimits, `${cp}.sublimits`);
    for (const [k, v] of Object.entries(c.sublimits)) { oneOf(k, `${cp}.sublimits.${k}`, spec.perils); num(v, `${cp}.sublimits.${k}`, 0, MAX_AMOUNT); }
    if (kind === 'sum_insured') num(c.sum_insured, `${cp}.sum_insured`, 1, MAX_AMOUNT);
    if (kind !== 'sum_insured' && c.limit !== null) num(c.limit, `${cp}.limit`, 0, MAX_AMOUNT); // null = no monetary limit
    if (kind === 'insured_annual_amount') {
      num(c.insured_annual_amount, `${cp}.insured_annual_amount`, 1, MAX_AMOUNT);
      oneOf(c.valuation_basis, `${cp}.valuation_basis`, spec.coverages[c.coverage].valuation_bases);
      num(c.indemnity_period_days, `${cp}.indemnity_period_days`, 1, 1095); num(c.waiting_days, `${cp}.waiting_days`, 0, 365);
      if (c.waiting_days >= c.indemnity_period_days) fail(`${cp}.waiting_days`, 'must be shorter than the indemnity period');
      if (c.excess !== 0) fail(`${cp}.excess`, 'time-element covers express the excess as waiting_days; set excess to 0');
    }
  });
  if (terms.overlap_allocation !== undefined) {
    if (!Array.isArray(terms.overlap_allocation)) fail(`${p}.overlap_allocation`, 'expected array');
    terms.overlap_allocation.forEach((a, i) => {
      const ap = `${p}.overlap_allocation[${i}]`; obj(a, ap); keys(a, ap, ['group', 'rule', 'primary_coverage']);
      str(a.group, `${ap}.group`); oneOf(a.rule, `${ap}.rule`, ['primary']);
      if (!seen.has(a.primary_coverage) || spec.coverages[a.primary_coverage].overlap_group !== a.group) fail(`${ap}.primary_coverage`, 'must be a listed coverage belonging to the group');
    });
  }
}

function validateEvidence(spec, e, p, subjectId) {
  obj(e, p);
  keys(e, p, ['evidence_id', 'subject_id', 'predicate', 'value', 'issuer_id', 'method', 'observed_at', 'valid_until', 'digest_sha256', 'signature_b64'],
    ['evidence_id', 'subject_id', 'predicate', 'value', 'issuer_id', 'method', 'observed_at', 'valid_until']);
  for (const k of ['evidence_id', 'subject_id', 'predicate', 'issuer_id']) str(e[k], `${p}.${k}`);
  if (e.subject_id !== subjectId) fail(`${p}.subject_id`, 'does not match the assessed subject');
  const control = /^control\.([a-z0-9_]+)\.operational$/.exec(e.predicate);
  if (control) {
    if (!spec.controls.includes(control[1])) fail(`${p}.predicate`, 'control is not defined for this line');
    if (typeof e.value !== 'boolean') fail(`${p}.value`, 'control assertions carry a boolean');
  } else if (e.predicate.startsWith('fact.')) {
    const f = spec.factors[e.predicate.slice(5)];
    if (!f) fail(`${p}.predicate`, 'factor is not defined for this line');
    if (f.type === 'int') { if (!Number.isInteger(e.value)) fail(`${p}.value`, 'expected integer'); num(e.value, `${p}.value`, f.min, f.max); }
    else oneOf(e.value, `${p}.value`, f.values);
  } else fail(`${p}.predicate`, 'expected control.<name>.operational or fact.<group>.<attribute>');
  oneOf(e.method, `${p}.method`, METHODS);
  time(e.observed_at, `${p}.observed_at`); time(e.valid_until, `${p}.valid_until`);
  if (Date.parse(e.valid_until) <= Date.parse(e.observed_at)) fail(`${p}.valid_until`, 'must be later than observed_at');
  if (e.digest_sha256 !== undefined && !/^[a-f0-9]{64}$/.test(e.digest_sha256)) fail(`${p}.digest_sha256`, 'expected sha256 hex');
  if (e.signature_b64 !== undefined) str(e.signature_b64, `${p}.signature_b64`);
}

function validateInput(input) {
  obj(input, 'input');
  keys(input, 'input', ['schema_version', 'as_of', 'decision_use', 'requester_role', 'subject', 'policy_terms', 'evidence', 'prior_snapshot'],
    ['schema_version', 'as_of', 'decision_use', 'requester_role', 'subject', 'policy_terms', 'evidence']);
  oneOf(input.schema_version, 'input.schema_version', ['0.2']);
  time(input.as_of, 'input.as_of'); oneOf(input.decision_use, 'input.decision_use', DECISION_USES); oneOf(input.requester_role, 'input.requester_role', ROLES);
  const spec = validateSubject(input.subject);
  validatePolicyTerms(spec, input.policy_terms);
  if (!Array.isArray(input.evidence) || input.evidence.length > 1000) fail('input.evidence', 'expected array of at most 1000 assertions');
  const seen = new Set();
  input.evidence.forEach((e, i) => {
    validateEvidence(spec, e, `input.evidence[${i}]`, input.subject.subject_id);
    if (seen.has(e.evidence_id)) fail(`input.evidence[${i}].evidence_id`, 'duplicate evidence ID'); seen.add(e.evidence_id);
  });
  if (input.prior_snapshot !== undefined) {
    const s = obj(input.prior_snapshot, 'input.prior_snapshot');
    keys(s, 'input.prior_snapshot', ['assessment_id', 'as_of', 'comparability_sha256', 'expected_claim_payment_total', 'evidence_resolved_share']);
    str(s.assessment_id, 'input.prior_snapshot.assessment_id'); time(s.as_of, 'input.prior_snapshot.as_of');
    if (!/^[a-f0-9]{64}$/.test(s.comparability_sha256)) fail('input.prior_snapshot.comparability_sha256', 'expected sha256 hex');
    if (s.expected_claim_payment_total !== null) num(s.expected_claim_payment_total, 'input.prior_snapshot.expected_claim_payment_total', 0, MAX_AMOUNT);
    if (s.evidence_resolved_share !== null) num(s.evidence_resolved_share, 'input.prior_snapshot.evidence_resolved_share', 0, 1);
  }
  return spec;
}

function validateTrustPolicy(policy) {
  const p = 'trust_policy'; obj(policy, p);
  keys(policy, p, ['policy_id', 'version', 'issuers', 'revoked_evidence_ids', 'max_evidence_age_days']);
  str(policy.policy_id, `${p}.policy_id`); str(policy.version, `${p}.version`);
  obj(policy.issuers, `${p}.issuers`);
  for (const [id, e] of Object.entries(policy.issuers)) {
    const ip = `${p}.issuers.${id}`; obj(e, ip);
    keys(e, ip, ['public_key_pem', 'accepted_methods', 'accepted_predicate_prefixes', 'valid_from', 'valid_until', 'revoked_at']);
    str(e.public_key_pem, `${ip}.public_key_pem`);
    if (!Array.isArray(e.accepted_methods)) fail(`${ip}.accepted_methods`, 'expected array');
    e.accepted_methods.forEach((m, i) => oneOf(m, `${ip}.accepted_methods[${i}]`, CREDITABLE_METHODS)); // self_declaration can never be made creditable
    if (!Array.isArray(e.accepted_predicate_prefixes)) fail(`${ip}.accepted_predicate_prefixes`, 'expected array');
    e.accepted_predicate_prefixes.forEach((x, i) => str(x, `${ip}.accepted_predicate_prefixes[${i}]`));
    time(e.valid_from, `${ip}.valid_from`);
    for (const k of ['valid_until', 'revoked_at']) if (e[k] !== null) time(e[k], `${ip}.${k}`);
  }
  if (!Array.isArray(policy.revoked_evidence_ids)) fail(`${p}.revoked_evidence_ids`, 'expected array');
  policy.revoked_evidence_ids.forEach((x, i) => str(x, `${p}.revoked_evidence_ids[${i}]`));
  obj(policy.max_evidence_age_days, `${p}.max_evidence_age_days`);
  for (const [k, v] of Object.entries(policy.max_evidence_age_days)) num(v, `${p}.max_evidence_age_days.${k}`, 1, 36500);
  return policy;
}

const EMPTY_TRUST_POLICY = Object.freeze({policy_id: 'none', version: '0', issuers: {}, revoked_evidence_ids: [], max_evidence_age_days: {}});

module.exports = {ValidationError, validateInput, validateSubject, validateTrustPolicy, EMPTY_TRUST_POLICY,
  NA, DECISION_USES, ROLES, AU_STATES, METHODS, CREDITABLE_METHODS, DEP_KINDS};
