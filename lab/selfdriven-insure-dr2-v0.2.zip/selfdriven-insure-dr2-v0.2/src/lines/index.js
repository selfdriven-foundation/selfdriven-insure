'use strict';
const {deepFreeze} = require('../canonical');
const specs = [require('./home-contents'), require('./strata'), require('./sme'), require('./travel'), require('./cyber')];
const LINES = deepFreeze(Object.fromEntries(specs.map(s => [s.line, s])));
// The scope matrix: every in-scope (line, coverage, peril) triple.
function catalog() {
  return {catalog_version: '0.2.0', jurisdictions: ['AU'],
    lines: Object.values(LINES).map(s => ({line: s.line, title: s.title, context_profile: s.context_profile,
      period_basis: s.period_basis, coverages: Object.keys(s.coverages).map(c => ({coverage: c, exposure: s.coverages[c].exposure,
        overlap_group: s.coverages[c].overlap_group || null, perils: s.matrix[c]})), controls: s.controls}))};
}
module.exports = {LINES, catalog};
