# Australian Regulatory Reference Pointers

**Reference list snapshot: 20 November 2026.** URLs are starting points to independently verify; **not** a declaration that every rule applies to every selfdriven.insure actor or product.

- APRA prudential standards and guidance: https://www.apra.gov.au/prudential-and-reporting-standards ; review CPS 220 (Risk Management), CPS 230 (Operational Risk Management), CPS 234 (Information Security), GPS 230 (Reinsurance Management), and general insurance guidance as applicable.
- ASIC insurance sector regulatory guidance and product governance: https://asic.gov.au/regulatory-resources/insurance/ ; review applicable design and distribution, claims handling and consumer protection requirements.
- OAIC Australian Privacy Principles and privacy guidance: https://www.oaic.gov.au/privacy/australian-privacy-principles ; health and other sensitive information need particular attention.
- Australian legislation: https://www.legislation.gov.au/ (Insurance Contracts Act 1984, Corporations Act 2001, Privacy Act 1988, as amended; check relevance).
- National Insurance Brokers Association / Insurance Council of Australia industry references may aid vocabulary, but are not sources of binding law.
- State/territory strata authorities for scheme insurance obligations, including NSW Fair Trading (https://www.nsw.gov.au/housing-and-construction/strata), VIC Consumer Affairs and corresponding jurisdictions.
- DFAT travel advice: https://www.smartraveller.gov.au/ ; advisories are context and are not universal policy exclusions.
- Australian Cyber Security Centre advisories and Essential Eight: https://www.cyber.gov.au/ ; control practices are not themselves calibrated claim probabilities.

## Agent regulatory research protocol
For regulatory claims identify law/standard title, regulator, official URL, current date/effective date, regulated legal entity/product, applicability, evidence of compliance and review owner. If not verified, write `requires_legal_confirmation`. Avoid inferring underwriting eligibility from regulation alone.
