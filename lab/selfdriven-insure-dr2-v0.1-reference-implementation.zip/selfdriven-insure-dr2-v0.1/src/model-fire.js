'use strict';
const {sha256} = require('./canonical');
// Explicitly synthetic coefficients: NOT an actuarially calibrated model.
function deepFreeze(value) {
  if(value && typeof value==='object') {
    for (const member of Object.values(value)) deepFreeze(member);
    Object.freeze(value);
  }
  return value;
}
const FIRE_MODEL = deepFreeze({
  model_id: 'dr2-fire-synthetic', version: '0.1.0', status:'unvalidated_synthetic',
  peril:'fire', coverage:'property_damage', currency:'AUD',
  annual_frequency_base:0.015, base_claim_severity_share:0.20,
  frequency_material:{steel:1, masonry:0.85,timber:1.4,concrete:0.75},
  frequency_occupancy:{warehouse:1,office:0.65,light_industrial:1.3,hospitality:1.5},
  frequency_external_fire_hazard:{low:0.8,moderate:1,high:1.4},
  severity_material:{steel:1,masonry:0.9,timber:1.25,concrete:0.8},
  control_effects:{
    sprinkler_system:{target:'conditional_severity', reduction:0.45},
    smoke_detection:{target:'conditional_severity', reduction:0.15},
    electrical_inspection:{target:'claim_frequency', reduction:0.20}
  },
  limitations:[
    'Synthetic multipliers are illustrative, not estimated from claims data',
    'Single-claim expected annual loss only; catastrophe dependence and policy terms excluded',
    'Control multipliers assumed multiplicative, with no measured interaction or causal attribution',
    'Unknown controls receive no mitigation credit; result is not an assessment that controls are absent',
    'No uncertainty interval or technical premium is produced'
  ]
});
const manifest = () => ({...FIRE_MODEL,manifest_sha256:sha256(FIRE_MODEL)});
function calculateFire(asset, controls) {
  const material = asset.cope.construction.primary_material;
  const occupancy = asset.cope.occupancy.primary_use;
  const exposure = asset.cope.exposure.external_fire_hazard;
  const baseFreq=FIRE_MODEL.annual_frequency_base;
  const freqFactors={material:FIRE_MODEL.frequency_material[material],occupancy:FIRE_MODEL.frequency_occupancy[occupancy],external_fire_hazard:FIRE_MODEL.frequency_external_fire_hazard[exposure]};
  const severityFactors={material:FIRE_MODEL.severity_material[material]};
  const referenceFreq = Math.min(1,baseFreq*Object.values(freqFactors).reduce((a,b)=>a*b,1));
  const referenceSev = Math.min(asset.sum_insured_aud,asset.sum_insured_aud*FIRE_MODEL.base_claim_severity_share*severityFactors.material);
  let fMultiplier=1, sMultiplier=1;
  const applied=[];
  for (const [name, effect] of Object.entries(FIRE_MODEL.control_effects)) {
    if (controls[name]?.state !== 'verified_true') continue;
    if (effect.target === 'claim_frequency') fMultiplier*=1-effect.reduction;
    else sMultiplier*=1-effect.reduction;
    applied.push({control:name,target:effect.target,synthetic_reduction:effect.reduction,evidence_ids:controls[name].evidence_ids});
  }
  const frequency=referenceFreq*fMultiplier;
  const severity=referenceSev*sMultiplier;
  const referenceEal=referenceFreq*referenceSev;
  const residualEal=frequency*severity;
  return {
    peril:'fire',coverage:'property_damage',currency:'AUD',
    frequency_model:'single_claim_annual_probability',
    reference:{annual_claim_probability:referenceFreq,conditional_mean_severity_aud:referenceSev,expected_annual_loss_aud:referenceEal},
    residual:{annual_claim_probability:frequency,conditional_mean_severity_aud:severity,expected_annual_loss_aud:residualEal},
    estimated_reduction_aud:referenceEal-residualEal,
    factors:{reference_frequency:freqFactors,reference_severity:severityFactors,frequency_mitigation_multiplier:fMultiplier,severity_mitigation_multiplier:sMultiplier},
    applied_controls:applied,
    model_status:'unvalidated_synthetic',
    uncertainty:{status:'not_quantified'},
    premium:null
  };
}
module.exports={FIRE_MODEL,manifest,calculateFire};
