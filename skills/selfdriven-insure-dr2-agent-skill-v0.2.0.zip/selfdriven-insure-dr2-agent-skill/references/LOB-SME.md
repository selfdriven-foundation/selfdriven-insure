# Line module — SME: Buildings, Contents, Business Interruption & Loss of Profits

## Canonical units
Subject = business legal entity plus sites, insured assets, equipment, stock and operations, mapped to premises and supply-chain dependencies. Separate property damage from interruption of business activity. Policy period normally annual; interruption indemnity period may extend beyond expiry, depending on wording.

## COPE for physical property
- Construction: premises materials, fire separations, roof, structural and replacement values.
- Occupancy: business activities, hazardous materials, processes, hours, equipment, storage.
- Protection: alarms, fire suppression, security, maintenance and environmental controls.
- Exposure: natural hazards, neighbours, utilities and external infrastructure.

## Coverage families
| Coverage | Loss outcome | Core basis |
|---|---|---|
| Buildings | Property damage | repair/rebuild under policy terms |
| Contents / plant | Equipment, fixtures and furnishings | insured replacement/reinstatement basis |
| Stock | Damaged inventory | cost/valuation basis from policy |
| Business interruption (BI) | Insured trading interruption | gross profit / revenue or other agreed formula |
| Additional increased cost of working | Extra expense to avoid/reduce interruption | expenses subject to tests and sublimits |
| Loss of profits | Frequently a BI description, not a separate benefit | interpret contract, never auto-add to BI |

## BI / loss-of-profits model
Separate causal stages:
`covered initiating event → property or other insured trigger → physical/operational impairment → business activity lost → projected revenue/turnover effect → continuing and saved expenses → insurance gross profit/increased cost of working → policy waiting period, indemnity period, limits and offsets`.

Model *insured gross profit* using the applicable policy definition, **not accounting net profit**. Example research decomposition: insured turnover reduction × contract-defined rate of gross profit + allowable increased cost of working − saved expenses/other contractual adjustments; apply formal policy terms case-by-case. Avoid subtracting saved expenses twice. Track counterfactual turnover, seasonality, growth and event-related demand impacts.

### Dependency graph
`Site → Equipment → Process → Product/Service → RevenueStream`; connect suppliers, cloud systems, power, water, logistics, staff, customers, alternate sites and recovery lead times. Explicitly model contingent BI only where policy covers it.

## Anti-double-counting rule
`business_interruption` and `loss_of_profits` are often **synonymous insurance concepts** or alternate methods of quantifying the same insured economic damage. Treat them as separate policy sections only when distinct triggers and disjoint insured loss bases are documented. Also avoid adding BI lost profit to the same amount recovered as increased cost of working.

## Validation cases
1. Fire damages building, stock and equipment; BI follows one covered trigger with separate contract-defined benefit.
2. Fire occurs but business trades normally → physical property loss without assumed BI loss.
3. Supplier outage with no insured trigger → operational loss, potentially zero *covered* BI while gross economic harm remains.
4. BI and loss-of-profits labels refer to same section → only one insured payment.
5. Interruption crosses policy year → indemnity period and time-dependent limits follow contract.
6. Saved expense treatment, VAT/GST, co-insurance and underinsurance basis are explicit and tested.
7. Two sites share a critical machine → correlated impairment, not independently modelled events.

## Calibration data
Exposure by industry, building/site, insured gross-profit and revenue bases, property event and claim IDs, BI start/end, sales history, variable costs, supply outages, wait periods, inflation and adjustment practices. Require qualified review of financial/accounting assumptions.
