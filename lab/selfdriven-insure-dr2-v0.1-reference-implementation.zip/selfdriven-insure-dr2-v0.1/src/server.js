#!/usr/bin/env node
'use strict';
// Loopback-only DEVELOPMENT server. No authentication, persistence or production controls.
const http=require('node:http');
const fs=require('node:fs');
const {assess}=require('./assess');
const {manifest}=require('./model-fire');
const {ValidationError}=require('./validate');
const registryPath=process.env.DR2_TRUST_REGISTRY_FILE;
const trustRegistry=registryPath?JSON.parse(fs.readFileSync(registryPath,'utf8')):{};
const port=Number(process.env.PORT||8765);
function respond(res,status,obj) {res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj));}
const server=http.createServer((req,res)=>{
  if(req.method==='GET' && req.url==='/health') return respond(res,200,{status:'ok',mode:'research_only'});
  if(req.method==='GET' && req.url==='/v1/models/fire/manifest') return respond(res,200,manifest());
  if(req.method==='POST' && req.url==='/v1/assessments') {
    if(!(req.headers['content-type']||'').startsWith('application/json')) return respond(res,415,{error:'content-type must be application/json'});
    let body='',closed=false;
    req.on('data',chunk=>{
      body+=chunk;
      if(body.length>131072){closed=true;respond(res,413,{error:'request exceeds 128 KiB'});req.destroy();}
    });
    req.on('end',()=>{
      if(closed)return;
      try {respond(res,200,assess(JSON.parse(body),{trustRegistry}));}
      catch(err){respond(res,err instanceof ValidationError?422:400,{error:err.message});}
    });
    return;
  }
  respond(res,404,{error:'not found'});
});
if(require.main===module) server.listen(port,'127.0.0.1',()=>console.log(`DR2 development server on http://127.0.0.1:${port}`));
module.exports={server};
