'use strict';
const {checkSignature} = require('./canonical');
const {NA} = require('./validate');

const ELIGIBLE = 'eligible_authenticated_assertion';
const DAY = 86400000;

// Eligibility is decided BEFORE any risk effect is considered.
// "Eligible" means: authenticated against an out-of-band trust anchor, in scope, in date
// and not revoked. It does NOT mean the asserted fact is true or the control is effective.
function verifyAssertion(e, asOf, policy) {
  const out = status => ({evidence_id: e.evidence_id, predicate: e.predicate, issuer_id: e.issuer_id, method: e.method,
    observed_at: e.observed_at, valid_until: e.valid_until, signed: e.signature_b64 !== undefined, status});
  if (policy.revoked_evidence_ids.includes(e.evidence_id)) return out('revoked_evidence');
  const issuer = Object.hasOwn(policy.issuers, e.issuer_id) ? policy.issuers[e.issuer_id] : null;
  if (!issuer) return out('untrusted_issuer');
  const t = Date.parse(asOf), obs = Date.parse(e.observed_at);
  if (issuer.revoked_at !== null && Date.parse(issuer.revoked_at) <= t) return out('issuer_revoked');
  if (obs < Date.parse(issuer.valid_from) || (issuer.valid_until !== null && obs >= Date.parse(issuer.valid_until))) return out('issuer_not_valid_at_observation');
  const sig = checkSignature(e, issuer.public_key_pem);
  if (!sig.digest_valid) return out('missing_or_invalid_digest');
  if (!sig.signature_valid) return out('missing_or_invalid_signature');
  if (!issuer.accepted_methods.includes(e.method)) return out('unaccepted_method');
  if (!issuer.accepted_predicate_prefixes.some(pre => e.predicate.startsWith(pre))) return out('predicate_outside_issuer_scope');
  if (obs > t) return out('future_observation');
  if (Date.parse(e.valid_until) <= t) return out('expired');
  const maxAge = Object.hasOwn(policy.max_evidence_age_days, e.predicate) ? policy.max_evidence_age_days[e.predicate]
    : Object.hasOwn(policy.max_evidence_age_days, 'default') ? policy.max_evidence_age_days.default : null;
  if (maxAge !== null && t - obs > maxAge * DAY) return out('stale');
  return out(ELIGIBLE);
}

function evaluateEvidence(spec, subject, assertions, asOf, policy) {
  const records = assertions.map(e => verifyAssertion(e, asOf, policy)).sort((a, b) => a.evidence_id < b.evidence_id ? -1 : 1);
  const status = new Map(records.map(r => [r.evidence_id, r.status]));
  const eligibleFor = predicate => assertions.filter(e => e.predicate === predicate && status.get(e.evidence_id) === ELIGIBLE);
  const issues = [];

  const controls = {};
  for (const name of spec.controls) {
    const predicate = `control.${name}.operational`;
    const eligible = eligibleFor(predicate), values = new Set(eligible.map(e => e.value));
    const declared = subject.declared_controls[name];
    let state = declared === NA ? 'not_applicable' : 'unknown';
    if (values.size > 1) { state = 'disputed'; issues.push({subject: `control.${name}`, code: 'conflicting_eligible_assertions'}); }
    else if (values.size === 1) {
      const v = values.has(true);
      if (declared === NA || (v && declared === false)) { state = 'disputed'; issues.push({subject: `control.${name}`, code: 'eligible_assertion_disagrees_with_declaration'}); }
      else {
        state = v ? 'verified_true' : 'verified_false';
        if (!v && declared === true) issues.push({subject: `control.${name}`, code: 'eligible_assertion_disagrees_with_declaration'});
      }
    }
    controls[name] = {state, declared, evidence_ids: eligible.map(e => e.evidence_id).sort(),
      assertions_submitted: assertions.filter(e => e.predicate === predicate).length};
  }

  const facts = {};
  for (const key of Object.keys(spec.factors)) {
    const [g, a] = key.split('.'), declared = subject.profile[g][a];
    const eligible = eligibleFor(`fact.${key}`), values = new Set(eligible.map(e => e.value));
    let state, value = declared;
    if (values.size > 1) { state = 'disputed'; value = null; issues.push({subject: `fact.${key}`, code: 'conflicting_eligible_assertions'}); }
    else if (values.size === 1) {
      const v = [...values][0];
      if (declared === null || declared === v) { state = 'verified'; value = v; }
      else { state = 'disputed'; value = null; issues.push({subject: `fact.${key}`, code: 'eligible_assertion_disagrees_with_declaration'}); }
    } else state = declared === null ? 'unknown' : declared === NA ? 'not_applicable' : 'declared';
    const provenance = subject.profile_provenance && Object.hasOwn(subject.profile_provenance, key) ? subject.profile_provenance[key] : null;
    facts[key] = {state, value, declared, evidence_ids: eligible.map(e => e.evidence_id).sort(), provenance};
  }

  const applicable = spec.controls.filter(c => controls[c].state !== 'not_applicable');
  const resolved = applicable.filter(c => ['verified_true', 'verified_false'].includes(controls[c].state));
  const factKeys = Object.keys(facts).filter(k => facts[k].state !== 'not_applicable');
  return {
    records, controls, facts, issues,
    unanchored_signed_assertions: records.filter(r => r.signed && r.status === 'untrusted_issuer').map(r => r.evidence_id),
    // Documentation metrics only. Not a probability, confidence level or score.
    coverage: {
      applicable_controls: applicable.length, resolved_controls: resolved.length,
      credited_eligible_controls: applicable.filter(c => controls[c].state === 'verified_true').length,
      control_resolved_share: applicable.length ? resolved.length / applicable.length : null,
      applicable_facts: factKeys.length, verified_facts: factKeys.filter(k => facts[k].state === 'verified').length,
      unknown_or_disputed_facts: factKeys.filter(k => ['unknown', 'disputed'].includes(facts[k].state)).length,
      meaning: 'share_of_items_resolved_by_eligible_evidence_not_a_confidence_measure'
    }
  };
}
module.exports = {ELIGIBLE, verifyAssertion, evaluateEvidence};
