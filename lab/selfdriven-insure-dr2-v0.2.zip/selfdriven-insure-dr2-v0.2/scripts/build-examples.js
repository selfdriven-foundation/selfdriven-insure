#!/usr/bin/env node
'use strict';
// Writes assets/examples/<line>.input.json and <line>.result.json (synthetic fixture, no evidence).
const fs = require('node:fs');
const path = require('node:path');
const {assess} = require('../src/engine');
const {BUILDERS} = require('./lib/examples');
const parameterSet = require('../params/synthetic-fixture-v0.2.json');
const dir = path.join(__dirname, '..', 'assets', 'examples');
for (const [line, build] of Object.entries(BUILDERS)) {
  const input = build(), result = assess(input, {parameterSet});
  fs.writeFileSync(path.join(dir, `${line}.input.json`), JSON.stringify(input, null, 2) + '\n');
  fs.writeFileSync(path.join(dir, `${line}.result.json`), JSON.stringify(result, null, 2) + '\n');
  const t = result.risk.totals.expected_claim_payment;
  console.log(`${line.padEnd(14)} ${result.status.padEnd(22)} payment point=${t.point} low=${t.low} high=${t.high} insurability=${result.insurability.status}`);
}
