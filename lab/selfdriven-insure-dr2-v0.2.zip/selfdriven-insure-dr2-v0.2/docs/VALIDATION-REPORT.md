# DR² v0.2 — Calibration and validation report

Date: 20 November 2026. Parameter set: `dr2-synthetic-fixture` v0.2.0 (`synthetic_fixture`).

## Summary

Software conformance: passed. Everything else: not started. The engine is not approved
for any underwriting, pricing or customer-facing use.

## Gate A — Software conformance (passed)

`node --test`: 54 tests, 54 pass. `python3 scripts/validate_bundle.py`: 16 JSON files, ok.

| Area | What the tests establish |
|---|---|
| Arithmetic | Normal CDF reference points; lognormal limited expected value agrees with an independent numerical integration to 2e-4 relative; layer behaviour for excess, cap and limit |
| Hand-checked values | SME theft frequency, severity and payment recomputed from the tables; period scaling; travel trip-day and traveller exposure; time-element daily amount, waiting-day excess and indemnity cap |
| Evidence | Declared controls earn nothing; 11 separate failure modes earn nothing; conflicts are disputed and referred; unanchored signed assertions are referred; self-declaration cannot be made creditable |
| Mechanism | Frequency controls change only frequency, severity and duration controls only severity; fire controls do not touch theft; email MFA does not touch ransomware |
| Unknown / not applicable | Unknown gives bounds and no point; a known value falls inside the bounds; not-applicable is accepted only where defined; a missing field is rejected |
| Policy terms | Excluded peril keeps the loss event and zeroes the payment; sublimit caps payment and leaves gross loss unchanged |
| Line constraints | Strata common property only; BI and loss of profits never summed without allocation; travel per trip with no COPE, no controls, no health or age fields; cyber shared-cause groups and accumulation keys |
| Governance | No parameter set gives `model_unavailable`; pricing, bind, decline and vary are referred; premium and score always null; unsafe parameter sets are rejected |
| Reproducibility | Deterministic replay; key-order independence; any change to parameters or terms moves the hashes |

Not covered: cross-runtime numerical stability, fuzzing, load, security testing of the
development server, canonical-encoding conformance vectors for other languages.

## Gate B — Evidence assurance (not started)

Blockers: no accredited issuers, no key lifecycle, no measured agreement between
attestations and physical or technical re-inspection, no revocation service.

## Gate C — Predictive validation (not started)

Blockers, per line:

- No claims or exposure dataset for any line. No frequency, severity or duration parameter
  has been estimated. The lognormal family and every coefficient of variation are assumed.
- No hazard mapping for bushfire, flood, wind or theft; no destination band mapping.
- No causal or empirical basis for any control effect. Selection effects are unaddressed.
- Multiplicative factor structure is untested against interaction effects.
- Business interruption duration and cyber severity have no data support at all.
- Travel event rates ignore age and health by design; a real model needs a lawful basis.

Required before any reliance: pre-registered out-of-time validation per coverage and peril,
calibration by segment, proper scoring against an incumbent benchmark, interval coverage,
subgroup stability, and independent actuarial review.

## Gate D — Fairness and privacy review (not started)

## Gate E — Shadow underwriting and insurer approval (not started)

## Sign-offs

| Role | Name | Date | Decision |
|---|---|---|---|
| Engineering reviewer | — | — | Pending |
| Appointed or reviewing actuary | — | — | Pending |
| Underwriting lead | — | — | Pending |
| Privacy and fairness | — | — | Pending |
| Model owner / insurer governance | — | — | Pending |
