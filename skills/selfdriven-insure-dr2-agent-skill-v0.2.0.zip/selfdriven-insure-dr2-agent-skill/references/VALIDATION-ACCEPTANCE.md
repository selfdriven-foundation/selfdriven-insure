# Verification, Validation & Acceptance

## Six validation planes
**V1 Data contract**: schema and referential integrity; type and unit checks; timestamp consistency; currency/valuation and geography fields; unknown / false / zero / not-applicable semantics.

**V2 Evidence assurance**: cryptographic verification; source competence; revocation; expiry; scope; conflict resolution; independence; provenance; replay under frozen trust policy.

**V3 Computational**: algebraic identities within their assumptions; deterministic replay; stable serialization; exact policy-term ordering; floating-point or decimal policy; model manifest pinning and extreme/boundary inputs.

**V4 Predictive/actuarial**: labelled exposure and outcome definition, temporal holdout, calibration-in-the-large and by segment, claim count/severity model checks, out-of-time score stability, event aggregation, tail risk, backtesting and uncertainty intervals.

**V5 Underwriting/domain**: specialist review of peril relevance, causal pathway, contract semantics, claim/payment reconciliation, absence of double-counting and material referral reasons.

**V6 Governance**: privacy, responsible use and fairness, human decision rights, approval chain, incident/change management, access, monitoring, rollback and customer explanation.

## Formal hypothesis protocol
For each proposed effect write: `hypothesis`, target `peril+coverage`, mechanism, population, comparator, outcome, data provenance, temporal holdout, model class, confounders/selection effects, statistical method, sign-off owner, pre-registered pass threshold and known failure modes. Avoid post-hoc thresholds.

## Example implementation milestones
| Gate | Output | Must pass |
|---|---|---|
| G0 Ontology | canonical line/peril/coverage | expert-reviewed mappings |
| G1 Software | schema + evidence + adapters | schema and logic tests |
| G2 Reproducibility | immutable snapshots | byte-identical deterministic replays |
| G3 Data | governed exposure/claims extract | quality/lineage audit |
| G4 Model | fitted benchmark vs enhanced | out-of-time predictive tests |
| G5 Shadow | insurer-underwriter comparison | safety, referral and governance review |
| G6 Limited pilot | approved supervised use | monitoring/rollback/complaints ready |

## Required line-specific acceptance cases
- **Home**: building-vs-contents, natural peril source missing, coverage exclusion, time-based occupancy, one event/multiple sections.
- **Strata**: zone-level sprinkler scope; lot-common ownership; multi-lot water propagation; shared catastrophe.
- **SME**: cover trigger, insurance gross-profit accounting, indemnity period, BI/profits deduplication, cross-site dependencies.
- **Travel**: per-trip period, policy known-event date, medical data restrictions, multiple leg same event, refund offsets.
- **Cyber**: scoped MFA, restore evidence, common vendor outage, waiting periods, changeable attack surface and threats.

## Reference software checks
Run `python3 scripts/validate_bundle.py` (requires Python jsonschema for full schema validation) and `node --test` for deterministic arithmetic tests. These checks only demonstrate consistency of the **engineering scaffolding**.

## Required build outputs
Return a model card for each component, coverage-peril matrix, sample events and assertions, validation trace, source and parameter hashes, unvalidated assumptions, blockers and production sign-off requirements.

## Immediate rejection conditions
A fabricated premium; absent policy terms treated as standard; hidden evidence multiplier; claims of physical truth from signatures; additive duplicate BI/profits; COPE applied to travel/cyber; cross-line score comparison without reference population; automatic acceptance/binding/declination by autonomous agent.
