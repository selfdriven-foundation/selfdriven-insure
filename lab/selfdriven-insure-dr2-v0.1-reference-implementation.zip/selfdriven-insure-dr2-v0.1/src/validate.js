'use strict';
class ValidationError extends Error {
  constructor(message, details=[]) { super(message); this.name='ValidationError'; this.details=details; }
}
const fail = (path, msg) => { throw new ValidationError(`${path}: ${msg}`, [{path, message:msg}]); };
const keys = (x,p,allowed) => { for (const k of Object.keys(x)) if (!allowed.includes(k)) fail(`${p}.${k}`,'unknown field'); };
const object = (x,p) => { if (!x || typeof x !== 'object' || Array.isArray(x) || Object.getPrototypeOf(x)!==Object.prototype) fail(p,'expected plain object'); return x; };
const str = (x,p) => { if (typeof x !== 'string' || x.length === 0 || x.length > 512) fail(p,'expected nonempty string, <=512 chars'); return x; };
const oneOf = (x,p,allowed) => { if (!allowed.includes(x)) fail(p,`expected one of: ${allowed.join(', ')}`); return x; };
const num = (x,p,min,max) => { if (typeof x !== 'number' || !Number.isFinite(x) || x<min || x>max) fail(p,`expected finite number in [${min}, ${max}]`); return x; };
const time = (x,p) => {
  str(x,p);
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(x)||!Number.isFinite(Date.parse(x))) fail(p,'expected valid UTC ISO 8601 timestamp');
  if (new Date(x).toISOString().slice(0,19)!==x.slice(0,19)) fail(p,'invalid UTC calendar date/time');
  return x;
};
const controlNames = Object.freeze(['sprinkler_system','smoke_detection','electrical_inspection']);
const specs = Object.freeze({
  construction: Object.freeze(['steel','masonry','timber','concrete']),
  occupancy: Object.freeze(['warehouse','office','light_industrial','hospitality']),
  exposure: Object.freeze(['low','moderate','high'])
});
function validateAsset(asset) {
  object(asset,'asset'); keys(asset,'asset',['asset_id','currency','sum_insured_aud','cope']); str(asset.asset_id,'asset.asset_id'); oneOf(asset.currency,'asset.currency',['AUD']);
  num(asset.sum_insured_aud,'asset.sum_insured_aud',1,1e12);
  object(asset.cope,'asset.cope'); keys(asset.cope,'asset.cope',['construction','occupancy','protection','exposure']);
  object(asset.cope.construction,'asset.cope.construction'); keys(asset.cope.construction,'asset.cope.construction',['primary_material']);
  oneOf(asset.cope.construction.primary_material,'asset.cope.construction.primary_material',specs.construction);
  object(asset.cope.occupancy,'asset.cope.occupancy'); keys(asset.cope.occupancy,'asset.cope.occupancy',['primary_use']);
  oneOf(asset.cope.occupancy.primary_use,'asset.cope.occupancy.primary_use',specs.occupancy);
  object(asset.cope.exposure,'asset.cope.exposure'); keys(asset.cope.exposure,'asset.cope.exposure',['external_fire_hazard']);
  oneOf(asset.cope.exposure.external_fire_hazard,'asset.cope.exposure.external_fire_hazard',specs.exposure);
  object(asset.cope.protection,'asset.cope.protection'); keys(asset.cope.protection,'asset.cope.protection',['declared_controls']);
  object(asset.cope.protection.declared_controls,'asset.cope.protection.declared_controls'); keys(asset.cope.protection.declared_controls,'asset.cope.protection.declared_controls',controlNames);
  for (const name of controlNames) {
    const v = asset.cope.protection.declared_controls[name];
    if (v !== null && v !== true && v !== false) fail(`asset.cope.protection.declared_controls.${name}`,'expected true, false or null');
  }
  return asset;
}
function validateEvidence(evidence) {
  object(evidence,'evidence'); keys(evidence,'evidence',['evidence_id','asset_id','predicate','value','issuer_id','method','observed_at','valid_until','digest_sha256','signature_b64']);
  for (const k of ['evidence_id','asset_id','predicate','issuer_id','method']) str(evidence[k],`evidence.${k}`);
  if (typeof evidence.value !== 'boolean') fail('evidence.value','expected boolean');
  if (!controlNames.map(c => `control.${c}.operational`).includes(evidence.predicate)) fail('evidence.predicate','unsupported control predicate');
  oneOf(evidence.method,'evidence.method',['inspection','sensor','self_declaration']);
  time(evidence.observed_at,'evidence.observed_at'); time(evidence.valid_until,'evidence.valid_until');
  if (Date.parse(evidence.valid_until) <= Date.parse(evidence.observed_at)) fail('evidence.valid_until','must be later than observed_at');
  if (evidence.digest_sha256 !== undefined && !/^[a-f0-9]{64}$/.test(evidence.digest_sha256)) fail('evidence.digest_sha256','expected sha256 hex');
  if (evidence.signature_b64 !== undefined) str(evidence.signature_b64,'evidence.signature_b64');
  return evidence;
}
function validateInput(input) {
  object(input,'input'); keys(input,'input',['asset','as_of','evidence']); validateAsset(input.asset); time(input.as_of,'input.as_of');
  if (!Array.isArray(input.evidence) || input.evidence.length > 1000) fail('input.evidence','expected array of at most 1000 records');
  const seen = new Set();
  for (const [i,item] of input.evidence.entries()) {
    validateEvidence(item);
    if (item.asset_id !== input.asset.asset_id) fail(`input.evidence[${i}].asset_id`,'does not match assessed asset');
    if (seen.has(item.evidence_id)) fail(`input.evidence[${i}].evidence_id`,'duplicate evidence ID');
    seen.add(item.evidence_id);
  }
  return input;
}
function validateRegistry(registry) {
  object(registry,'registry');
  for (const [issuer_id,entry] of Object.entries(registry)) {
    str(issuer_id,'registry issuer ID'); object(entry,`registry.${issuer_id}`);
    str(entry.public_key_pem,`registry.${issuer_id}.public_key_pem`);
    if (!Array.isArray(entry.accepted_methods) || entry.accepted_methods.some(m => !['inspection','sensor'].includes(m)))
      fail(`registry.${issuer_id}.accepted_methods`,'expected array of inspection/sensor methods');
  }
  return registry;
}
module.exports={ValidationError,validateAsset,validateEvidence,validateInput,validateRegistry,controlNames};
