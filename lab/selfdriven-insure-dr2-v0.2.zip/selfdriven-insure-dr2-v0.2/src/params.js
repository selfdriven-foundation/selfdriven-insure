'use strict';
const {LINES} = require('./lines');
const {NA} = require('./validate');

// A parameter set is the ONLY source of numbers the engine may use. It is supplied by the
// operator, pinned by hash in every output, and carries its own calibration status.
class ParameterSetError extends Error { constructor(m) { super(m); this.name = 'ParameterSetError'; } }
const bad = m => { throw new ParameterSetError(`parameter_set: ${m}`); };
const posNum = (x, p, max = 1e12) => { if (typeof x !== 'number' || !Number.isFinite(x) || x <= 0 || x > max) bad(`${p} must be a finite number in (0, ${max}]`); };

const UNITS = {annual: ['per_year'], per_trip: ['per_trip', 'per_trip_day']};
const BASIS_FOR = {sum_insured: 'share_of_exposure', limit: 'amount', insured_annual_amount: 'duration_days'};

function factorLabels(f) { return f.type === 'int' ? f.bands.map(b => b[1]) : f.values; }

function checkFactors(spec, list, p) {
  if (!Array.isArray(list)) bad(`${p} must be an array`);
  for (const f of list) {
    const def = spec.factors[f.factor];
    if (!def) bad(`${p}: unknown factor ${f.factor}`);
    if (!f.table || typeof f.table !== 'object') bad(`${p}.${f.factor}: table required`);
    for (const label of factorLabels(def)) { if (!Object.hasOwn(f.table, label)) bad(`${p}.${f.factor}: table has no entry for ${label}`); }
    for (const [k, v] of Object.entries(f.table)) {
      if (k !== NA && !factorLabels(def).includes(k)) bad(`${p}.${f.factor}: unexpected table entry ${k}`);
      posNum(v, `${p}.${f.factor}.${k}`, 100);
    }
  }
}
function checkControls(spec, list, p, targets) {
  if (!Array.isArray(list)) bad(`${p} must be an array`);
  if (new Set(list.map(c => c.control)).size !== list.length) bad(`${p}: a control is listed more than once`);
  for (const c of list) {
    if (!spec.controls.includes(c.control)) bad(`${p}: unknown control ${c.control}`);
    if (!targets.includes(c.target)) bad(`${p}.${c.control}: target must be one of ${targets.join(', ')}`);
    posNum(c.multiplier, `${p}.${c.control}.multiplier`, 1); // a control can never increase the modelled loss
    if (typeof c.effect_basis !== 'string' || !c.effect_basis) bad(`${p}.${c.control}: effect_basis (approved effect model reference) is required`);
  }
}

function validateParameterSet(ps) {
  if (!ps || typeof ps !== 'object') bad('expected object');
  for (const k of ['parameter_set_id', 'version']) if (typeof ps[k] !== 'string' || !ps[k]) bad(`${k} required`);
  if (!['synthetic_fixture', 'calibrated'].includes(ps.status)) bad('status must be synthetic_fixture or calibrated');
  if (!Array.isArray(ps.approvals)) bad('approvals must be an array');
  if (ps.status === 'calibrated' && (!ps.approvals.length || !ps.calibration || !ps.calibration.validation_report_ref)) bad('a calibrated set requires approvals and calibration.validation_report_ref');
  if (ps.currency !== 'AUD') bad('currency must be AUD');
  posNum(ps.trajectory_tolerance, 'trajectory_tolerance', 1);
  for (const [key, ev] of Object.entries(ps.events || {})) {
    const [line, peril] = key.split('.'), spec = LINES[line];
    if (!spec || !spec.perils.includes(peril)) bad(`events.${key}: not in the scope catalog`);
    if (!UNITS[spec.period_basis].includes(ev.unit)) bad(`events.${key}: unit ${ev.unit} is invalid for a ${spec.period_basis} line`);
    posNum(ev.base_rate, `events.${key}.base_rate`, 100);
    checkFactors(spec, ev.factors, `events.${key}.factors`);
    checkControls(spec, ev.controls, `events.${key}.controls`, ['frequency']);
  }
  for (const [key, c] of Object.entries(ps.components || {})) {
    const [line, coverage, peril] = key.split('.'), spec = LINES[line];
    if (!spec || !spec.matrix[coverage] || !spec.matrix[coverage].includes(peril)) bad(`components.${key}: not in the scope catalog`);
    if (!Object.hasOwn(ps.events, `${line}.${peril}`)) bad(`components.${key}: no event model ${line}.${peril}`);
    posNum(c.involvement_probability, `components.${key}.involvement_probability`, 1);
    const s = c.severity || bad(`components.${key}.severity required`);
    const expect = BASIS_FOR[spec.coverages[coverage].exposure];
    if (s.basis !== expect) bad(`components.${key}: severity basis must be ${expect} for this coverage`);
    posNum(s.base, `components.${key}.severity.base`, s.basis === 'share_of_exposure' ? 1 : 1e9); posNum(s.cv, `components.${key}.severity.cv`, 20);
    checkFactors(spec, s.factors, `components.${key}.severity.factors`);
    checkControls(spec, c.controls, `components.${key}.controls`, [s.basis === 'duration_days' ? 'duration' : 'conditional_severity']);
    // Structural guard against double-counting: one control, one mechanism per peril.
    const onEvent = ps.events[`${line}.${peril}`].controls.map(x => x.control);
    for (const x of c.controls) if (onEvent.includes(x.control)) bad(`components.${key}: control ${x.control} already acts on the ${peril} event frequency`);
  }
  for (const r of ps.insurability_rules || []) {
    const spec = LINES[r.line]; if (!spec) bad(`insurability rule ${r.id}: unknown line`);
    if (!['refer', 'information_required'].includes(r.outcome)) bad(`insurability rule ${r.id}: outcome must be refer or information_required (the engine never accepts or declines)`);
    if (r.when.factor && !spec.factors[r.when.factor]) bad(`insurability rule ${r.id}: unknown factor`);
    if (r.when.control && !spec.controls.includes(r.when.control)) bad(`insurability rule ${r.id}: unknown control`);
    if (!r.when.factor && !r.when.control) bad(`insurability rule ${r.id}: when.factor or when.control required`);
  }
  return ps;
}
module.exports = {ParameterSetError, validateParameterSet, factorLabels, BASIS_FOR};
