# selfdriven.insure — DR² v0.1 Technical Framework & Validation Specification

**Executable Reference Build — 23 October 2026**

This standalone document accompanies `selfdriven-insure-dr2-v0.1.zip`. It covers the executable model, evidence verification, validation programme and governance boundaries. The values and model coefficients are synthetic; this work is not authorised for underwriting or insurance pricing.

# DR² v0.1 — Executable Reference Specification

**Draft 0.1 — 23 October 2026**  
**Scope:** commercial property, fire/property damage only  
**Status:** exploratory, unvalidated, synthetic

## 1. Purpose

This is the first executable slice of the wider selfdriven.insure **Dynamic Risk & Resilience (DR²)** specification. It preserves property COPE classifications and separates three independently reviewable quantities:

1. The asset's COPE characteristics, including declared protection features.
2. Independently submitted evidence that a specific control is operational.
3. The *modelled* impact, for a given peril, of controls whose evidence meets a configured acceptance policy.

This stage **does not** assert that the computed values are calibrated representations of any actual Australian property insurance portfolio. Computation and evidence verification can be proven correct while predictions are still wrong.

## 2. Canonical objects

### Asset

Each asset has `asset_id`, `currency=AUD`, `sum_insured_aud`, and a `cope` object:

| COPE group | v0.1 required attribute | Allowed values |
|---|---|---|
| Construction | `primary_material` | steel, masonry, timber, concrete |
| Occupancy | `primary_use` | warehouse, office, light_industrial, hospitality |
| Protection | `declared_controls` | three Boolean-or-null fields |
| Exposure | `external_fire_hazard` | low, moderate, high |

`null` means unknown, **not** that the protection does not exist. The narrow vocabulary is a reference implementation convenience. Future vocabularies need explicit versioning and jurisdictional alignment rather than silently changing the meaning of fields.

### Evidence

An evidence assertion contains:

`evidence_id`, `asset_id`, `predicate`, `value`, `issuer_id`, `method`, `observed_at`, `valid_until` and optional `digest_sha256`, `signature_b64`.

The three v0.1 predicates are:

- `control.sprinkler_system.operational`
- `control.smoke_detection.operational`
- `control.electrical_inspection.operational`

The **entire submitted payload excluding digest and signature** is signed using Ed25519 over the v0.1 sorted-key JSON string encoding. `digest_sha256` is the hex SHA-256 of the same canonical payload.

This implementation's encoding is **not RFC 8785 JCS** and is not guaranteed portable to other programming languages. For multi-language deployments, explicitly adopt and test a standards-based cross-runtime canonicalisation format with conformance vectors.

An `issuer_id` is only trusted if its public key and accepted inspection method were provisioned **out of band** in the trust registry. A record is eligible only if:

- The issuer exists as an own entry in the registry.
- The payload digest matches.
- The Ed25519 signature validates.
- The issuer's policy accepts the attestation method (`inspection` or `sensor`).
- `observed_at <= as_of < valid_until`.
- The assertion is not contradicted by another eligible assertion for the same control.
- A COPE `false` declaration does not contradict a signed `true` control statement.

Actual inspection accreditation, key ownership, physical inspection validity, replay attacks, certificate chains and key revocation are **not** addressed by this local prototype.

### Control state

`unknown`, `disputed`, `verified_true`, or `verified_false`.

- `verified_true`: control eligible for mitigation credit **under the configured demonstration policy**.
- `verified_false`: eligible evidence supports that the control is not operational; no credit.
- `unknown`: no eligible evidence; no credit but no assertion that the control is absent.
- `disputed`: eligible conflicting evidence, or a true attestation conflicting with a false COPE declaration; no credit.

The use of `verified` refers strictly to authenticated qualifying evidence within this prototype, **not** proof of actual control effectiveness.

## 3. Reference fire risk calculation

For steel/warehouse/moderate external hazard:

- Base probability of one fire property-damage claim in a year = `0.015`.
- Base conditional mean severity = `20% × sum_insured`.

Other classes use the factors below, all **illustrative**:

| Factor | Construction frequency | Construction severity |
|---|---:|---:|
| Steel | 1.00 | 1.00 |
| Masonry | 0.85 | 0.90 |
| Timber | 1.40 | 1.25 |
| Concrete | 0.75 | 0.80 |

| Occupancy | Frequency factor |
|---|---:|
| Warehouse | 1.00 |
| Office | 0.65 |
| Light industrial | 1.30 |
| Hospitality | 1.50 |

| External fire hazard | Frequency factor |
|---|---:|
| Low | 0.80 |
| Moderate | 1.00 |
| High | 1.40 |

Let:

`p0 = min(1, 0.015 × C_frequency × O_frequency × E_frequency)`

`mu0 = min(sum_insured_aud, 0.20 × sum_insured_aud × C_severity)`

`EAL0 = p0 × mu0`

Then independently authenticated **operational-control** indicators in the demonstration model apply:

| Control | Conditional effect | Illustrative reduction |
|---|---|---:|
| Sprinklers | Conditional mean severity | 45% |
| Smoke detection | Conditional mean severity | 15% |
| Electrical inspection | Fire claim probability | 20% |

`p1 = p0 × (0.8 if electrical inspection eligible else 1)`

`mu1 = mu0 × (0.55 if sprinklers eligible else 1) × (0.85 if smoke detection eligible else 1)`

`EAL1 = p1 × mu1`

`EAL_reduction = EAL0 − EAL1`

**Important:** this model uses Bernoulli single-claim probability, *not* a Poisson count-rate interpretation, so `EAL = p × mu` is valid for the defined single-event toy model. It is not a frequency model suitable for general commercial property claims, multiple events, catastrophe clustering, inflation, policy limits, deductibles, reinstatement, sublimits or exposure period differences.

Synthetic control reductions are compounded multiplicatively for implementation convenience. Real controls interact; double-counting must be addressed in an actuarily calibrated implementation.

## 4. Assessment output contract

Every assessment includes:

- Stable `assessment_id` derived from assessment input and pinned model/policy hashes.
- `input_sha256`, `trust_registry_sha256`, `manifest_sha256`, `result_sha256`.
- Results for one peril and coverage with reference and residual risk.
- Control decision states, eligible evidence IDs, evidence verification result codes and discrepancies.
- Evidence coverage as the fraction of three control facts resolved by eligible attestations.
- Research-only model and underwriting status.
- `null` risk score and premium, with explicitly unquantified uncertainty.

Determinism is tested for the same semantic JSON property order, same evidence array order, same registry and same manifest on the same JavaScript runtime semantics. Array reordering is not normalised. Numerical canonicalisation is a project-specific convention and will require protocol hardening.

The assessment does not persist or disclose the entire input payload. Reproduction requires lawful access to the original input, policy registry and model version.

## 5. Validation requirements

See `VALIDATION-PLAN.md` for evidence, software and actuarial separation.

The model MUST produce the following examples:

| Scenario | Reference EAL | Residual EAL | Expected effect |
|---|---:|---:|---|
| No qualifying evidence | 3000 | 3000 | Declared protection gives no credit |
| Eligible sprinklers only | 3000 | 1650 | Severity ×0.55 |
| Eligible smoke only | 3000 | 2550 | Severity ×0.85 |
| Eligible electrical inspection only | 3000 | 2400 | Frequency ×0.80 |
| Three eligible controls | 3000 | 1122 | Multiplicative modifiers |
| Expired or forged sprinkler evidence | 3000 | 3000 | No credit |
| Conflicting eligible sprinkler attestations | 3000 | 3000 | Disputed/no credit |

All numbers are AUD/year expected-loss *illustrations*, not premium prices.

## 6. Interface

`assess(input, {trustRegistry}) -> result`

`replayCheck(input, registry, previousResult) -> {matches, calculated_hash, previous_hash}`

`signEvidence(unsignedEvidence, privateKey) -> signedEvidence` is provided for development and test utilities only. Production issuers must sign outside the insurer's calculation service, with appropriate identity governance and key custody.

Loopback-only development server:

- `GET /health`
- `GET /v1/models/fire/manifest`
- `POST /v1/assessments`

For the POST, the trust registry must be preconfigured by the operator, never supplied as a caller-chosen trust policy.

## 7. Next feature boundary

Do not promote v0.1 scores into underwriting pricing. First implement storage and issuer policy lifecycle, choose a claims-linked outcome dataset, estimate and validate real peril factors, then add time effects and uncertainty. Future DR² implementations can add resilience, recovery, trajectory and insurability as distinct services rather than forcing these ideas into the fire model.


---

# DR² Validation & Calibration Plan — v0.1

## Validation has three distinct layers

1. **Software conformance:** The code implements the stated rules and is replayable.
2. **Evidence assurance:** Assertions are authentic, current, relevant and supported by appropriately qualified issuers.
3. **Actuarial and practical validation:** The loss predictions and control benefits generalise to real risks and lead to defensible underwriting decisions.

Passing one layer does **not** imply passing the others.

## Gate A — Software verification (included in this package)

- Test correct COPE input types, enums, protected null semantics and date validity.
- Assert the fire calculation, frequency vs severity effects and unit consistency.
- Ensure unverified, forged, stale, contradictory or out-of-scope assertions do not earn mitigation credit.
- Confirm that model and registry changes affect reproducibility fingerprints.
- Confirm that same accepted input yields the same result digest.
- Confirm `risk_score` and `premium` remain null rather than inventing calibration.
- Target: all automated tests passing; no critical/major uncaught defects; a second reviewer reproduces baseline test values from the written equations.

**Current state:** 67 automated tests executed successfully at preparation; report `test-run.txt`.

## Gate B — Evidence assurance (not complete)

Controlled research protocol:

- Define issuer verification/accreditation requirements and minimum inspection scopes.
- Specify cryptographic key enrolment, rotation, expiration, revocation and compromise handling.
- Establish authentic evidence capture from inspectors or instrumented systems.
- Define conflicting observations, remediation and challenge/correction workflows.
- Measure agreement between digital attestations and blinded physical re-inspections.
- Test timeliness and expiry for the expected deterioration rate of each control.
- Quantify false-positive/false-negative rates for attestation validity where observable.

Output: documented trust policy, independent audit and source-specific error estimates.

## Gate C — Statistical validation (not complete)

Pre-register the following before examining holdout outcomes:

**Population and target**

- Define commercial property business classes, Australian geographies, policy coverage and annual observation periods.
- Define claims inclusion/exclusion rules, notification-to-payment maturity and development adjustments.
- Define exposure denominators and cancellation/partial-year effects.

**Data protection**

- Formal permission for claims and underwriting data use.
- De-identify or minimise personal data and link data using governed pseudonymous keys.
- Protect test period integrity and prevent target leakage from claims-derived inspections.
- Reconstruct source timestamps and historical validity to avoid look-ahead bias.

**Benchmarks and experiments**

- Model 0: incumbent COPE-based underwriting or benchmark frequency-severity model.
- Model 1: COPE plus condition/inspection fields.
- Model 2: COPE plus authenticated operational controls.
- Model 3: time-varying evidence/trajectory, *only if history is available*.

Evaluate on out-of-time and, where feasible, out-of-entity/region holdouts.

**Statistical tests**

- Claims frequency calibration by rating segment and peril.
- Conditional severity calibration and tail sensitivity.
- Observed/expected loss ratio with uncertainty intervals.
- Proper scoring measures suited to the fitted distribution (e.g. deviance, log likelihood).
- Interval coverage and error under rare/peril-specific events.
- Stability across construction, occupancy, location, sum-insured and evidence-quality subgroups.
- Bootstrap confidence intervals for improvement relative to baseline.
- Calibration drift and operational drift monitoring.

Set acceptance thresholds based on data power and insurer materiality **before** holdout evaluation. An arbitrary fixed percentage improvement would be scientifically inappropriate without a dataset.

**Mitigation causal challenge**

There is selection bias: well-run organisations both install controls and have other lower-risk characteristics. Do not infer a causal 45% sprinkler severity reduction from correlation alone. Use engineering studies, credible actuarial studies and/or quasi-experimental designs with sensitivity analysis, plus qualified expert challenge.

**Insurance pricing boundary**

Even a validated EAL model is not a final premium: catastrophe capital, expenses, reinsurance, margins, policy terms and legal/fairness governance belong to a separately approved pricing process.

## Gate D — Shadow underwriting (not complete)

- Run scoring in parallel with live underwriting, without decision impact.
- Compare referral rates, explanations and control disputes.
- Log insurer expert review, corrections, model limitations and operational incidents.
- Require independent actuarial validation and accountable model approval.
- Publish limitations and establish rollback criteria.

## Gate E — Controlled operational pilot (not complete)

Deploy only after real-data evaluation, security assessment, privacy governance, actuarial approval, contractual authority and the appropriate insurance regulatory review.

## Additional acceptance criteria for the next build

- Fully versioned asset/evidence/issuer model with durable records.
- Replay bundles containing source hashes and approved model artifacts.
- Cross-language canonical encoding specification and test vectors.
- Issuer registration/revocation and dispute workflows.
- Formal threat modelling, security tests and signed audit logs.
- Historical cohort study with defensible uncertainty estimates.


---

# DR² v0.1 — Security, Trust and Product Limitations

## Trust boundaries

1. **Insured declarations:** Unverified statements of protection presence; do not receive credit.
2. **Issuer identity:** Ed25519 public keys provisioned in a local trust registry. The prototype does not perform accreditation, identity proofing, custody evaluation or revocation.
3. **Issuer assertions:** Signatures authenticate that the holder of a registered key signed the payload; they do **not** prove the inspection happened or was accurate.
4. **Decision policy:** The server/operator chooses trusted issuers and methods, not the assessment caller.
5. **Models:** Fire model constants are fixed and hashed but have not been fitted to claims experience.
6. **Output:** A content hash makes changes detectable under the declared encoding, but does not itself create an append-only audit trail or signed authoritative assessment.

## Important known gaps

- No strong user or tenant authentication and no per-asset authorisation.
- Development HTTP server is for localhost only and does not terminate TLS.
- No durable storage, audit log, data retention or recovery system.
- No hardware-backed signing keys, PKI, signing-time proof or revocation checks.
- No detection of compromised-but-still-trusted inspector keys.
- No re-inspection process when genuine sources provide incorrect data.
- No externally verified geo-hazard or property identity mapping.
- No anti-replay challenge beyond evidence identity and validity dates within one assessment input.
- No claims-based actuarial validity, underwriting approvals, pricing guardrails or regulated product disclosures.
- Custom canonicalisation, pending stronger interoperable standard and test vectors.
- No comprehensive numerical stability testing for all runtimes, policies and currencies.

## Suggested pre-production controls

- Operate behind authenticated APIs and tenant-scoped authorisation.
- Enrol approved issuers using independently checked identity and inspection qualifications.
- Use protected signing keys; define revocation, rollover and compromise response.
- Keep signed and independently timestamped issuer statements and immutable assessment records.
- Have a separate human process for conflicting/appealed assessments.
- Implement ingestion-size limits, abuse controls, logging and secure request processing.
- Run privacy, cyber security, penetration testing and appropriate insurer model reviews.
- Never turn unvalidated mitigation multipliers into actual premium credits.

## Advisory

The reference is supplied as a research artifact and contains no real policy, personal or insurance customer data. The generated mock keys are deliberately ephemeral and cannot be treated as any real organisation's credential. It must not be publicly deployed or used for commercial underwriting without substantive further work.


---

# DR² v0.1 — Requirements Traceability

This table describes verifiable requirements for the v0.1 research MVP. The automated test cases can be located by searching their descriptive names in `test/engine.test.js` and `test/server.test.js`.

| ID | Requirement | Implementation | Acceptance evidence |
|---|---|---|---|
| R-01 | Represent COPE groups explicitly | `schemas/asset.schema.json`, `src/validate.js` | Schema checks and invalid-class tests |
| R-02 | Distinguish missing protection from false | `declared_controls` and `src/evidence.js` | Unknown controls; null declaration tests |
| R-03 | Support peril-specific fire EAL | `src/model-fire.js` | Baseline and COPE multiplier tests |
| R-04 | Separate frequency and severity controls | `src/model-fire.js` | Individual control effect tests |
| R-05 | Require authenticated evidence for credit | `src/canonical.js`, `src/evidence.js` | Signed vs unsigned tests |
| R-06 | Enforce issuer/method trust policy | `src/evidence.js` | Untrusted issuer and method tests |
| R-07 | Reject stale/future evidence | `src/evidence.js` | Expiry and future observation tests |
| R-08 | Flag inconsistent assertions | `src/evidence.js` | Contradictory verified attestations |
| R-09 | Prevent unvalidated pricing decisions | `src/assess.js` | Null premium and underwriting status |
| R-10 | Preserve model and registry fingerprints | `src/assess.js`, `src/model-fire.js` | Manifest and registry hash tests |
| R-11 | Support deterministic replay | `src/canonical.js`, `src/assess.js` | Replay match/tampering tests |
| R-12 | Expose development API | `src/server.js` | API health, manifest, assessment, 4xx tests |
| R-13 | Strictly validate input classes and dates | `src/validate.js` | Type, unknown field and malformed dates |
| R-14 | Supply reproducible synthetic worked example | `scripts/demo.js` | Three controls AUD 1,122 and replay true |

## Definition of done

- All tests pass on Node 20+ without downloading dependencies.
- Baseline reference result is AUD 3,000 EAL for the supplied asset.
- The mock signed three-control scenario produces AUD 1,122 EAL.
- Untrusted, expired, forged or disputed controls receive no risk reduction.
- No insurance premium or customer risk grade is returned.
- A third party can reproduce the source calculations from `REFERENCE-SPEC.md`.

## Exclusions

Actuarial correctness, real-world attester identity, operational security, deployed multi-tenant authorization, historical pricing calibration, model governance approval and customer suitability are **not** certified by passing these tests.
