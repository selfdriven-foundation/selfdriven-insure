#!/usr/bin/env node
'use strict';
// Builds params/synthetic-fixture-v0.2.json.
//
// EVERY NUMBER IN THIS FILE IS INVENTED. It exists so the engine, tests and examples have
// something to execute. None of it is estimated from claims, engineering or hazard data,
// and none of it may be used for underwriting, pricing or customer-facing scores.
const fs = require('node:fs');
const path = require('node:path');
const {validateParameterSet} = require('../src/params');

const BASIS = 'SYNTHETIC-FIXTURE-NO-EMPIRICAL-BASIS';
const F = (factor, table) => ({factor, table});
const C = (control, target, multiplier) => ({control, target, multiplier, effect_basis: BASIS});
const event = (unit, base_rate, factors = [], controls = [], extra = {}) => ({unit, base_rate, factors, controls, ...extra});
const comp = (involvement_probability, basis, base, cv, factors = [], controls = []) => ({involvement_probability, severity: {basis, base, cv, factors}, controls});
const share = (inv, base, cv, f, c) => comp(inv, 'share_of_exposure', base, cv, f, c);
const amount = (inv, base, cv, f, c) => comp(inv, 'amount', base, cv, f, c);
const days = (inv, base, cv, f, c) => comp(inv, 'duration_days', base, cv, f, c);

const hazard4 = (a, b, c, d) => ({low: a, moderate: b, high: c, extreme: d});
const hazard3 = (a, b, c) => ({low: a, moderate: b, high: c});
const wind = {non_cyclonic: 1, intermediate: 1.3, cyclonic: 2.2, severe_cyclonic: 3};
const year = (a, b, c, d) => ({pre_1960: a, y1960_1989: b, y1990_2009: c, y2010_plus: d});
const flood = F('exposure.flood_hazard_class', hazard4(0.1, 1, 5, 15));
const bushfire = F('exposure.bushfire_hazard_class', hazard4(0.2, 1, 4, 10));

const events = {}, components = {};

// ---- Home & contents -------------------------------------------------------------------
const occ = (a, b, c, d) => ({owner_occupied: a, tenanted: b, holiday_home: c, unoccupied: d});
const wall = (a, b, c, d, e) => ({double_brick: a, brick_veneer: b, weatherboard: c, fibre_cement: d, concrete: e});
const roof = F('construction.roof_material', {tile: 1.1, metal: 0.9, other: 1.2});
Object.assign(events, {
  'home_contents.fire': event('per_year', 0.003, [F('construction.wall_material', wall(0.85, 1, 1.3, 1.1, 0.8)), F('construction.year_built_band', year(1.3, 1.1, 1, 0.9)), F('occupancy.occupancy_type', occ(1, 1.15, 1.1, 1.5))]),
  'home_contents.bushfire': event('per_year', 0.0005, [bushfire]),
  'home_contents.storm': event('per_year', 0.02, [F('exposure.wind_region', wind), F('construction.roof_condition', {good: 0.85, fair: 1, poor: 1.6})], [C('roof_maintenance', 'frequency', 0.9)]),
  'home_contents.flood': event('per_year', 0.004, [flood]),
  'home_contents.escape_of_liquid': event('per_year', 0.03, [F('construction.year_built_band', year(1.3, 1.15, 1, 0.85)), F('occupancy.dwelling_type', {house: 1, townhouse: 1.05, unit: 1.2})], [C('flexi_hose_replacement', 'frequency', 0.85)]),
  'home_contents.theft': event('per_year', 0.015, [F('exposure.theft_hazard_class', hazard3(0.6, 1, 1.8)), F('occupancy.occupancy_type', occ(1, 1.2, 1.4, 1.6))], [C('deadlocks_window_locks', 'frequency', 0.85), C('monitored_alarm', 'frequency', 0.8)])
});
Object.assign(components, {
  'home_contents.building.fire': share(1, 0.15, 2.5, [F('construction.wall_material', wall(0.9, 1, 1.25, 1.1, 0.85))], [C('smoke_alarms', 'conditional_severity', 0.9)]),
  'home_contents.contents.fire': share(0.9, 0.2, 2, [], [C('smoke_alarms', 'conditional_severity', 0.9)]),
  'home_contents.building.bushfire': share(1, 0.5, 1.2, [roof], [C('ember_protection', 'conditional_severity', 0.8)]),
  'home_contents.contents.bushfire': share(0.95, 0.55, 1.2, [], [C('ember_protection', 'conditional_severity', 0.8)]),
  'home_contents.building.storm': share(1, 0.02, 3, [roof]),
  'home_contents.contents.storm': share(0.3, 0.03, 2.5),
  'home_contents.building.flood': share(1, 0.12, 1.5, [F('occupancy.dwelling_type', {house: 1, townhouse: 0.9, unit: 0.5})]),
  'home_contents.contents.flood': share(0.9, 0.25, 1.3),
  'home_contents.building.escape_of_liquid': share(1, 0.012, 2, [], [C('leak_detection_shutoff', 'conditional_severity', 0.7)]),
  'home_contents.contents.escape_of_liquid': share(0.5, 0.03, 1.8, [], [C('leak_detection_shutoff', 'conditional_severity', 0.7)]),
  'home_contents.contents.theft': share(1, 0.06, 1.5)
});

// ---- Strata (common property) ------------------------------------------------------------
const storeys = (a, b, c) => ({low_rise_1_3: a, mid_rise_4_8: b, high_rise_9_plus: c});
const lots = (a, b, c, d) => ({l2_10: a, l11_50: b, l51_150: c, l151_plus: d});
const cladding = F('construction.external_cladding', {non_combustible: 1, combustible_remediated: 1.1, combustible_present: 2.5});
const defects = (a, b, c) => ({none_reported: a, minor: b, major_unrectified: c});
Object.assign(events, {
  'strata.fire': event('per_year', 0.01, [F('construction.frame_material', {concrete: 0.8, masonry: 0.9, steel: 1, timber: 1.4}), F('occupancy.use_mix', {residential: 1, mixed_use_retail: 1.2, mixed_use_hospitality: 1.6}), F('occupancy.lots_band', lots(0.7, 1, 1.5, 2.2)), F('occupancy.short_stay_share', hazard3(1, 1.1, 1.25))], [C('annual_fire_safety_statement', 'frequency', 0.9)]),
  'strata.bushfire': event('per_year', 0.0005, [bushfire]),
  'strata.storm': event('per_year', 0.05, [F('exposure.wind_region', wind), F('construction.storeys_band', storeys(1, 1.1, 1.25))], [C('roof_membrane_maintenance', 'frequency', 0.9)]),
  'strata.flood': event('per_year', 0.004, [flood]),
  'strata.escape_of_liquid': event('per_year', 0.25, [F('occupancy.lots_band', lots(0.4, 1, 2.5, 5)), F('construction.year_built_band', year(1.3, 1.15, 1, 0.9)), F('construction.known_defects', defects(1, 1.2, 1.8))], [C('plumbing_maintenance_program', 'frequency', 0.85)])
});
Object.assign(components, {
  'strata.common_property_building.fire': share(1, 0.03, 3.5, [cladding, F('construction.storeys_band', storeys(1, 1.2, 1.5))], [C('sprinkler_system', 'conditional_severity', 0.55)]),
  'strata.common_contents.fire': share(0.5, 0.1, 2, [], [C('sprinkler_system', 'conditional_severity', 0.6)]),
  'strata.common_property_building.bushfire': share(1, 0.3, 1.3, [cladding]),
  'strata.common_property_building.storm': share(1, 0.004, 3, [F('construction.known_defects', defects(1, 1.3, 2))]),
  'strata.common_contents.storm': share(0.2, 0.03, 2),
  'strata.common_property_building.flood': share(1, 0.05, 1.5, [F('construction.storeys_band', storeys(1, 0.6, 0.35))]),
  'strata.common_contents.flood': share(0.8, 0.2, 1.3),
  'strata.common_property_building.escape_of_liquid': share(1, 0.0015, 2.5, [F('construction.storeys_band', storeys(1, 1.3, 1.6))], [C('leak_detection_shutoff', 'conditional_severity', 0.7)]),
  'strata.common_contents.escape_of_liquid': share(0.3, 0.02, 2, [], [C('leak_detection_shutoff', 'conditional_severity', 0.7)])
});

// ---- SME ---------------------------------------------------------------------------------
// The fire event and the three v0.1 controls reuse the v0.1 synthetic multipliers.
const use = (a, b, c, d, e) => ({warehouse: a, office: b, light_industrial: c, hospitality: d, retail: e});
const eps = F('construction.eps_panel', {none: 1, present: 1.8});
const altPremises = F('operations.alternative_premises', {available: 0.7, not_available: 1.2, not_applicable: 1});
const supplier = F('operations.supplier_concentration', {low: 0.95, moderate: 1, high: 1.15, not_applicable: 1});
const bcp = [C('business_continuity_plan_tested', 'duration', 0.8)];
Object.assign(events, {
  'sme.fire': event('per_year', 0.015, [F('construction.primary_material', {steel: 1, masonry: 0.85, timber: 1.4, concrete: 0.75}), F('occupancy.primary_use', use(1, 0.65, 1.3, 1.5, 0.9)), F('exposure.external_fire_hazard', hazard3(0.8, 1, 1.4))], [C('electrical_inspection', 'frequency', 0.8)]),
  'sme.storm': event('per_year', 0.03, [F('exposure.wind_region', wind), F('construction.primary_material', {steel: 1.1, masonry: 0.9, timber: 1.2, concrete: 0.8})]),
  'sme.flood': event('per_year', 0.005, [flood]),
  'sme.escape_of_liquid': event('per_year', 0.04, [F('occupancy.primary_use', use(0.8, 1, 1, 1.5, 1))]),
  'sme.theft': event('per_year', 0.04, [F('exposure.theft_hazard_class', hazard3(0.6, 1, 1.8)), F('occupancy.primary_use', use(1.2, 0.7, 1, 1.1, 1.5))], [C('monitored_intruder_alarm', 'frequency', 0.75)])
});
Object.assign(components, {
  'sme.buildings.fire': share(1, 0.2, 2.5, [F('construction.primary_material', {steel: 1, masonry: 0.9, timber: 1.25, concrete: 0.8}), eps], [C('sprinkler_system', 'conditional_severity', 0.55), C('smoke_detection', 'conditional_severity', 0.85)]),
  'sme.contents.fire': share(0.9, 0.3, 2, [eps], [C('sprinkler_system', 'conditional_severity', 0.6), C('smoke_detection', 'conditional_severity', 0.85)]),
  'sme.buildings.storm': share(1, 0.02, 3), 'sme.contents.storm': share(0.3, 0.04, 2.5),
  'sme.buildings.flood': share(1, 0.1, 1.5), 'sme.contents.flood': share(0.9, 0.3, 1.3),
  'sme.buildings.escape_of_liquid': share(1, 0.01, 2), 'sme.contents.escape_of_liquid': share(0.6, 0.03, 2),
  'sme.contents.theft': share(1, 0.05, 1.5)
});
for (const cov of ['business_interruption', 'loss_of_profits']) Object.assign(components, {
  [`sme.${cov}.fire`]: days(0.6, 60, 1.5, [altPremises, supplier], bcp),
  [`sme.${cov}.storm`]: days(0.3, 15, 1.5, [altPremises], bcp),
  [`sme.${cov}.flood`]: days(0.7, 30, 1.3, [altPremises, supplier], bcp)
});

// ---- Travel (per trip) -------------------------------------------------------------------
const disruption = t => F('trip.destination_disruption_band', t);
const mode = t => F('trip.mode', t);
Object.assign(events, {
  'travel.illness_injury': event('per_trip_day', 0.002, [F('trip.activities', {standard: 1, snow_sports: 1.8, adventure: 2.2}), mode({land_air: 1, cruise: 1.3})], [], {per_traveller: true}),
  'travel.cancellation_cause': event('per_trip', 0.04, [F('trip.lead_days', {l0_7: 0.4, l8_30: 0.7, l31_90: 1, l91_plus: 1.4}), disruption(hazard3(0.9, 1, 1.4)), F('trip.travellers', {t1: 1, t2: 1.15, t3_5: 1.4, t6_plus: 1.8})]),
  'travel.baggage_incident': event('per_trip_day', 0.0015, [mode({land_air: 1, cruise: 0.8})], [], {per_traveller: true}),
  'travel.transport_delay': event('per_trip', 0.05, [disruption(hazard3(0.8, 1, 1.5)), F('trip.duration_days', {d1_7: 0.8, d8_14: 1, d15_30: 1.2, d31_90: 1.5, d91_365: 2})])
});
Object.assign(components, {
  'travel.overseas_medical.illness_injury': amount(1, 4000, 6, [F('trip.destination_medical_cost_band', {band_1: 0.5, band_2: 1, band_3: 2, band_4: 4}), mode({land_air: 1, cruise: 1.5})]),
  'travel.cancellation.cancellation_cause': share(1, 0.5, 1),
  'travel.luggage.baggage_incident': share(1, 0.08, 1.5),
  'travel.travel_delay.transport_delay': amount(1, 400, 1)
});

// ---- Cyber -------------------------------------------------------------------------------
const industry = (a, b, c, d, e, f) => ({professional_services: a, retail_ecommerce: b, healthcare: c, manufacturing: d, financial_services: e, other: f});
const revenue = (a, b, c, d) => ({under_2m: a, r2m_10m: b, r10m_50m: c, r50m_plus: d});
const records = (a, b, c, d) => ({under_10k: a, r10k_100k: b, r100k_1m: c, over_1m: d});
const itDep = t => F('organisation.it_dependency', t);
const irPlan = C('incident_response_plan_tested', 'conditional_severity', 0.85);
Object.assign(events, {
  'cyber.ransomware': event('per_year', 0.03, [F('organisation.industry_class', industry(1, 1.1, 1.5, 1.3, 0.9, 1)), F('organisation.revenue_band', revenue(0.7, 1, 1.4, 1.8)), F('organisation.remote_access_exposure', {none: 0.7, managed: 1, internet_exposed: 2.5})],
    [C('mfa_remote_access', 'frequency', 0.6), C('edr_deployed', 'frequency', 0.7), C('patching_within_sla', 'frequency', 0.8), C('email_filtering', 'frequency', 0.9), C('security_awareness_training', 'frequency', 0.95)]),
  'cyber.business_email_compromise': event('per_year', 0.06, [F('organisation.payment_volume', hazard3(0.6, 1, 1.6)), F('organisation.revenue_band', revenue(0.8, 1, 1.3, 1.6))],
    [C('mfa_email', 'frequency', 0.5), C('email_filtering', 'frequency', 0.8), C('security_awareness_training', 'frequency', 0.9)]),
  'cyber.data_breach': event('per_year', 0.02, [F('organisation.industry_class', industry(1, 1.2, 1.6, 0.8, 1.3, 1)), F('organisation.records_band', records(0.6, 1, 1.5, 2.2))],
    [C('mfa_remote_access', 'frequency', 0.8), C('patching_within_sla', 'frequency', 0.8), C('edr_deployed', 'frequency', 0.85)]),
  'cyber.dependency_outage': event('per_year', 0.1, [itDep(hazard3(0.5, 1, 1.6))])
});
Object.assign(components, {
  'cyber.incident_response.ransomware': amount(1, 40000, 1.5, [F('organisation.revenue_band', revenue(0.5, 1, 2, 4))], [irPlan]),
  'cyber.incident_response.business_email_compromise': amount(0.7, 8000, 1.2, [F('organisation.revenue_band', revenue(0.7, 1, 1.5, 2))]),
  'cyber.incident_response.data_breach': amount(1, 30000, 2, [F('organisation.records_band', records(0.4, 1, 2.5, 6))], [irPlan]),
  'cyber.cyber_business_interruption.ransomware': days(0.8, 10, 1.5, [itDep(hazard3(0.5, 1, 1.5))], [C('offline_backups_tested', 'duration', 0.5), C('incident_response_plan_tested', 'duration', 0.85)]),
  'cyber.cyber_business_interruption.dependency_outage': days(0.5, 1.5, 1.5, [itDep(hazard3(0.5, 1, 1.5))]),
  'cyber.data_restoration.ransomware': amount(0.8, 25000, 1.5, [F('organisation.revenue_band', revenue(0.5, 1, 2, 4))], [C('offline_backups_tested', 'conditional_severity', 0.6)]),
  'cyber.privacy_liability.data_breach': amount(0.3, 60000, 3, [F('organisation.records_band', records(0.4, 1, 2.5, 6))]),
  'cyber.funds_transfer_fraud.business_email_compromise': amount(0.5, 35000, 2, [F('organisation.payment_volume', hazard3(0.6, 1, 1.8))], [C('payment_callback_verification', 'conditional_severity', 0.4)])
});

// ---- Insurability constraints (placeholders for an insurer's own appetite rules) -----------
const RB = 'ILLUSTRATIVE-PLACEHOLDER-INSURER-TO-DEFINE';
const rule = (id, line, when, outcome, reason) => ({id, line, when, outcome, reason, rule_basis: RB});
const insurability_rules = [
  rule('HC-01', 'home_contents', {factor: 'occupancy.occupancy_type', in: ['unoccupied']}, 'refer', 'Unoccupied dwelling'),
  rule('HC-02', 'home_contents', {factor: 'exposure.bushfire_hazard_class', in: ['extreme']}, 'refer', 'Extreme bushfire hazard class'),
  rule('HC-03', 'home_contents', {factor: 'exposure.flood_hazard_class', unknown: true}, 'information_required', 'Flood hazard class not established'),
  rule('ST-01', 'strata', {factor: 'construction.external_cladding', in: ['combustible_present']}, 'refer', 'Combustible cladding present and unremediated'),
  rule('ST-02', 'strata', {factor: 'construction.external_cladding', unknown: true}, 'information_required', 'Cladding status not established'),
  rule('ST-03', 'strata', {factor: 'construction.known_defects', in: ['major_unrectified']}, 'refer', 'Major unrectified building defects'),
  rule('SME-01', 'sme', {factor: 'construction.eps_panel', in: ['present']}, 'refer', 'Expanded polystyrene sandwich panel construction'),
  rule('SME-02', 'sme', {factor: 'exposure.flood_hazard_class', in: ['extreme']}, 'refer', 'Extreme flood hazard class'),
  rule('TR-01', 'travel', {factor: 'trip.advisory_level', in: ['level_3', 'level_4']}, 'refer', 'Destination under an elevated official travel advisory'),
  rule('TR-02', 'travel', {factor: 'trip.advisory_level', unknown: true}, 'information_required', 'Travel advisory level not established'),
  rule('CY-01', 'cyber', {factor: 'organisation.remote_access_exposure', in: ['internet_exposed']}, 'refer', 'Remote access exposed directly to the internet'),
  rule('CY-02', 'cyber', {control: 'mfa_remote_access', state_in: ['verified_false']}, 'refer', 'Eligible evidence that MFA on remote access is not operational'),
  rule('CY-03', 'cyber', {control: 'offline_backups_tested', state_in: ['unknown', 'verified_false', 'disputed']}, 'information_required', 'Tested offline backups not evidenced')
];

const parameterSet = {
  parameter_set_id: 'dr2-synthetic-fixture', version: '0.2.0', status: 'synthetic_fixture',
  notice: 'SYNTHETIC SOFTWARE FIXTURE. Every value is invented. Not actuarially calibrated. Not for underwriting, pricing or customer-facing use.',
  approvals: [], calibration: {data_ref: null, validation_report_ref: null},
  currency: 'AUD', trajectory_tolerance: 0.05,
  events, components, insurability_rules
};
validateParameterSet(parameterSet);
const out = path.join(__dirname, '..', 'params', 'synthetic-fixture-v0.2.json');
fs.writeFileSync(out, JSON.stringify(parameterSet, null, 1) + '\n');
console.log(`wrote ${out}: ${Object.keys(events).length} events, ${Object.keys(components).length} components, ${insurability_rules.length} rules`);
