# Change log

## 0.2.0 — 20 November 2026
- Generalised single commercial-property fire reference into agent skill.
- Added modules for home/contents, strata, SME property+BI/profits, travel and cyber.
- Introduced canonical multi-line risk profile, evidence, model manifest,
  assessment request/response schemas and example records.
- Defined peril-specific, per-period loss contracts and non-pricing test helpers.
- Added explicit separation of evidence, pricing, insurability, model validity.
- Added Australian governance/reference links, test scenarios and model-card template.

## Historical foundation 0.1 — 23 October 2026
- Property COPE and initial evidence-backed fire-peril research prototype.
