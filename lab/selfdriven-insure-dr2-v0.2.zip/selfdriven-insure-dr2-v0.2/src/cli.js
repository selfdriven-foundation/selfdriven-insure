#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const {assess} = require('./engine');
const {catalog} = require('./lines');
const {ValidationError} = require('./validate');

const args = process.argv.slice(2), flag = n => { const i = args.indexOf(n); return i < 0 ? null : args[i + 1]; };
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
if (args[0] === 'catalog') console.log(JSON.stringify(catalog(), null, 2));
else if (args[0] === 'assess' && args[1]) {
  try {
    const options = {};
    // No --params means no numbers: the engine answers model_unavailable rather than inventing any.
    if (flag('--params')) options.parameterSet = read(flag('--params'));
    if (flag('--trust')) options.trustPolicy = read(flag('--trust'));
    console.log(JSON.stringify(assess(read(args[1]), options), null, 2));
  } catch (err) {
    console.error(err instanceof ValidationError ? `Invalid input: ${err.message}` : err.message); process.exitCode = 1;
  }
} else {
  console.error('Usage:\n  node src/cli.js assess INPUT.json [--params PARAMETER_SET.json] [--trust TRUST_POLICY.json]\n  node src/cli.js catalog');
  process.exitCode = 2;
}
