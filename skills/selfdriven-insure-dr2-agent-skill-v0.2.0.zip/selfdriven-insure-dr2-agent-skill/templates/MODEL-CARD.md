# Model card — <line>/<coverage>/<peril>

- Model ID, version, author, owner, reviewer, date:
- Status: `research_only` / `calibrated` / `approved` / `retired`
- Jurisdiction, product, policy terms, coverage/peril definition:
- Subject, event/claim unit, exposure period, monetary basis:
- Target outcome and settlement transformation:
- Features and source provenance:
- Control mechanisms and reference condition:
- Data, sampling, missingness, observed population:
- Assumptions, uncertainty and correlations:
- Model form, fitting and validation metrics:
- Temporal holdout and benchmark comparison:
- Bias/fairness and privacy assessment:
- Stress/sensitivity tests, confidence limits:
- Limitations, drift monitoring, rollback:
- Approvals and mandatory human escalation:
