---
name: selfdriven-insure-dr2
version: 0.2.0
description: >-
  Engineer, validate, and explain evidence-backed insurance risk rating engines
  using selfdriven.insure Dynamic Risk & Resilience (DR²), traditional property
  COPE, peril/coverage-specific loss models, Verified Context Graph evidence,
  reproducible assessments, and line-specific underwriting constraints for
  Australian home and contents, strata, SME property and business interruption,
  travel, and cyber insurance. Use when agents are asked to design schemas,
  implement a rating service, create test fixtures, assess control evidence,
  build explainable risk scores, or validate modelling and underwriting boundaries.
---

# selfdriven.insure — DR² Agent Engineering Skill

## Mission

Build **evidence-verifiable, peril-specific, reproducible insurance risk engines**.
Preserve property **COPE** (Construction, Occupancy, Protection, Exposure) where
applicable. Extend it with **DR²** (Dynamic Risk & Resilience), separate evidence
quality from underlying hazard, and treat **insurability** as distinct from
expected loss, customer-facing score and underwriting eligibility.

This skill guides implementation. **No data, scores, probabilities or prices
in this package are actuarially calibrated**; it is not delegated underwriting
authority, a production rating algorithm, or legal advice.

## Mandatory engineering invariants

1. The canonical assessment unit is `(subject, coverage, peril, period, jurisdiction,
   policy_terms_version, model_version)`. Keep **loss-event** and **claim-payment**
   concepts separate; don't sum overlapping coverages without an allocation rule.
2. Keep four distinct outputs: **risk/loss**, **evidence and uncertainty**,
   **trajectory**, **insurability**. Presentation scores are optional and must
   be calibrated before being labelled as predictive.
3. **COPE applies to physical property** (home, strata, SME building/contents).
   Never force COPE onto travel or cyber. Use their specific context profiles.
4. Calculate peril/coverage-specific **frequency × conditional severity** only
   when units and assumptions make it valid. Travel is often **per trip**, not
   annual. Cyber incidents may have shared-cause event aggregation.
5. Assess mitigations by **named peril and loss mechanism**; no arbitrary
   universal weights. Verified controls have credit only under an explicit
   eligible-evidence policy, approved effect model and causal/empirical basis.
6. **Unknown ≠ false ≠ zero ≠ not applicable.** Expired, inconsistent or unsigned
   declarations must not silently become protective controls. Missing data may
   trigger confidence bounds, information requests or human referral.
7. A signature proves content integrity and key possession, **not factual truth,
   control efficacy or statistical calibration**. Use out-of-band trust anchors.
8. All assessment outputs must pin input snapshot hashes, policy terms, model
   manifest, parameter set, as-of time, source provenance and execution version.
9. No automatic binding, denial, cancellation, discriminatory decision or
   premium variation without an approved insurer workflow and legal review.
10. Handle personal and sensitive information with minimisation, lawful basis,
    access control and human review, particularly travel health information.
11. The agent must not fabricate actuarial coefficients, geography risk data,
    reinsurance loadings, loss history, regulatory approvals or evidence. If
    calibration is absent return `research_only` / `model_unavailable` / `refer`.
12. Distinguish source checks, code correctness, predictive validation,
    fairness testing and insurer governance; none substitutes for the others.

## Read the relevant material before implementation

Always read:
- `references/CORE-RISK-MODEL.md`
- `references/EVIDENCE-VCG.md`
- `references/ARCHITECTURE-API.md`
- `references/VALIDATION-ACCEPTANCE.md`
- `references/GOVERNANCE.md`

Then read exactly the requested lines:
- **Home & contents:** `references/LOB-HOME-CONTENTS.md`
- **Strata:** `references/LOB-STRATA.md`
- **SME buildings, contents, BI, loss of profits:** `references/LOB-SME.md`
- **Travel:** `references/LOB-TRAVEL.md`
- **Cyber:** `references/LOB-CYBER.md`

Use schemas and catalog: `assets/schemas/*.schema.json`,
`assets/catalogs/lob-catalog.json`. Use `references/V0.1-COMPATIBILITY.md` for
migration from the original commercial-property fire prototype.

## Agent execution workflow

### 1 — Scope and underwrite the question

Identify jurisdiction, intended insurer/technology-provider role, line,
product, coverage, named perils, per-risk exposure period, geographic scope,
policy wording, exclusions, limits, excesses, and decision use. State assumptions.
No comparison of scores across lines until the mapping is validated.

### 2 — Define canonical objects

Model: `Subject`, `RiskLocation`, `Coverage`, `PolicyTerms`, `Peril`,
`RiskFactor`, `Control`, `EvidenceAssertion`, `TrustPolicy`, `Dependency`,
`ModelManifest`, `AssessmentSnapshot`, `DecisionRecommendation`.

Keep building/contents ownership distinct, including strata common property vs
lot-owner contents. For SME, `business_interruption` and `loss_of_profits`
represent potentially overlapping **valuation bases**, not automatically two
additive claim streams.

### 3 — Define exact loss target per component

For each peril/coverage write: event definition; cause/trigger; exposure unit;
frequency model; severity basis; reporting delay; policy terms transformation;
conditional dependencies; uncertainty; calibration data; limitations.
Mark the effect of each control on *frequency*, *conditional severity*, or
*duration*, avoiding double-counting. Use `references/CORE-RISK-MODEL.md`.

### 4 — Capture and verify evidence

Create immutable assertions and trust policy: who issued which fact, observed
when, valid through when, by what method, content digest, signature if present,
and revocation/conflict state. Treat observation and assessment timestamps
separately. Apply evidence eligibility **before** risk effects. Do not accept
self-declared public keys as trust anchors.

### 5 — Implement a model adapter

Use the contract in `references/ARCHITECTURE-API.md`. Implement pure functions
where possible; identify stochastic seed, rounding, currency and timezone rules.
Return `model_unavailable` rather than a fabricated result when necessary.
Keep line adapters independent from evidence storage and presentation grades.

### 6 — Explain and assess uncertainty

Return factor-to-peril explanations and evidence refs, data freshness,
uncertainty intervals or an explicit `unquantified` label, and a clear trail of
human overrides. Do not apply an arbitrary generic "evidence multiplier" to
loss or premium.

### 7 — Test and validate

Use the line test matrix plus `references/VALIDATION-ACCEPTANCE.md`.
Run `python3 scripts/validate_bundle.py` and `node --test` from the package
root. Synthetic contract tests are **not** evidence of predictive performance.
Before production, require historical out-of-time actuarial validation,
underwriter review, privacy/fairness review and operational control approval.

### 8 — Deliver engineering outputs

For each task produce:
1. Scope and coverage/peril matrix.
2. Versioned schemas, mappings and example records.
3. Model card per coverage/peril, including reference/effect basis.
4. Reproducible source code / API contracts and test fixtures.
5. Evidence and provenance policy.
6. Calibration and validation report with blockers and sign-offs.
7. Implementation handover with known limitations and next actions.

## Agent stop / referral conditions

Return `requires_human_review` if medical underwriting consent/basis is unclear,
identity or ownership is disputed, covers overlap without allocation,
trust anchors are missing for claimed verification, policy terms are ambiguous,
model calibration is absent but pricing is requested, a proposed feature may be
unlawfully discriminatory, or an action would bind/decline/alter cover.

## Ready-made resources

- `assets/schemas/`: JSON Schema 2020-12 contracts (not a complete insurer policy ontology).
- `assets/examples/`: fictional example assessments for each line.
- `templates/`: model-card, test-plan, model-governance and build-plan templates.
- `src/reference-math.mjs`: minimal **non-pricing** arithmetic helpers.
- `test/`: contract and edge-case tests.
- `references/REGULATORY-REFERENCES.md`: authoritative Australian reference links,
  to be rechecked when deploying; the snapshot is dated November 2026.

**Completion standard:** A reproducible, evidence-linked risk assessment
prototype is acceptable; an uncalibrated "premium" or autonomous insurance
eligibility decision is not.
