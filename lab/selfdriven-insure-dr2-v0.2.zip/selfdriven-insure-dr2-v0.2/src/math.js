'use strict';
// Non-pricing arithmetic helpers. Nothing here is a calibrated assumption: every
// number that enters these functions comes from the pinned parameter set.

// Standard normal CDF, Abramowitz & Stegun 26.2.17 (absolute error < 7.5e-8).
function phi(x) {
  if (x === Infinity) return 1;
  if (x === -Infinity) return 0;
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989422804014327 * Math.exp(-x * x / 2);
  const p = d * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  return x >= 0 ? 1 - p : p;
}

// Lognormal severity described by its mean and coefficient of variation.
function lognormal(mean, cv) {
  if (!(mean > 0) || !(cv > 0)) throw new RangeError('lognormal requires mean > 0 and cv > 0');
  const s2 = Math.log(1 + cv * cv), s = Math.sqrt(s2), mu = Math.log(mean) - s2 / 2;
  return {
    mean, cv,
    // Limited expected value E[min(X, u)].
    lev(u) {
      if (u <= 0) return 0;
      if (u === Infinity) return mean;
      const z = Math.log(u);
      return mean * phi((z - mu - s2) / s) + u * (1 - phi((z - mu) / s));
    },
    // P(X > d).
    exceed(d) { return d <= 0 ? 1 : 1 - phi((Math.log(d) - mu) / s); }
  };
}

// Per-event transformation from a ground-up loss X to a claim payment
//   payment = min( max( min(X, cap) - excess, 0 ), limit )
// cap   = natural ceiling of the loss (e.g. sum insured); Infinity when none
// limit = maximum payment per claim after excess; Infinity when none
function layer(dist, {cap = Infinity, excess = 0, limit = Infinity}) {
  const top = Math.min(cap, excess + limit);
  const gross = dist.lev(cap);
  const payment = top > excess ? dist.lev(top) - dist.lev(excess) : 0;
  const claimProbability = top > excess ? dist.exceed(excess) : 0;
  return {expected_gross_loss_per_event: gross, expected_payment_per_event: Math.max(0, payment),
    probability_event_becomes_claim: claimProbability};
}

// Stable output rounding so result hashes do not depend on trailing float noise.
const round = (x, dp = 6) => { if (x === null || x === undefined) return null; const f = 10 ** dp; const r = Math.round(x * f) / f; return r === 0 ? 0 : r; };

const product = xs => xs.reduce((a, b) => a * b, 1);
module.exports = {phi, lognormal, layer, round, product};
