# DR² Validation & Calibration Plan — v0.1

## Validation has three distinct layers

1. **Software conformance:** The code implements the stated rules and is replayable.
2. **Evidence assurance:** Assertions are authentic, current, relevant and supported by appropriately qualified issuers.
3. **Actuarial and practical validation:** The loss predictions and control benefits generalise to real risks and lead to defensible underwriting decisions.

Passing one layer does **not** imply passing the others.

## Gate A — Software verification (included in this package)

- Test correct COPE input types, enums, protected null semantics and date validity.
- Assert the fire calculation, frequency vs severity effects and unit consistency.
- Ensure unverified, forged, stale, contradictory or out-of-scope assertions do not earn mitigation credit.
- Confirm that model and registry changes affect reproducibility fingerprints.
- Confirm that same accepted input yields the same result digest.
- Confirm `risk_score` and `premium` remain null rather than inventing calibration.
- Target: all automated tests passing; no critical/major uncaught defects; a second reviewer reproduces baseline test values from the written equations.

**Current state:** 67 automated tests executed successfully at preparation; report `test-run.txt`.

## Gate B — Evidence assurance (not complete)

Controlled research protocol:

- Define issuer verification/accreditation requirements and minimum inspection scopes.
- Specify cryptographic key enrolment, rotation, expiration, revocation and compromise handling.
- Establish authentic evidence capture from inspectors or instrumented systems.
- Define conflicting observations, remediation and challenge/correction workflows.
- Measure agreement between digital attestations and blinded physical re-inspections.
- Test timeliness and expiry for the expected deterioration rate of each control.
- Quantify false-positive/false-negative rates for attestation validity where observable.

Output: documented trust policy, independent audit and source-specific error estimates.

## Gate C — Statistical validation (not complete)

Pre-register the following before examining holdout outcomes:

**Population and target**

- Define commercial property business classes, Australian geographies, policy coverage and annual observation periods.
- Define claims inclusion/exclusion rules, notification-to-payment maturity and development adjustments.
- Define exposure denominators and cancellation/partial-year effects.

**Data protection**

- Formal permission for claims and underwriting data use.
- De-identify or minimise personal data and link data using governed pseudonymous keys.
- Protect test period integrity and prevent target leakage from claims-derived inspections.
- Reconstruct source timestamps and historical validity to avoid look-ahead bias.

**Benchmarks and experiments**

- Model 0: incumbent COPE-based underwriting or benchmark frequency-severity model.
- Model 1: COPE plus condition/inspection fields.
- Model 2: COPE plus authenticated operational controls.
- Model 3: time-varying evidence/trajectory, *only if history is available*.

Evaluate on out-of-time and, where feasible, out-of-entity/region holdouts.

**Statistical tests**

- Claims frequency calibration by rating segment and peril.
- Conditional severity calibration and tail sensitivity.
- Observed/expected loss ratio with uncertainty intervals.
- Proper scoring measures suited to the fitted distribution (e.g. deviance, log likelihood).
- Interval coverage and error under rare/peril-specific events.
- Stability across construction, occupancy, location, sum-insured and evidence-quality subgroups.
- Bootstrap confidence intervals for improvement relative to baseline.
- Calibration drift and operational drift monitoring.

Set acceptance thresholds based on data power and insurer materiality **before** holdout evaluation. An arbitrary fixed percentage improvement would be scientifically inappropriate without a dataset.

**Mitigation causal challenge**

There is selection bias: well-run organisations both install controls and have other lower-risk characteristics. Do not infer a causal 45% sprinkler severity reduction from correlation alone. Use engineering studies, credible actuarial studies and/or quasi-experimental designs with sensitivity analysis, plus qualified expert challenge.

**Insurance pricing boundary**

Even a validated EAL model is not a final premium: catastrophe capital, expenses, reinsurance, margins, policy terms and legal/fairness governance belong to a separately approved pricing process.

## Gate D — Shadow underwriting (not complete)

- Run scoring in parallel with live underwriting, without decision impact.
- Compare referral rates, explanations and control disputes.
- Log insurer expert review, corrections, model limitations and operational incidents.
- Require independent actuarial validation and accountable model approval.
- Publish limitations and establish rollback criteria.

## Gate E — Controlled operational pilot (not complete)

Deploy only after real-data evaluation, security assessment, privacy governance, actuarial approval, contractual authority and the appropriate insurance regulatory review.

## Additional acceptance criteria for the next build

- Fully versioned asset/evidence/issuer model with durable records.
- Replay bundles containing source hashes and approved model artifacts.
- Cross-language canonical encoding specification and test vectors.
- Issuer registration/revocation and dispute workflows.
- Formal threat modelling, security tests and signed audit logs.
- Historical cohort study with defensible uncertainty estimates.
