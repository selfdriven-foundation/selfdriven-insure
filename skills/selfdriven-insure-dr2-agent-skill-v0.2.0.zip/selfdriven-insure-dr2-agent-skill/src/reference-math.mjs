/**
 * DR² small deterministic research helpers. Not a rating engine, calibrated
 * model, actuarial pricing service, underwriting decision or policy interpreter.
 * All monetary amounts are in a SINGLE declared currency and loss basis.
 */
import { createHash, createPublicKey, verify as cryptoVerify } from 'node:crypto';

export function assertFiniteNonNegative(name, value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new TypeError(`${name} must be a finite, non-negative number`);
  }
}

/** Only valid when frequency is claim counts per exposure unit and
 * severity is mean insured payment per claim for the same unit/contract. */
export function frequencySeverityExpectedLoss(frequency, meanSeverity) {
  assertFiniteNonNegative('frequency', frequency);
  assertFiniteNonNegative('meanSeverity', meanSeverity);
  const result = frequency * meanSeverity;
  if (!Number.isFinite(result)) throw new RangeError('EAL overflow');
  return result;
}

/** Apply a simplified per-claim excess and payment limit, NEVER to mean EAL.
 * Actual policy terms may differ (aggregation, waiting periods, franchise etc). */
export function illustrativeClaimPayment(grossClaimAmount, excess, eventLimit) {
  for (const [k,v] of Object.entries({grossClaimAmount, excess, eventLimit})) {
    assertFiniteNonNegative(k,v);
  }
  return Math.min(Math.max(grossClaimAmount - excess, 0), eventLimit);
}

/** Research example of an explicitly approved component credit.
 * effectFraction is not supplied by this skill; use only external validated effects. */
export function applyApprovedControlEffect(referenceLoss, effectFraction, approved) {
  assertFiniteNonNegative('referenceLoss', referenceLoss);
  if (!approved) throw new Error('No approved peril-specific mitigation effect');
  if (typeof effectFraction !== 'number' || !Number.isFinite(effectFraction) || effectFraction < 0 || effectFraction > 1) {
    throw new RangeError('effectFraction must be within [0,1]');
  }
  return referenceLoss * (1 - effectFraction);
}

/** Canonicalisation for closed JSON data in this research package. The format
 * is NOT a standard external signature serialization and must be versioned
 * before interoperability or production use. */
export function stableJson(value) {
  if (value === null || typeof value !== 'object') {
    if (typeof value === 'number' && !Number.isFinite(value)) throw new TypeError('Non-finite number');
    if (typeof value === 'undefined' || typeof value === 'function' || typeof value === 'bigint') {
      throw new TypeError('Unsupported value in canonical JSON');
    }
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return '['+value.map(stableJson).join(',')+']';
  const keys=Object.keys(value).sort();
  return '{'+keys.map(k=>JSON.stringify(k)+':'+stableJson(value[k])).join(',')+'}';
}
export function sha256Json(value) {
  return createHash('sha256').update(stableJson(value)).digest('hex');
}

/** Cryptographic authenticity ONLY. pubKey must come from an independently
 * configured trusted issuer registry, never from this asserted evidence. */
export function checkEd25519Signature(payloadBytes, signatureBase64, trustedPublicKeyPem) {
  if (!Buffer.isBuffer(payloadBytes) || !signatureBase64 || !trustedPublicKeyPem) return false;
  try {
    const key = createPublicKey(trustedPublicKeyPem);
    if (key.asymmetricKeyType !== 'ed25519') return false;
    return cryptoVerify(null, payloadBytes, key, Buffer.from(signatureBase64, 'base64'));
  } catch { return false; }
}

/** Blocks duplicate allocations for SAME insured economic loss. */
export function sumDistinctAllocations(allocations) {
  if (!Array.isArray(allocations)) throw new TypeError('allocations must be an array');
  const seen = new Set(); let total = 0;
  for (const {economicLossId, amount} of allocations) {
    if (typeof economicLossId !== 'string' || !economicLossId) throw new Error('economicLossId required');
    assertFiniteNonNegative('amount', amount);
    if (seen.has(economicLossId)) throw new Error(`Duplicate economic loss: ${economicLossId}`);
    seen.add(economicLossId);total+=amount;
  }
  if (!Number.isFinite(total)) throw new RangeError('Loss sum overflow');
  return total;
}

/** Prototype placeholder is intentionally a non-estimate, never zero. */
export function noModelAvailable(component) {
  const {coverage_id, peril_id, exposure_unit} = component;
  if (![coverage_id,peril_id,exposure_unit].every(x => typeof x === 'string' && x.length)) throw new TypeError('Incomplete component');
  return Object.freeze({coverage_id,peril_id,exposure_unit, model_status:'model_unavailable',
    expected_loss: null, uncertainty: 'unquantified', reasons:['No calibrated and approved model configured']});
}
