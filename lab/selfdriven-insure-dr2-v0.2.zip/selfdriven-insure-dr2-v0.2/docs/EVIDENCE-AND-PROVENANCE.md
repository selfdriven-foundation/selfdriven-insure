# DR² v0.2 — Evidence and provenance policy

## Assertion

`evidence_id`, `subject_id`, `predicate`, `value`, `issuer_id`, `method`, `observed_at`,
`valid_until`, optional `digest_sha256` and `signature_b64`.

- `control.<name>.operational` carries a boolean.
- `fact.<group>.<attribute>` carries a value from that factor's vocabulary.
- The signed payload is the whole assertion minus digest and signature, in the project's
  sorted-key JSON encoding (`dr2-sorted-json-v0.2`, not RFC 8785), signed with Ed25519.
- Observation time (`observed_at`) and assessment time (`as_of`) are separate inputs.

## Trust policy

Operator configuration, never part of the request. The schema rejects a caller-supplied
policy. Per issuer: public key, accepted methods, accepted predicate prefixes, validity
window, revocation time. Plus a list of revoked evidence IDs and maximum evidence age per
predicate. `self_declaration` cannot be configured as a creditable method.

## Eligibility, in order

| Status | Meaning |
|---|---|
| `revoked_evidence` | ID is on the revocation list |
| `untrusted_issuer` | No trust anchor for the issuer |
| `issuer_revoked` | Issuer revoked at or before `as_of` |
| `issuer_not_valid_at_observation` | Observed outside the issuer's validity window |
| `missing_or_invalid_digest` / `missing_or_invalid_signature` | Integrity or authentication failed |
| `unaccepted_method` | Method not accepted for this issuer |
| `predicate_outside_issuer_scope` | Issuer not trusted for this kind of statement |
| `future_observation` / `expired` / `stale` | Timing failed |
| `eligible_authenticated_assertion` | All checks passed |

Eligibility is settled before any risk effect is looked up.

## What eligible means

An authenticated, in-date, in-scope statement from an issuer the operator trusts. It does
not establish that the statement is true, that the control works, or that the model's
effect for that control is calibrated. Those are separate assurance questions.

## Resolution

Controls: `unknown` (no eligible evidence; no credit; not treated as absent),
`verified_true` (credit under the parameter set's effect model), `verified_false`,
`disputed` (eligible assertions conflict, or eligible true against a declared false or
not-applicable; no credit; referred), `not_applicable`.

Facts: `declared`, `verified` (eligible evidence agrees with or fills the declaration),
`unknown`, `disputed` (treated as unknown for calculation and referred), `not_applicable`.

A signed assertion whose issuer has no trust anchor raises
`trust_anchor_missing_for_claimed_verification`.

Hazard classes (bushfire, flood, wind, theft, destination bands, advisory level) are inputs
from the insurer's own mapping. This package ships no geographic data. A hazard class
supplied without `profile_provenance` produces an information request.

## Provenance pinned in every result

`input_sha256`, `subject_sha256`, `policy_terms_sha256`, `evidence_sha256`,
`trust_policy_sha256` with policy id and version, `parameter_set_sha256` with id, version,
status and approvals, model `manifest_sha256` (engine version, line spec, conventions),
`policy_terms_version`, `as_of`, canonical encoding, and `result_sha256`. No random draws.

## Not built

Issuer accreditation and identity proofing, key custody, certificate chains, trusted
timestamping, anti-replay beyond IDs and validity dates, durable evidence storage,
append-only audit log, KERI/ACDC credential verification, dispute and correction workflow.
