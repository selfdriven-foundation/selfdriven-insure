'use strict';
const {HAZARD4, HAZARD3, WIND, YEAR_BUILT, enumf} = require('./shared');
module.exports = {
  line: 'home_contents', title: 'Home & contents', context_profile: 'COPE', period_basis: 'annual',
  coverages: {
    building: {exposure: 'sum_insured'},
    contents: {exposure: 'sum_insured'}
  },
  perils: ['fire', 'bushfire', 'storm', 'flood', 'escape_of_liquid', 'theft'],
  matrix: {
    building: ['fire', 'bushfire', 'storm', 'flood', 'escape_of_liquid'],
    contents: ['fire', 'bushfire', 'storm', 'flood', 'escape_of_liquid', 'theft']
  },
  factors: {
    'construction.wall_material': enumf(['double_brick', 'brick_veneer', 'weatherboard', 'fibre_cement', 'concrete']),
    'construction.roof_material': enumf(['tile', 'metal', 'other']),
    'construction.year_built_band': enumf(YEAR_BUILT),
    'construction.roof_condition': enumf(['good', 'fair', 'poor']),
    'occupancy.dwelling_type': enumf(['house', 'townhouse', 'unit']),
    'occupancy.occupancy_type': enumf(['owner_occupied', 'tenanted', 'holiday_home', 'unoccupied']),
    'exposure.bushfire_hazard_class': enumf(HAZARD4, {hazard: true}),
    'exposure.flood_hazard_class': enumf(HAZARD4, {hazard: true}),
    'exposure.wind_region': enumf(WIND, {hazard: true}),
    'exposure.theft_hazard_class': enumf(HAZARD3, {hazard: true})
  },
  // COPE "P": declared protection. Credit only flows through eligible evidence.
  controls: ['smoke_alarms', 'ember_protection', 'roof_maintenance', 'flexi_hose_replacement',
    'leak_detection_shutoff', 'deadlocks_window_locks', 'monitored_alarm'],
  ownership_scopes: ['owner_building_and_contents', 'owner_building_only', 'contents_only_tenant', 'contents_only_lot_owner'],
  // Building and contents ownership are kept distinct: a tenant or strata lot owner has no building interest here.
  scope_coverages: {owner_building_and_contents: ['building', 'contents'], owner_building_only: ['building'], contents_only_tenant: ['contents'], contents_only_lot_owner: ['contents']}
};
