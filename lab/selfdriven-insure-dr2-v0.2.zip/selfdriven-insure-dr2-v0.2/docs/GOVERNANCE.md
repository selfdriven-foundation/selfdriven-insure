# DR² v0.2 — Governance boundaries

## What the engine will not do

- Bind, decline, vary or cancel cover, or set or vary a premium. `decision_use` of `bind`,
  `decline`, `vary_or_cancel` or `pricing` returns `requires_human_review`. Authority flags
  in the result are constant `false` and `premium` is constant `null`.
- Emit an insurability decision. Rules can only produce `refer` or `information_required`;
  the parameter-set validator rejects any other outcome.
- Emit a presentation score. `presentation_score` is `null` until a score has been
  calibrated and approved; relativities and expected values are reported as what they are.
- Supply numbers of its own. No parameter set means `model_unavailable`.

## Referral conditions implemented

`action_would_bind_decline_or_alter_cover`, `pricing_requested_without_calibrated_model`,
`pricing_is_outside_engine_scope`, `identity_or_ownership_not_established`,
`coverage_inconsistent_with_ownership_scope`, `policy_terms_ambiguous`,
`overlapping_covers_without_allocation_rule`, `trust_anchor_missing_for_claimed_verification`,
`evidence_conflict`, `medical_underwriting_consent_or_basis_unclear`,
`insurability_constraint_triggered`, `jurisdiction_not_supported`.

Not implemented, and so a human responsibility: detecting that a proposed rating factor may
be unlawfully discriminatory. The engine cannot judge that. It is controlled at
parameter-set approval instead.

## Personal and sensitive information

- Travel accepts a `sensitive` block of three fields: whether medical screening was used,
  a consent reference and a lawful-basis reference. Health detail and traveller age are
  rejected by the validator. Age and health are not rating factors in this build.
- If screening was used and either reference is missing, the assessment is referred.
- The result echoes the subject profile's factor values in explanations. It does not echo
  names, addresses or contact details, because the input has no fields for them.
- No persistence. Retention, access control and deletion belong to the host system.

## Five separate assurances

| Layer | Evidence in this package | Status |
|---|---|---|
| Source and evidence checks | `src/evidence.js`, evidence tests | Software only |
| Code correctness | 54 tests, bundle validator, replay check | Done for this build |
| Predictive validation | None | Not started; no data |
| Fairness testing | None | Not started |
| Insurer governance and approval | None | Not started |

## Australian reference pointers

Listed from general knowledge to orient legal review. They were not rechecked against
current sources for this build and are not legal advice.

- Insurance Contracts Act 1984 and Regulations: disclosure duties, and the standard
  definition of flood for home building, home contents, strata and small business contracts.
- Privacy Act 1988 and the Australian Privacy Principles: health information is sensitive
  information.
- Disability Discrimination Act 1992 s 46 and Age Discrimination Act 2004 s 37: insurance
  exemptions that depend on actuarial or statistical data it is reasonable to rely on.
- Corporations Act 2001 design and distribution obligations, and the General Insurance
  Code of Practice.
- APRA prudential standards on risk management and operational risk (CPS 220, CPS 230)
  where the user is an APRA-regulated insurer.
- State strata and fire-safety legislation for strata insurance and fire-safety statements.
