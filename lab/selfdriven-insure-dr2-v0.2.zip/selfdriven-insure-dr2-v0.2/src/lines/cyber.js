'use strict';
const {enumf} = require('./shared');
module.exports = {
  // No COPE. Organisation context profile plus shared-cause dependencies.
  line: 'cyber', title: 'Cyber (SME)', context_profile: 'cyber_organisation', period_basis: 'annual',
  coverages: {
    incident_response: {exposure: 'limit'},
    cyber_business_interruption: {exposure: 'insured_annual_amount', valuation_bases: ['gross_profit', 'gross_revenue']},
    data_restoration: {exposure: 'limit'},
    privacy_liability: {exposure: 'limit'},
    funds_transfer_fraud: {exposure: 'limit'}
  },
  perils: ['ransomware', 'business_email_compromise', 'data_breach', 'dependency_outage'],
  matrix: {
    incident_response: ['ransomware', 'business_email_compromise', 'data_breach'],
    cyber_business_interruption: ['ransomware', 'dependency_outage'],
    data_restoration: ['ransomware'],
    privacy_liability: ['data_breach'],
    funds_transfer_fraud: ['business_email_compromise']
  },
  factors: {
    'organisation.industry_class': enumf(['professional_services', 'retail_ecommerce', 'healthcare', 'manufacturing', 'financial_services', 'other']),
    'organisation.revenue_band': enumf(['under_2m', 'r2m_10m', 'r10m_50m', 'r50m_plus']),
    'organisation.records_band': enumf(['under_10k', 'r10k_100k', 'r100k_1m', 'over_1m']),
    'organisation.it_dependency': enumf(['low', 'moderate', 'high']),
    'organisation.remote_access_exposure': enumf(['none', 'managed', 'internet_exposed']),
    'organisation.payment_volume': enumf(['low', 'moderate', 'high'])
  },
  controls: ['mfa_remote_access', 'mfa_email', 'edr_deployed', 'offline_backups_tested', 'patching_within_sla',
    'email_filtering', 'payment_callback_verification', 'incident_response_plan_tested', 'security_awareness_training'],
  dependencies: true,
  ownership_scopes: ['organisation']
};
