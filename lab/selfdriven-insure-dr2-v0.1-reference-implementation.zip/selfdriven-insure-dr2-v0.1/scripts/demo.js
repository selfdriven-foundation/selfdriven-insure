'use strict';
const {generateKeyPairSync}=require('node:crypto');
const {readFileSync}=require('node:fs');
const path=require('node:path');
const {assess,signEvidence,replayCheck}=require('../src');
const asset=JSON.parse(readFileSync(path.join(__dirname,'../examples/asset-warehouse.json'),'utf8'));
const as_of='2026-10-23T12:00:00Z';
// Ephemeral demonstration keys: NOT issued by any real inspector or trusted authority.
const {publicKey,privateKey}=generateKeyPairSync('ed25519');
const registry={'SYNTHETIC-INSPECTOR':{
  public_key_pem:publicKey.export({type:'spki',format:'pem'}),
  accepted_methods:['inspection']
}};
function inspection(control,value) {
  return signEvidence({
    evidence_id:`DEMO-${control}`,asset_id:asset.asset_id,
    predicate:`control.${control}.operational`,value,
    issuer_id:'SYNTHETIC-INSPECTOR',method:'inspection',
    observed_at:'2026-10-20T00:00:00Z',valid_until:'2026-11-20T00:00:00Z'
  },privateKey);
}
const input={asset,as_of,evidence:[inspection('sprinkler_system',true),inspection('smoke_detection',true),inspection('electrical_inspection',true)]};
const result=assess(input,{trustRegistry:registry});
const noEvidence=assess({asset,as_of,evidence:[]},{trustRegistry:registry});
console.log(JSON.stringify({
  disclaimer:'Synthetic demonstration; signed attestations prove the DEMO key signed the payload, not that the inspected controls exist in reality.',
  reference_eal_aud:result.perils[0].reference.expected_annual_loss_aud,
  residual_eal_aud:result.perils[0].residual.expected_annual_loss_aud,
  no_evidence_eal_aud:noEvidence.perils[0].residual.expected_annual_loss_aud,
  applied_controls:result.perils[0].applied_controls,
  evidence_coverage:result.evidence.evidence_coverage,
  replay:replayCheck(input,registry,result),
  sample_result_hash:result.result_sha256
},null,2));
