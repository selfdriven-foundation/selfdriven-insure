#!/usr/bin/env python3
"""Validate skill manifest refs and JSON Schema 2020-12 examples. Requires jsonschema."""
from pathlib import Path
import json, sys, re
ROOT=Path(__file__).resolve().parents[1]
try:
  import jsonschema
  from jsonschema import Draft202012Validator, FormatChecker
except ImportError:
  print('ERROR: Install Python jsonschema: python3 -m pip install jsonschema',file=sys.stderr)
  raise SystemExit(2)

required=[
 'SKILL.md','README.md', 'references/CORE-RISK-MODEL.md', 'references/EVIDENCE-VCG.md',
 'references/ARCHITECTURE-API.md', 'references/VALIDATION-ACCEPTANCE.md', 'references/GOVERNANCE.md',
 'references/LOB-HOME-CONTENTS.md', 'references/LOB-STRATA.md','references/LOB-SME.md',
 'references/LOB-TRAVEL.md', 'references/LOB-CYBER.md', 'references/V0.1-COMPATIBILITY.md',
 'assets/catalogs/lob-catalog.json'
]
for rel in required:
  assert (ROOT/rel).is_file(),f'Missing: {rel}'
manifest=(ROOT/'SKILL.md').read_text()
assert manifest.startswith('---\n') and '\n---\n' in manifest[4:],'Missing skill frontmatter'
for rel in required[2:]:
  if rel.endswith('.md') and rel.startswith('references/'):
    assert rel in manifest or rel in (ROOT/'README.md').read_text(),f'Undocumented reference: {rel}'

schemas={p.stem.replace('.schema',''):json.loads(p.read_text()) for p in (ROOT/'assets/schemas').glob('*.schema.json')}
assert set(schemas)=={'subject','evidence','assessment','model-manifest'},'Unexpected schema list'
for name,schema in schemas.items():
  Draft202012Validator.check_schema(schema)

mapping={
 'subject':['home_contents.subject.json','strata.subject.json','sme.subject.json','travel.subject.json','cyber.subject.json'],
 'evidence':['home_contents.evidence.json'],
 'assessment':['home_contents.assessment.json'],
 'model-manifest':['research.model-manifest.json']
}
count=0
for kind,files in mapping.items():
  validator=Draft202012Validator(schemas[kind],format_checker=FormatChecker())
  for name in files:
    data=json.loads((ROOT/'assets/examples'/name).read_text())
    errors=sorted(validator.iter_errors(data),key=lambda x:list(map(str,x.path)))
    if errors:
      raise ValueError(f'{name}: '+'; '.join(e.message for e in errors))
    count+=1

catalog=json.loads((ROOT/'assets/catalogs/lob-catalog.json').read_text())
assert {x['line'] for x in catalog['lines']} == {'home_contents','strata','sme','travel','cyber'}
# Negative contract tests: invalid models and missing COPE must fail.
sub=json.loads((ROOT/'assets/examples/home_contents.subject.json').read_text())
sub['profile'].pop('cope')
assert not Draft202012Validator(schemas['subject']).is_valid(sub),'Missing COPE was accepted'
sub=json.loads((ROOT/'assets/examples/travel.subject.json').read_text())
sub['profile'].pop('trip')
assert not Draft202012Validator(schemas['subject']).is_valid(sub),'Missing trip was accepted'
assessment=json.loads((ROOT/'assets/examples/home_contents.assessment.json').read_text())
assessment['components'][0]['expected_loss']={'amount':-1,'currency':'AUD'}
assert not Draft202012Validator(schemas['assessment']).is_valid(assessment),'Negative loss was accepted'
print(f'PASS: {len(required)} required paths, {len(schemas)} JSON Schemas, {count} examples, 3 negative contract tests')
