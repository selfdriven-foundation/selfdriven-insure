'use strict';
const {sha256} = require('./canonical');
const {validateInput,validateRegistry} = require('./validate');
const {evaluateControls} = require('./evidence');
const {calculateFire,manifest} = require('./model-fire');
const ENGINE_VERSION='0.1.0';

function assess(input,{trustRegistry={}}={}) {
  validateInput(input);validateRegistry(trustRegistry);
  const model=manifest();
  const ev=evaluateControls(input.asset,input.evidence,input.as_of,trustRegistry);
  const fire=calculateFire(input.asset,ev.controls);
  const registry_sha256=sha256(trustRegistry);
  const input_sha256=sha256({asset:input.asset,evidence:input.evidence,as_of:input.as_of});
  const result={
    assessment_schema_version:'0.1',engine_version:ENGINE_VERSION,
    assessment_id:'dr2-'+sha256({input_sha256,registry_sha256,model_hash:model.manifest_sha256}).slice(0,24),
    asset_id:input.asset.asset_id,as_of:input.as_of,
    model:{id:model.model_id,version:model.version,manifest_sha256:model.manifest_sha256,validation_status:model.status},
    reproducibility:{input_sha256,trust_registry_sha256:registry_sha256,canonical_encoding:'dr2-sorted-json-v0.1'},
    evidence:ev,
    perils:[fire],
    rating:{risk_score:null,evidence_score:null,trajectory:'indeterminate',insurability:null},
    underwriting:{status:'research_only',manual_review_required:true,may_set_premium:false},
    caveats:[
      'Synthetic coefficients: no actuarial validation or pricing approval',
      'Signed evidence establishes authenticated issuer assertions, not guaranteed physical truth',
      'Unverified/unknown controls receive zero credited reduction; this does not mean they are absent',
      'Missing/invalid evidence and model uncertainty are not quantified statistically'
    ]
  };
  return {...result,result_sha256:sha256(result)};
}
function replayCheck(input,registry,prior) {
  const next=assess(input,{trustRegistry:registry});
  return {matches:next.result_sha256===prior.result_sha256,calculated_hash:next.result_sha256,previous_hash:prior.result_sha256};
}
module.exports={assess,replayCheck};
