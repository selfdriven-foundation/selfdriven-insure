# Line module — Strata (AU)

## Canonical units
Subject = strata scheme/body corporate/owners corporation, location, building(s), lot/common-property map, shared infrastructure, management and maintenance obligations. Jurisdiction must be explicit (`AU-NSW`, `AU-VIC`, etc.); legal definitions of building, common property and insurance obligations can differ. Do not infer those definitions from generic COPE.

## Coverages and risk structure
- Building/common property damage: fire, flood, storm, water escape, malicious damage subject to wording.
- Common contents and machinery/equipment breakdown where covered.
- Public liability and other statutory scheme covers only with dedicated liability models.
- Temporary accommodation, rent or business interruption of common operations only if included by specific contract; maintain ownership/beneficiary distinctions.

## COPE mapping
Construction per building and block (mixed-age towers, façades, roof, sprinklers); Occupancy per lot/usage class and mixed retail/short-term accommodation; Protection from shared fire systems and upkeep; Exposure from aggregate location and adjacent hazard. Never flatten diverse blocks into one COPE record without aggregation method.

## Graph dependencies
`scheme → buildings → lots → ownership/common_property_classification → shared_assets → controls → evidence`; attach each defect, inspection and maintenance order to the correct object. Model water leak propagation across lots and concentration of shared infrastructure failure. A single sprinkler certification can apply to some zones but not all.

## Control/evidence
Fire panel tests, sprinkler coverage map, fire-door inspections, cladding/façade evaluation, lift service records, waterproofing, leak reports, capital works plans, strata meeting approvals. Evidence of a planned repair is not evidence of completion.

## Critical boundaries
- Strata levy arrears, building defect disputes and governance issues can indicate funding/maintenance capacity, but require causal/peril relevance, permission and anti-discrimination review.
- Insurer policy and jurisdiction determine what is insured and by whom; prevent building/lot-owner duplicate valuation.
- Catastrophe concentration across scheme towers must be captured jointly; compare building-level EAL vs scheme-level distribution.

## Test scenarios
1. One building lacks compliant sprinkler documentation while another has coverage → distinct zone-level eligibility.
2. Water leak starts in common riser and damages multiple lots → one event, multiple impacts and explicit allocation.
3. Expired fire-system inspection → still record installed system, withhold unsupported operating-state assertion.
4. Changes to common-property classification → versioned legal/ownership mapping, historical claims unchanged.
5. Storm damages common roof and individual contents → separate beneficiaries/policy sections, no double count.
6. Mixed use retail and residential → occupancy per zone and weighted peril exposure, not averaged arbitrarily.

## Calibration needs
Scheme-year exposure; building/unit attributes; claims and settlement basis; cause-of-loss; repair cost; multi-lot event IDs; regional construction, defect and catastrophe series; property-value/indexation changes.
