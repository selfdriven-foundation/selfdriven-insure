'use strict';
module.exports={...require('./assess'),...require('./canonical'),...require('./evidence'),...require('./model-fire'),...require('./validate')};
