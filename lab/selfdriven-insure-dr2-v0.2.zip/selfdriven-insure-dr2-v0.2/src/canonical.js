'use strict';
const {createHash, createPublicKey, sign, verify} = require('node:crypto');

// Project-specific canonical encoding (sorted keys, JSON-compatible values only).
// Carried over from v0.1. NOT RFC 8785 (JCS); not guaranteed portable across languages.
const ENCODING = 'dr2-sorted-json-v0.2';

function canonical(value) {
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && Object.getPrototypeOf(value) === Object.prototype) {
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
  }
  throw new TypeError('Value must consist of plain objects, arrays, finite numbers and JSON literals');
}
const sha256 = value => createHash('sha256').update(canonical(value), 'utf8').digest('hex');

function deepFreeze(value) {
  if (value && typeof value === 'object') { for (const v of Object.values(value)) deepFreeze(v); Object.freeze(value); }
  return value;
}

function payloadOf(evidence) {
  const {signature_b64, digest_sha256, ...payload} = evidence;
  return payload;
}
// Development/test utility only. Production issuers sign outside the assessment service.
function signEvidence(unsigned, privateKey) {
  const payload = payloadOf(unsigned);
  return {...payload, digest_sha256: sha256(payload),
    signature_b64: sign(null, Buffer.from(canonical(payload), 'utf8'), privateKey).toString('base64')};
}
function checkSignature(evidence, publicKeyPem) {
  const payload = payloadOf(evidence);
  if (evidence.digest_sha256 !== sha256(payload)) return {digest_valid: false, signature_valid: false};
  if (typeof evidence.signature_b64 !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(evidence.signature_b64))
    return {digest_valid: true, signature_valid: false};
  try {
    const signature = Buffer.from(evidence.signature_b64, 'base64');
    if (signature.length !== 64) return {digest_valid: true, signature_valid: false};
    const key = createPublicKey(publicKeyPem);
    if (key.asymmetricKeyType !== 'ed25519') return {digest_valid: true, signature_valid: false};
    return {digest_valid: true, signature_valid: verify(null, Buffer.from(canonical(payload), 'utf8'), key, signature)};
  } catch (_err) {
    return {digest_valid: true, signature_valid: false};
  }
}
module.exports = {ENCODING, canonical, sha256, deepFreeze, payloadOf, signEvidence, checkSignature};
