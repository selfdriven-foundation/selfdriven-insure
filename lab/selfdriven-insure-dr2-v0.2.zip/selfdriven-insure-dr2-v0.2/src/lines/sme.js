'use strict';
const {HAZARD4, HAZARD3, WIND, enumf} = require('./shared');
module.exports = {
  line: 'sme', title: 'SME property and business interruption', context_profile: 'COPE', period_basis: 'annual',
  coverages: {
    buildings: {exposure: 'sum_insured'},
    contents: {exposure: 'sum_insured'},
    // Two VALUATION BASES for the same interruption, not two additive claim streams.
    business_interruption: {exposure: 'insured_annual_amount', overlap_group: 'sme_time_element',
      valuation_bases: ['gross_revenue', 'increased_cost_of_working', 'gross_profit']},
    loss_of_profits: {exposure: 'insured_annual_amount', overlap_group: 'sme_time_element',
      valuation_bases: ['gross_profit']}
  },
  perils: ['fire', 'storm', 'flood', 'escape_of_liquid', 'theft'],
  matrix: {
    buildings: ['fire', 'storm', 'flood', 'escape_of_liquid'],
    contents: ['fire', 'storm', 'flood', 'escape_of_liquid', 'theft'],
    business_interruption: ['fire', 'storm', 'flood'],
    loss_of_profits: ['fire', 'storm', 'flood']
  },
  factors: {
    'construction.primary_material': enumf(['steel', 'masonry', 'timber', 'concrete']),
    'construction.eps_panel': enumf(['none', 'present']),
    'occupancy.primary_use': enumf(['warehouse', 'office', 'light_industrial', 'hospitality', 'retail']),
    'occupancy.premises_tenure': enumf(['owner', 'tenant']),
    'exposure.external_fire_hazard': enumf(HAZARD3, {hazard: true}),
    'exposure.flood_hazard_class': enumf(HAZARD4, {hazard: true}),
    'exposure.wind_region': enumf(WIND, {hazard: true}),
    'exposure.theft_hazard_class': enumf(HAZARD3, {hazard: true}),
    'operations.supplier_concentration': enumf(['low', 'moderate', 'high'], {na: true}),
    'operations.alternative_premises': enumf(['available', 'not_available'], {na: true})
  },
  controls: ['sprinkler_system', 'smoke_detection', 'electrical_inspection', 'monitored_intruder_alarm',
    'business_continuity_plan_tested'],
  ownership_scopes: ['owner_occupier', 'tenant', 'landlord']
};
