#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const {assess}=require('./assess');
const {ValidationError}=require('./validate');
const [command,inputPath,registryPath]=process.argv.slice(2);
if(command!=='assess'||!inputPath) {
  console.error('Usage: node src/cli.js assess INPUT.json [TRUST_REGISTRY.json]'); process.exitCode=2;
} else {
  try {
    const input=JSON.parse(fs.readFileSync(inputPath,'utf8'));
    const registry=registryPath?JSON.parse(fs.readFileSync(registryPath,'utf8')):{};
    console.log(JSON.stringify(assess(input,{trustRegistry:registry}),null,2));
  } catch (err) {
    console.error(err instanceof ValidationError?`Invalid input: ${err.message}`:err.message);
    process.exitCode=1;
  }
}
