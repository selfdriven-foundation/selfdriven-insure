# selfdriven.insure — DR² Multi-Line Agent Skill

**v0.2.0 | 20 November 2026 | Research/engineering specification**

Reusable agent instructions and machine-readable contracts for developing a
**Dynamic Risk & Resilience (DR²)** insurance risk-rating engine for:

1. Home & contents
2. Strata
3. SME buildings, contents, business interruption and loss of profits
4. Travel
5. Cyber

This skill generalises the earlier v0.1 commercial-property/fire prototype.
It is **not** a deployable multi-line rating engine and does not contain
calibrated underwriting or premium coefficients. It includes a small
reference-maths library and verification/test scaffolding.

## How to use

Copy this complete directory into the **skills directory recognised by your
agent environment**. The agent should discover `SKILL.md` and follow its
progressive reading guide. You can also reference the path explicitly:

> Use the `selfdriven-insure-dr2` skill to design a strata risk engine. Read
> its shared risk, evidence and API contracts, the strata module and the test
> plan. Output schemas, deterministic code, test fixtures, model card and a
> calibration/validation gap report. Don't invent loss coefficients.

## Package map

- `SKILL.md` — mandatory agent workflow, hard safety constraints, file routing.
- `references/CORE-RISK-MODEL.md` — units, distributions, covered loss, double counting.
- `references/EVIDENCE-VCG.md` — assertions, trust, verification, conflicts.
- `references/ARCHITECTURE-API.md` — services, model adapter, API and events.
- `references/LOB-*.md` — distinct line-specific risk/peril/coverage contracts.
- `references/VALIDATION-ACCEPTANCE.md` — tests and production gates.
- `references/GOVERNANCE.md` — underwriting authority, privacy, model risk.
- `references/REGULATORY-REFERENCES.md` — official source links and refresh policy.
- `references/FOUNDATION-v0.1.md` — supplied original v0.1 framework document.
- `assets/schemas/` — JSON Schema contracts; `assets/examples/` — fictional samples.
- `assets/catalogs/` — example coverage/peril taxonomy, **not** a regulator taxonomy.
- `templates/` — agent deliverables.
- `src/` and `test/` — small dependency-free research helpers and tests.

## Validate the package

Requires Python 3 and Node.js 20+. For full JSON Schema validation, install
Python `jsonschema` in the environment: `python3 -m pip install jsonschema`.

```sh
python3 scripts/validate_bundle.py
node --test
```

The Python validator deliberately fails when `jsonschema` is unavailable:
validation of real JSON Schema constraints must not be replaced with a shallow
key-only check. All examples are fictional and contain no real customer data.

## Compatibility

The original fire prototype uses a different, narrower structure. Read
`references/V0.1-COMPATIBILITY.md`; **do not treat v0.2 as a drop-in upgrade**.

## Governance

No premium, decline/bind recommendation, or model output may be represented as
actuarially valid until qualified insurer governance approves it using
appropriate claims/exposure data. Ownership of code/data and licences are not
established by this draft package.
