# DR² Core Risk Model — normative engineering design

## 1. Unit of analysis

A **risk component** is indexed by:

`(subject_id, line, coverage_id, peril_id, evaluation_period, jurisdiction,
policy_terms_version, model_manifest_id)`.

The outcome is a **distribution of insured claim/payment losses** over the
specified period. Different coverage sections on the same event must identify
allocation and overlap rules. Exposures measured per trip or per person-day
must not silently be annualised.

## 2. Objects and concepts

- `HazardEvent`: a fire, flood, cyber attack, illness event, cancellation event,
  etc. Neither automatic claim nor automatic coverage.
- `Damage`: observable physical, medical, financial or operational impact.
- `GrossLoss`: monetary/economic consequence before policy terms.
- `Claim`: asserted payment under policy.
- `InsuredPayment`: result after triggers, exclusions, sublimits, deductibles,
  waiting periods, co-insurance, reinstatement, aggregation, and endorsement rules.
- `RiskEstimate`: frequency/severity distribution, uncertainty and model basis.
- `Control`: peril/mechanism-targeted mitigation or recovery action.
- `Evidence`: claim about a risk-relevant state, with trust and temporal context.
- `RiskPresentation`: optional risk-grade **view** over calibrated estimates.
- `Insurability`: independent view of observability, predictability,
  controllability, recoverability and insurer capacity/risk appetite.

## 3. Frequency–severity (where appropriate)

For a homogeneous component over a known exposure period:

`E[L] = E[N] × E[S | claim]` where `N` is count of claims and `S` is the
**insured payment** amount per claim, provided the frequency and severity
model refer to the same claim unit and are appropriately conditioned. This
identity does not imply independent perils or no inflation/trend.

For travel per-trip cancellation, a Bernoulli event model may be appropriate:
`E[L_trip] = P(covered cancellation in trip) × E[claim payment | cancellation]`.
Medical treatment while travelling may be modelled by days, trip, or event;
choose a consistent denominator based on observed training exposure.

For shared catastrophe/cyber incidents, model `Event × Locations/Entities ×
Coverages` using joint dependence instead of treating individual components
as independent. Aggregate expected values need correct **non-overlapping
payment definitions**; tail risk requires joint loss distributions.

## 4. Peril-specific mitigation

Document the counterfactual reference state and whether a control changes:

- hazard occurrence / claim frequency,
- loss given event / vulnerability,
- claims payment size,
- duration or recovery,
- dependency/accumulation.

A model may use `reference_EAL × (1 - calibrated_effect)` only with a well-
defined reference and empirically/causally defensible effect. Never multiply
unrelated percentage discounts or insert arbitrary evidence discounts. Each
credit needs a model version and relevant verified control states.

`declared=true` does not imply `operational=true` and `operational=true` does
not imply causal efficacy. Verified evidence may affect **certainty** rather
than expected loss unless there is an approved effect model.

## 5. Policy mapping

Implement a versioned, insurer-authorised **policy terms evaluator** separate
from gross-loss model. Trigger, exclusion, waiting period, coverage sublimit,
excess, sum insured, co-insurance and aggregation operate at the correct
claim/event/period level. It is generally invalid to apply a deductible to a
mean loss as though it were a claim. For example,
`E[max(0, X - excess)] != max(0, E[X] - excess)` in general.

- Property: fire vs bushfire, flood vs rainwater runoff, accidental damage,
  insurer definitions and exclusions must follow the specific policy.
- Strata: common property vs individual lot/contents, scheme liability and
  applicable jurisdictional ownership boundaries.
- SME: physical damage may trigger BI only if contract conditions are met;
  policy definitions of insurable gross profit differ from accounting profit.
  "Loss of profits" may be the **same BI cover** under another valuation
  label. NEVER sum both without proof of disjoint coverage.
- Travel: cancellation, overseas medical, baggage and delay cover may have
  trip-specific limits, exclusions, excesses and pre-existing condition rules.
- Cyber: first-party incident response, digital BI and third-party liability
  may share common causes, sublimits, retroactive dates and waiting periods.

## 6. Uncertainty and evidence

Represent input uncertainty and model uncertainty independently. Evidence
quality should drive a data-quality flag, uncertainty interval or reviewer
referral, not an unexplained risk multiplication. There is no common 0–100
score that is comparable across property, travel and cyber without a properly
specified and calibrated normalization basis.

## 7. Trajectory

Compare snapshots only after controlling for model version, exposure period,
coverage definition and reference population. Classify as `improving`,
`stable`, `deteriorating` or `indeterminate`; always report interval, method
and confidence. An external hazard alert is a transient scenario, not
necessarily permanent deterioration in asset condition.

## 8. Insurability

Return a structured assessment:
`observability`, `predictability`, `controllability`, `recoverability`,
`capacity_and_appetite`, plus `status` and reasons. Do not treat a high
insurability score as a promise to insure.

## 9. Score mapping and technical premium

Loss estimates and predictive validation come first. Presentation grades may
only be defined through documented, versioned reference distributions.
Technical premium additionally requires expenses, catastrophe/tail, capital,
reinsurance and margin inputs governed by the insurer. This skill DOES NOT
supply those values.
