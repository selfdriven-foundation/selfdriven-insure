'use strict';
const {ENCODING, sha256} = require('./canonical');
const {lognormal, layer, round} = require('./math');
const {LINES} = require('./lines');
const {validateInput, validateTrustPolicy, EMPTY_TRUST_POLICY, NA} = require('./validate');
const {validateParameterSet} = require('./params');
const {evaluateEvidence} = require('./evidence');

const ENGINE_VERSION = '0.2.0';
const DAY = 86400000;
const UNQUANTIFIED = Object.freeze({status: 'unquantified',
  note: 'low/high are missing-data bounds across the parameter tables, not confidence or credible intervals; parameter and model uncertainty are not estimated'});

const CONVENTIONS = Object.freeze({
  frequency: 'Poisson claim-event rate over the stated exposure period; severities i.i.d. and independent of frequency',
  severity: 'lognormal ground-up loss per event, specified by mean and coefficient of variation',
  claim_payment: 'min(max(min(X, cap) - excess, 0), limit) per event; cap = sum insured or indemnity-period value',
  time_element: 'daily amount = insured annual amount / 365; excess = daily amount x waiting days',
  annual_period_scaling: 'period days / 365', normal_cdf: 'Abramowitz-Stegun 26.2.17', rounding: 'half away from zero to 6 decimal places on output only',
  currency: 'AUD', time: 'UTC ISO 8601', aggregation: 'sum of expectations over non-overlapping components; no variance, tail or aggregate-limit modelling'
});
const modelManifest = line => {
  const m = {engine_version: ENGINE_VERSION, line_spec: LINES[line], conventions: CONVENTIONS};
  return {engine_version: ENGINE_VERSION, line, conventions: CONVENTIONS, manifest_sha256: sha256(m)};
};

const labelOf = (def, v) => def.type === 'int' ? def.bands.find(b => v <= b[0])[1] : v;

function factorProduct(spec, list, facts) {
  let low = 1, high = 1, point = 1, unavailable = null; const explain = [], unknown = [];
  for (const f of list) {
    const fact = facts[f.factor], range = Object.entries(f.table).filter(([k]) => k !== NA).map(([, v]) => v);
    if (fact.state === 'unknown' || fact.state === 'disputed') {
      const lo = Math.min(...range), hi = Math.max(...range);
      low *= lo; high *= hi; point = null; unknown.push(f.factor);
      explain.push({factor: f.factor, state: fact.state, value: null, multiplier: null, bounds: [lo, hi], evidence_ids: fact.evidence_ids});
      continue;
    }
    const label = fact.state === 'not_applicable' ? NA : labelOf(spec.factors[f.factor], fact.value);
    if (!Object.hasOwn(f.table, label)) { unavailable = `no_parameter_for:${f.factor}=${label}`; continue; }
    const m = f.table[label]; low *= m; high *= m; if (point !== null) point *= m;
    explain.push({factor: f.factor, state: fact.state, value: fact.value, table_key: label, multiplier: m, evidence_ids: fact.evidence_ids});
  }
  return {low, high, point, explain, unknown, unavailable};
}
function controlProduct(list, controls) {
  let m = 1; const explain = [];
  for (const c of list) {
    const st = controls[c.control], applied = st.state === 'verified_true';
    if (applied) m *= c.multiplier;
    explain.push({control: c.control, target: c.target, state: st.state, declared: st.declared, credit_applied: applied,
      multiplier: applied ? c.multiplier : 1, multiplier_if_eligible: c.multiplier, effect_basis: c.effect_basis, evidence_ids: st.evidence_ids});
  }
  return {m, explain};
}
const times = (a, b) => (a === null || b === null) ? null : a * b;

function eventModel(key, ctx) {
  const ev = ctx.ps.events[key];
  let scale = 1; const exposure = {unit: ev.unit};
  if (ev.unit === 'per_year') { scale = ctx.periodDays / 365; exposure.period_days = ctx.periodDays; }
  if (ev.unit === 'per_trip_day') {
    const d = ctx.facts['trip.duration_days'].value; if (d === null) return {unavailable: 'insufficient_data:trip.duration_days'};
    scale *= d; exposure.trip_days = d;
  }
  if (ev.per_traveller) {
    const n = ctx.facts['trip.travellers'].value; if (n === null) return {unavailable: 'insufficient_data:trip.travellers'};
    scale *= n; exposure.travellers = n;
  }
  const fp = factorProduct(ctx.spec, ev.factors, ctx.facts), cp = controlProduct(ev.controls, ctx.controls);
  if (fp.unavailable) return {unavailable: fp.unavailable};
  const ref = ev.base_rate * scale;
  return {exposure, reference: ref, unmitigated: times(ref, fp.point), low: ref * fp.low * cp.m, high: ref * fp.high * cp.m,
    point: times(ref * cp.m, fp.point), factors: fp.explain, controls: cp.explain, unknown: fp.unknown};
}

function variant(freq, mean, cv, lay, excluded) {
  const L = layer(lognormal(mean, cv), lay);
  return {
    loss_event_frequency: round(freq, 8), conditional_mean_ground_up_severity: round(mean, 2),
    gross_expected_loss: round(freq * L.expected_gross_loss_per_event, 2),
    expected_claim_count: round(excluded ? 0 : freq * L.probability_event_becomes_claim, 8),
    expected_claim_payment: round(excluded ? 0 : freq * L.expected_payment_per_event, 2)
  };
}

function componentModel(coverage, peril, terms, ctx) {
  const {spec, ps, line} = ctx, key = `${line}.${coverage}.${peril}`, eventKey = `${line}.${peril}`;
  const kind = spec.coverages[coverage].exposure;
  const base = {key, coverage, peril, event_key: eventKey, period_basis: spec.period_basis, premium: null};
  if (!ps) return {...base, status: 'model_unavailable', reason: 'no_parameter_set_supplied'};
  const c = Object.hasOwn(ps.components, key) ? ps.components[key] : null;
  if (!c) return {...base, status: 'model_unavailable', reason: 'no_model_for_component_in_parameter_set'};
  const ev = ctx.events[eventKey] ||= eventModel(eventKey, ctx);
  if (ev.unavailable) return {...base, status: ev.unavailable.startsWith('insufficient_data') ? 'insufficient_data' : 'model_unavailable', reason: ev.unavailable};

  let unit = 1, cap = Infinity, excess = terms.excess, exposureAmount = null;
  let limit = Math.min(terms.limit ?? Infinity, Object.hasOwn(terms.sublimits, peril) ? terms.sublimits[peril] : Infinity);
  if (kind === 'sum_insured') { unit = terms.sum_insured; cap = terms.sum_insured; exposureAmount = terms.sum_insured; limit = Math.min(limit, terms.sum_insured); }
  if (kind === 'insured_annual_amount') {
    unit = terms.insured_annual_amount / 365; cap = unit * terms.indemnity_period_days; excess = unit * terms.waiting_days; exposureAmount = terms.insured_annual_amount;
  }
  const lay = {cap, excess, limit}, excluded = terms.excluded_perils.includes(peril);
  const sp = factorProduct(spec, c.severity.factors, ctx.facts), cp = controlProduct(c.controls, ctx.controls);
  if (sp.unavailable) return {...base, status: 'model_unavailable', reason: sp.unavailable};
  const inv = c.involvement_probability, m0 = c.severity.base * unit, cv = c.severity.cv;
  const v = (f, m) => (f === null || m === null) ? null : variant(f * inv, m, cv, lay, excluded);
  const reference = v(ev.reference, m0);
  const unmitigated = v(ev.unmitigated, times(m0, sp.point));
  const point = v(ev.point, times(m0 * cp.m, sp.point));
  const low = v(ev.low, m0 * sp.low * cp.m), high = v(ev.high, m0 * sp.high * cp.m);
  const unknown = [...new Set([...ev.unknown, ...sp.unknown])];
  const fin = x => x === Infinity ? null : round(x, 2);
  return {
    ...base,
    status: excluded ? 'excluded_by_policy_terms' : point ? 'computed' : 'computed_bounds_only',
    exposure: {kind, amount: exposureAmount, ...ev.exposure},
    terms_applied: {loss_cap: fin(cap), excess: fin(excess), payment_limit: fin(limit), peril_excluded: excluded,
      ...(kind === 'insured_annual_amount' ? {valuation_basis: terms.valuation_basis, daily_amount: round(unit, 2), waiting_days: terms.waiting_days, indemnity_period_days: terms.indemnity_period_days} : {})},
    reference_class: reference, unmitigated, residual: {point, low, high},
    modelled_control_effect_on_expected_claim_payment: point && unmitigated ? round(unmitigated.expected_claim_payment - point.expected_claim_payment, 2) : null,
    relativity_to_reference_class: point && reference.expected_claim_payment > 0 ? round(point.expected_claim_payment / reference.expected_claim_payment, 6) : null,
    expected_claim_payment_per_unit_exposure: point && exposureAmount ? round(point.expected_claim_payment / exposureAmount, 8) : null,
    explanation: {
      involvement_probability: inv, severity_basis: c.severity.basis, severity_cv: cv,
      frequency_factors: ev.factors, severity_factors: sp.explain,
      controls: [...ev.controls, ...cp.explain], unknown_or_disputed_inputs: unknown
    },
    uncertainty: UNQUANTIFIED
  };
}

function aggregate(components) {
  const sum = (list, pick, dp = 2) => list.some(c => pick(c) === null) ? null : round(list.reduce((a, c) => a + pick(c), 0), dp);
  const block = list => ({
    expected_claim_payment: {point: sum(list, c => c.residual.point && c.residual.point.expected_claim_payment), low: sum(list, c => c.residual.low.expected_claim_payment), high: sum(list, c => c.residual.high.expected_claim_payment)},
    gross_expected_loss: {point: sum(list, c => c.residual.point && c.residual.point.gross_expected_loss), low: sum(list, c => c.residual.low.gross_expected_loss), high: sum(list, c => c.residual.high.gross_expected_loss)},
    expected_claim_count: {point: sum(list, c => c.residual.point && c.residual.point.expected_claim_count, 8)}
  });
  const usable = components.filter(c => c.residual && c.included_in_totals);
  const by = {};
  for (const c of usable) (by[c.coverage] ||= []).push(c);
  const excluded = components.filter(c => !c.residual || !c.included_in_totals).map(c => ({key: c.key, reason: c.residual ? c.totals_exclusion_reason : c.status}));
  const ref = usable.reduce((a, c) => a + c.reference_class.expected_claim_payment, 0), b = block(usable);
  return {
    basis: 'sum_of_expectations_over_non_overlapping_components_for_the_exposure_period',
    ...(usable.length ? b : {expected_claim_payment: {point: null, low: null, high: null}, gross_expected_loss: {point: null, low: null, high: null}, expected_claim_count: {point: null}}),
    relativity_to_reference_class: usable.length && b.expected_claim_payment.point !== null && ref > 0 ? round(b.expected_claim_payment.point / ref, 6) : null,
    by_coverage: Object.fromEntries(Object.entries(by).map(([k, list]) => [k, block(list)])),
    incomplete: components.some(c => !c.residual), components_not_in_totals: excluded, uncertainty: UNQUANTIFIED
  };
}

function insurability(ctx) {
  const triggers = [];
  for (const r of (ctx.ps ? ctx.ps.insurability_rules : []).filter(r => r.line === ctx.line)) {
    let hit = false, observed;
    if (r.when.factor) {
      const f = ctx.facts[r.when.factor]; observed = {factor: r.when.factor, state: f.state, value: f.value};
      hit = (r.when.unknown === true && ['unknown', 'disputed'].includes(f.state)) || (Array.isArray(r.when.in) && r.when.in.includes(f.value));
    } else {
      const c = ctx.controls[r.when.control]; observed = {control: r.when.control, state: c.state};
      hit = r.when.state_in.includes(c.state);
    }
    if (hit) triggers.push({rule_id: r.id, outcome: r.outcome, reason: r.reason, observed, rule_basis: r.rule_basis});
  }
  const status = !ctx.ps ? 'not_assessed' : triggers.some(t => t.outcome === 'refer') ? 'refer'
    : triggers.length ? 'information_required' : 'no_constraint_triggered';
  return {status, triggers, decision: null,
    note: 'Constraint screening only. Distinct from expected loss. Never an acceptance, decline or eligibility decision.'};
}

function assess(input, {trustPolicy = EMPTY_TRUST_POLICY, parameterSet = null} = {}) {
  const spec = validateInput(input); validateTrustPolicy(trustPolicy);
  if (parameterSet) validateParameterSet(parameterSet);
  const {subject, policy_terms: terms} = input, line = subject.line;
  const supported = subject.jurisdiction.country === 'AU';
  const ps = supported ? parameterSet : null;
  const ev = evaluateEvidence(spec, subject, input.evidence, input.as_of, trustPolicy);
  const periodDays = round((Date.parse(terms.period.end) - Date.parse(terms.period.start)) / DAY, 4);
  const ctx = {spec, ps, line, facts: ev.facts, controls: ev.controls, periodDays, events: {}};
  const manifest = modelManifest(line);

  // Overlapping valuation bases are never summed without an explicit allocation rule.
  const groups = {};
  for (const t of terms.coverages) { const g = spec.coverages[t.coverage].overlap_group; if (g) (groups[g] ||= []).push(t.coverage); }
  const overlap = [], exclusion = {};
  for (const [g, list] of Object.entries(groups)) {
    if (list.length < 2) continue;
    const rule = (terms.overlap_allocation || []).find(a => a.group === g);
    overlap.push({group: g, coverages: list, allocation: rule ? {rule: rule.rule, primary_coverage: rule.primary_coverage} : null});
    for (const cov of list) if (!rule || cov !== rule.primary_coverage) exclusion[cov] = rule ? 'overlap_allocated_to_primary_coverage' : 'overlapping_cover_without_allocation_rule';
  }

  const components = [];
  for (const t of terms.coverages) for (const peril of spec.matrix[t.coverage]) {
    const c = componentModel(t.coverage, peril, t, ctx);
    if (!supported) c.reason = 'jurisdiction_not_supported';
    if (c.residual) { c.included_in_totals = !Object.hasOwn(exclusion, t.coverage); if (!c.included_in_totals) c.totals_exclusion_reason = exclusion[t.coverage]; }
    components.push(c);
  }
  const computed = components.filter(c => c.residual);
  const totals = aggregate(components);

  const eventGroups = Object.keys(ctx.events).filter(k => !ctx.events[k].unavailable).map(k => ({event: k, components: computed.filter(c => c.event_key === k).map(c => c.key)})).filter(g => g.components.length);
  const sharedCause = {
    event_groups: eventGroups,
    accumulation_keys: (subject.dependencies || []).map(d => ({key: `dependency:${d.kind}:${d.provider_ref}`, dependency_id: d.dependency_id, criticality: d.criticality})),
    note: 'Components in one event group arise from the same loss event. Per-event aggregate limits, portfolio accumulation and catastrophe clustering are not modelled.'
  };

  const insur = insurability(ctx);

  // Stop / referral conditions.
  const reasons = [];
  const add = (code, detail) => reasons.push(detail === undefined ? {code} : {code, detail});
  if (!supported) add('jurisdiction_not_supported', subject.jurisdiction.country);
  if (['bind', 'decline', 'vary_or_cancel'].includes(input.decision_use)) add('action_would_bind_decline_or_alter_cover', input.decision_use);
  if (input.decision_use === 'pricing') add(ps && ps.status === 'calibrated' ? 'pricing_is_outside_engine_scope' : 'pricing_requested_without_calibrated_model');
  if (subject.ownership.status !== 'undisputed') add('identity_or_ownership_not_established', subject.ownership.status);
  if (spec.scope_coverages) { const bad = terms.coverages.map(t => t.coverage).filter(c => !spec.scope_coverages[subject.ownership.scope].includes(c)); if (bad.length) add('coverage_inconsistent_with_ownership_scope', bad); }
  if (terms.wording_ref === null) add('policy_terms_ambiguous', 'policy_terms.wording_ref is null');
  for (const o of overlap) if (!o.allocation) add('overlapping_covers_without_allocation_rule', o.coverages);
  if (ev.unanchored_signed_assertions.length) add('trust_anchor_missing_for_claimed_verification', ev.unanchored_signed_assertions);
  for (const i of ev.issues) add('evidence_conflict', i);
  if (spec.sensitive_block && subject.sensitive.medical_screening_used && (subject.sensitive.consent_ref === null || subject.sensitive.lawful_basis_ref === null)) add('medical_underwriting_consent_or_basis_unclear');
  if (insur.status === 'refer') add('insurability_constraint_triggered', insur.triggers.filter(t => t.outcome === 'refer').map(t => t.rule_id));

  const info = [];
  const needed = new Set(computed.flatMap(c => c.explanation.unknown_or_disputed_inputs));
  for (const t of insur.triggers) if (t.outcome === 'information_required' && t.observed.factor) needed.add(t.observed.factor);
  for (const k of [...needed].sort()) info.push({item: `fact.${k}`, why: `${ev.facts[k].state}_input_widens_bounds_or_blocks_screening`});
  for (const c of components.filter(c => c.status === 'insufficient_data')) info.push({item: c.reason.split(':')[1], why: 'required_exposure_quantity_missing'});
  const creditable = new Set(computed.flatMap(c => c.explanation.controls.filter(x => x.state === 'unknown' && x.declared !== false).map(x => x.control)));
  for (const k of [...creditable].sort()) info.push({item: `control.${k}.operational`, why: 'no_eligible_evidence_so_no_credit_applied'});
  for (const [k, f] of Object.entries(ev.facts)) if (spec.factors[k].hazard && f.state === 'declared' && !f.provenance) info.push({item: `profile_provenance.${k}`, why: 'hazard_class_supplied_without_source'});
  const seenInfo = new Set(); const informationRequests = info.filter(i => !seenInfo.has(i.item) && seenInfo.add(i.item));

  const modelStatus = !ps ? 'model_unavailable' : ps.status === 'calibrated' ? 'calibrated_parameter_set' : 'research_only';
  const status = !computed.length ? 'model_unavailable' : reasons.length ? 'requires_human_review' : modelStatus === 'research_only' ? 'research_only' : 'assessed_for_underwriter_review';

  // Trajectory: only comparable when model, parameters, terms and subject are unchanged.
  const comparability = sha256({subject_id: subject.subject_id, parameter_set_sha256: ps ? sha256(ps) : null, manifest_sha256: manifest.manifest_sha256, policy_terms_sha256: sha256(terms)});
  const nowTotal = totals.expected_claim_payment.point, nowShare = ev.coverage.control_resolved_share === null ? null : round(ev.coverage.control_resolved_share, 6);
  let trajectory = {direction: 'indeterminate', reason: 'no_prior_snapshot'};
  const prior = input.prior_snapshot;
  if (prior) {
    if (prior.comparability_sha256 !== comparability) trajectory = {direction: 'indeterminate', reason: 'prior_snapshot_not_comparable_model_parameters_terms_or_subject_changed'};
    else if (Date.parse(prior.as_of) >= Date.parse(input.as_of)) trajectory = {direction: 'indeterminate', reason: 'prior_snapshot_not_earlier_than_as_of'};
    else if (nowTotal === null || prior.expected_claim_payment_total === null) trajectory = {direction: 'indeterminate', reason: 'point_estimate_unavailable_in_one_snapshot'};
    else {
      const change = prior.expected_claim_payment_total > 0 ? (nowTotal - prior.expected_claim_payment_total) / prior.expected_claim_payment_total : (nowTotal > 0 ? Infinity : 0);
      const tol = ps.trajectory_tolerance;
      trajectory = {direction: change > tol ? 'deteriorating' : change < -tol ? 'improving' : 'stable', tolerance: tol,
        relative_change_in_expected_claim_payment: Number.isFinite(change) ? round(change, 6) : null,
        change_in_control_resolved_share: nowShare !== null && prior.evidence_resolved_share !== null ? round(nowShare - prior.evidence_resolved_share, 6) : null,
        prior_assessment_id: prior.assessment_id, prior_as_of: prior.as_of};
    }
  }
  trajectory.note = 'Change in modelled expected claim payment between two comparable snapshots. Not a forecast.';

  const input_sha256 = sha256(input), trust_policy_sha256 = sha256(trustPolicy), parameter_set_sha256 = ps ? sha256(ps) : null;
  const assessment_id = 'dr2-' + sha256({input_sha256, trust_policy_sha256, parameter_set_sha256, manifest: manifest.manifest_sha256}).slice(0, 24);
  const result = {
    assessment_schema_version: '0.2', assessment_id, status,
    assessment_unit: {subject_id: subject.subject_id, line, context_profile: spec.context_profile, jurisdiction: subject.jurisdiction,
      period: terms.period, period_basis: spec.period_basis, period_days: periodDays, policy_terms_version: terms.version,
      coverages: terms.coverages.map(t => t.coverage), as_of: input.as_of, decision_use: input.decision_use, requester_role: input.requester_role},
    model: {engine_version: ENGINE_VERSION, manifest_sha256: manifest.manifest_sha256, status: modelStatus,
      parameter_set: parameterSet ? {id: parameterSet.parameter_set_id, version: parameterSet.version, status: parameterSet.status, approvals: parameterSet.approvals} : null},
    reproducibility: {input_sha256, subject_sha256: sha256(subject), policy_terms_sha256: sha256(terms), evidence_sha256: sha256(input.evidence),
      trust_policy_sha256, trust_policy: {id: trustPolicy.policy_id, version: trustPolicy.version}, parameter_set_sha256,
      canonical_encoding: ENCODING, stochastic_seed: null, note: 'Deterministic; no random draws. Replay needs lawful access to the original input, trust policy and parameter set.'},
    risk: {currency: 'AUD', components, totals, shared_cause: sharedCause, overlap_groups: overlap},
    evidence: {records: ev.records, controls: ev.controls, facts: ev.facts, issues: ev.issues, coverage: ev.coverage, uncertainty: UNQUANTIFIED},
    trajectory: {...trajectory, snapshot_for_next_assessment: {assessment_id, as_of: input.as_of, comparability_sha256: comparability, expected_claim_payment_total: nowTotal, evidence_resolved_share: nowShare}},
    insurability: insur,
    recommendation: {
      action: status === 'model_unavailable' ? 'model_unavailable' : reasons.length ? 'refer_to_human_underwriter' : informationRequests.length ? 'request_information' : 'none',
      referral_reasons: reasons, information_requests: informationRequests,
      human_overrides: [], may_bind: false, may_decline: false, may_vary_or_cancel: false, may_set_premium: false, premium: null,
      presentation_score: null
    },
    caveats: [
      parameterSet && parameterSet.status === 'synthetic_fixture' ? 'SYNTHETIC parameter set: every rate, share, multiplier and rule is an invented software fixture with no actuarial basis' : 'Outputs depend entirely on the pinned parameter set',
      'Expected values only: no premium, loading, capital, reinsurance, expense or margin',
      'Eligible evidence is an authenticated in-date assertion from a trusted issuer; it is not proof of fact or of control efficacy',
      'Unknown controls earn no credit and unknown facts widen bounds; neither is treated as false, zero or absent',
      'Code correctness, evidence assurance, predictive validity, fairness testing and insurer governance are separate; passing tests establishes only the first'
    ]
  };
  return {...result, result_sha256: sha256(result)};
}

function replayCheck(input, options, prior) {
  const next = assess(input, options);
  return {matches: next.result_sha256 === prior.result_sha256, calculated_hash: next.result_sha256, previous_hash: prior.result_sha256};
}
module.exports = {ENGINE_VERSION, CONVENTIONS, assess, replayCheck, modelManifest};
