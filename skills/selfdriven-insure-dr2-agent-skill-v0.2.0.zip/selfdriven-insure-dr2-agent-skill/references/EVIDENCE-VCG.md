# Evidence, Trust & Verified Context Graphs (VCG)

## Purpose
Keep **facts**, **assertions about facts**, **source integrity**, **control states**, **model assumptions** and **risk conclusions** separately addressable. The graph is a model of provenance and dependencies, not evidence of predictive validity by itself.

## Entities / edges
- `Subject` (insured person, building, business, trip, technology estate) **has** `RiskLocation`, `Dependency`, `Asset`, `Coverage`.
- `Assertion` **about** Subject; **claims** predicate/value; **supported_by** Evidence; **contradicted_by** other assertions.
- `Evidence` **issued_by** source; **observed_at** timestamp; **verified_under** TrustPolicy; **replaced_by** later evidence; **revoked_by** event.
- `Control` **affects** specified (`Peril`, `Coverage`, `LossMechanism`) and **has_state_at** time supported by assertions.
- `RiskAssessment` **derived_from** pinned input assertions, trusted model manifest and policy/coverage definitions; **evaluated_by** an approved model.
- `HumanOverride` **modifies_decision_only** or **supersedes_model_input** with reason, author, authority, timestamp and audit record.

## Evidence record requirements
Each evidence record captures stable ID, subject, predicate, typed value, issuer and verifier IDs, collection method, observation/ingestion/effective/expiry times, `sha256` of canonical payload, signature (optional), key ID, trust-policy version, validation status, revocation/conflict markers and original immutable reference.

`verified` means **validated against the declared verification policy**. Distinguish:
1. cryptographic integrity and source authentication;
2. independence, competence and legitimacy of source;
3. freshness, scope and coverage of observation;
4. applicability to this asset/peril/control;
5. whether asserted control state actually affects risk;
6. predictive model validation using real-world outcomes.

A signature covers bytes, not actual truth. Never trust a public key embedded solely in the submitted evidence; resolve it via configured trust registry. Document signature algorithm, canonicalisation and key rotation/revocation. Prefer Ed25519 and standard canonical serialisation with versioned rules where appropriate.

## Suggested eligibility state machine
`received → syntactically_valid → authenticity_checked → trusted_source → temporally_valid → no_material_conflict → eligible_for_specific_use`

Possible terminal or non-terminal states: `rejected`, `expired`, `revoked`, `disputed`, `pending_review`, `unverified`.

- Missing ≠ false; false ≠ revoked; stale ≠ never existed.
- Evidence may be eligible for a descriptive field but not for granting a mitigation credit.
- Imported inspection documents may require identity/issuer verification and explicit inspection scope.
- If two trusted sources disagree materially, preserve both and raise a review flag. Do not select whichever yields lower EAL.
- Failure to obtain telemetry is not automatically a failure of a physical protection system.

## Data quality outputs
Return per-feature `status`, `source_count`, `latest_observation`, `staleness`, `conflicts`, `coverage`, `eligible_uses` and a reason list. Return overall `evidence_status` (`supported`, `partial`, `insufficient`, `disputed`) with uncertainty notes; any percentage score is an optional **non-probabilistic** display index unless calibrated.

## Privacy-aware design
Request minimal data; retain provenance references where possible rather than replicating raw files. Separate identity keys, PII, health records and policy/claim outcomes. Enforce scoped consent and purpose-specific access, short-lived tokens, encryption, retention, revocation and audit logs. Do not put sensitive patient/identity details into content-addressed public stores or public chain records. Anchoring a hash may still create privacy or correlation risks; assess first.

## Verification tests
- Re-signing altered bytes fails; untrusted issuer fails; revoked key fails.
- Observed-after-expiry fails; future-dated attestations receive manual review.
- Two duplicate attestations from one inspection count as **one provenance lineage**.
- Conflict is preserved and control credit is withheld pending resolution under policy.
- Control evidence for fire does not receive automatic credit for flood or cyber.
- The assessment reproduces from immutable snapshots with model and trust policy versions pinned.
