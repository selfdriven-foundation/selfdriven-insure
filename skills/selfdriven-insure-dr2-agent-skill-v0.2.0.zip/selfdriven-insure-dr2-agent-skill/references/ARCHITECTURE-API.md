# Reference Architecture & API Contract

## Layer boundaries
1. **Asset/subject registry**: stable identifiers, ownership/role, addresses or country itinerary, technology dependencies, coverage scope.
2. **Evidence intake & VCG**: immutable evidence payloads, trust policy, versioned assertions, provenance graph, disputes.
3. **Feature materialiser**: effective-time joins, type validation, missingness, lineage, policy gating.
4. **Line/peril adapters**: calibrated/scaffold frequency, severity, catastrophe, event and dependencies; domain-specific loss definition.
5. **Policy terms evaluator**: trigger, exclusions, excess/deductible, waiting period, sublimits, limits, basis of settlement and aggregation; deterministic on event/claim records.
6. **Assessment & uncertainty**: loss distribution, uncertainty, attribution, status, insured vs gross basis.
7. **Decision support**: insurer-authorised referral flags, mitigation pathways, versioned human decisions, audit.
8. **Presentation**: user scores derived from calibrated measures; clear uncalibrated/research flags.

### Model adapter interface (TypeScript design)
```ts
interface AssessmentContext {
  subjectId: string;
  line: 'home_contents'|'strata'|'sme'|'travel'|'cyber';
  perilId: string;
  coverageId: string;
  periodStart: string; periodEnd: string;
  jurisdiction: string;
  policyTermsVersion: string;
  asOf: string;
  inputSnapshotHash: string;
}
interface ModelAdapter {
  manifest(): ModelManifest;
  requirements(): FeatureRequirement[];
  assess(context: AssessmentContext, features: ResolvedFeatures,
         terms: PolicyTerms): Promise<RiskResult>;
}
interface RiskResult {
  status: 'research_only'|'calibrated'|'model_unavailable'|'requires_human_review';
  annualisationBasis: 'year'|'trip'|'person_day'|'policy_period'|'event';
  lossBasis: 'gross'|'insured_payment';
  expectedLoss?: { amount: number; currency: string };
  distribution?: unknown;
  uncertainty: { status: 'quantified'|'unquantified'; method?: string };
  explanations: { factorId: string; perilId: string; lossMechanism: string;
                  evidenceIds: string[]; impact?: number }[];
  modelManifestId: string;
}
```
No adapter should invent outputs when its manifest requires missing inputs. Optional line-specific extensions should be versioned, not tucked inside free-text comments.

## Proposed APIs
- `POST /v1/subjects`; `GET /v1/subjects/{id}`
- `PUT /v1/subjects/{id}/profiles/{line}` (optimistic concurrency / ETag)
- `POST /v1/evidence` (idempotency key + immutable receipt)
- `POST /v1/evidence/{id}/verify` (auth-required role)
- `POST /v1/assessments` (snapshot, model/policy version selection)
- `GET /v1/assessments/{id}` (immutable versioned result)
- `GET /v1/subjects/{id}/trajectory` (version-aware trend)
- `GET /v1/models/{model_id}/manifest`
- `POST /v1/overrides` (two-person rule where policy requires)

## Sample assessment request
```json
{
 "subject_id":"demo-home-1", "line":"home_contents",
 "components":[{"coverage_id":"building","peril_id":"fire"}],
 "period":{"start":"2026-11-20","end":"2027-11-19"},
 "jurisdiction":"AU-NSW", "policy_terms_version":"research-terms-v1",
 "as_of":"2026-11-20T00:00:00Z", "purpose":"research_only"
}
```

## Storage and event design
- Canonical operational store: transactional subject/profile/coverage metadata.
- Evidence object store: encrypted with immutable object IDs and retention controls.
- Event log: append-only assertion/verification/revocation/override events.
- Assessment snapshots: freeze feature values, source IDs, trust policy, model parameters, policy terms, jurisdiction, software version, execution environment and output.
- Graph index: derived query projection; not the authoritative legal record by itself.
- Async events: `evidence.received`, `evidence.verified`, `risk.material_change_candidate`, `assessment.completed`, `assessment.review_required`.

## Reproducibility
Canonical input serialization + exact model artifact hash + parameter set + terms version + rule version + effective time + seed (if stochastic) produces an audit `assessment_hash`. A hash proves byte-level consistency, not result accuracy. For stochastic models document convergence and sampling variability. Currency/timezone rules, inflation/indexation basis and numeric precision must be pinned.

## Security
Tenant isolation, KMS-managed encryption, principle of least privilege, protection against prompt injection in document evidence, safe file handling, authenticated issuer registry, monitoring and rate limits. Never let an agent promote a model or assume underwriting authority through tool calls.
