# DR² v0.1 — Executable Reference Specification

**Draft 0.1 — 23 October 2026**  
**Scope:** commercial property, fire/property damage only  
**Status:** exploratory, unvalidated, synthetic

## 1. Purpose

This is the first executable slice of the wider selfdriven.insure **Dynamic Risk & Resilience (DR²)** specification. It preserves property COPE classifications and separates three independently reviewable quantities:

1. The asset's COPE characteristics, including declared protection features.
2. Independently submitted evidence that a specific control is operational.
3. The *modelled* impact, for a given peril, of controls whose evidence meets a configured acceptance policy.

This stage **does not** assert that the computed values are calibrated representations of any actual Australian property insurance portfolio. Computation and evidence verification can be proven correct while predictions are still wrong.

## 2. Canonical objects

### Asset

Each asset has `asset_id`, `currency=AUD`, `sum_insured_aud`, and a `cope` object:

| COPE group | v0.1 required attribute | Allowed values |
|---|---|---|
| Construction | `primary_material` | steel, masonry, timber, concrete |
| Occupancy | `primary_use` | warehouse, office, light_industrial, hospitality |
| Protection | `declared_controls` | three Boolean-or-null fields |
| Exposure | `external_fire_hazard` | low, moderate, high |

`null` means unknown, **not** that the protection does not exist. The narrow vocabulary is a reference implementation convenience. Future vocabularies need explicit versioning and jurisdictional alignment rather than silently changing the meaning of fields.

### Evidence

An evidence assertion contains:

`evidence_id`, `asset_id`, `predicate`, `value`, `issuer_id`, `method`, `observed_at`, `valid_until` and optional `digest_sha256`, `signature_b64`.

The three v0.1 predicates are:

- `control.sprinkler_system.operational`
- `control.smoke_detection.operational`
- `control.electrical_inspection.operational`

The **entire submitted payload excluding digest and signature** is signed using Ed25519 over the v0.1 sorted-key JSON string encoding. `digest_sha256` is the hex SHA-256 of the same canonical payload.

This implementation's encoding is **not RFC 8785 JCS** and is not guaranteed portable to other programming languages. For multi-language deployments, explicitly adopt and test a standards-based cross-runtime canonicalisation format with conformance vectors.

An `issuer_id` is only trusted if its public key and accepted inspection method were provisioned **out of band** in the trust registry. A record is eligible only if:

- The issuer exists as an own entry in the registry.
- The payload digest matches.
- The Ed25519 signature validates.
- The issuer's policy accepts the attestation method (`inspection` or `sensor`).
- `observed_at <= as_of < valid_until`.
- The assertion is not contradicted by another eligible assertion for the same control.
- A COPE `false` declaration does not contradict a signed `true` control statement.

Actual inspection accreditation, key ownership, physical inspection validity, replay attacks, certificate chains and key revocation are **not** addressed by this local prototype.

### Control state

`unknown`, `disputed`, `verified_true`, or `verified_false`.

- `verified_true`: control eligible for mitigation credit **under the configured demonstration policy**.
- `verified_false`: eligible evidence supports that the control is not operational; no credit.
- `unknown`: no eligible evidence; no credit but no assertion that the control is absent.
- `disputed`: eligible conflicting evidence, or a true attestation conflicting with a false COPE declaration; no credit.

The use of `verified` refers strictly to authenticated qualifying evidence within this prototype, **not** proof of actual control effectiveness.

## 3. Reference fire risk calculation

For steel/warehouse/moderate external hazard:

- Base probability of one fire property-damage claim in a year = `0.015`.
- Base conditional mean severity = `20% × sum_insured`.

Other classes use the factors below, all **illustrative**:

| Factor | Construction frequency | Construction severity |
|---|---:|---:|
| Steel | 1.00 | 1.00 |
| Masonry | 0.85 | 0.90 |
| Timber | 1.40 | 1.25 |
| Concrete | 0.75 | 0.80 |

| Occupancy | Frequency factor |
|---|---:|
| Warehouse | 1.00 |
| Office | 0.65 |
| Light industrial | 1.30 |
| Hospitality | 1.50 |

| External fire hazard | Frequency factor |
|---|---:|
| Low | 0.80 |
| Moderate | 1.00 |
| High | 1.40 |

Let:

`p0 = min(1, 0.015 × C_frequency × O_frequency × E_frequency)`

`mu0 = min(sum_insured_aud, 0.20 × sum_insured_aud × C_severity)`

`EAL0 = p0 × mu0`

Then independently authenticated **operational-control** indicators in the demonstration model apply:

| Control | Conditional effect | Illustrative reduction |
|---|---|---:|
| Sprinklers | Conditional mean severity | 45% |
| Smoke detection | Conditional mean severity | 15% |
| Electrical inspection | Fire claim probability | 20% |

`p1 = p0 × (0.8 if electrical inspection eligible else 1)`

`mu1 = mu0 × (0.55 if sprinklers eligible else 1) × (0.85 if smoke detection eligible else 1)`

`EAL1 = p1 × mu1`

`EAL_reduction = EAL0 − EAL1`

**Important:** this model uses Bernoulli single-claim probability, *not* a Poisson count-rate interpretation, so `EAL = p × mu` is valid for the defined single-event toy model. It is not a frequency model suitable for general commercial property claims, multiple events, catastrophe clustering, inflation, policy limits, deductibles, reinstatement, sublimits or exposure period differences.

Synthetic control reductions are compounded multiplicatively for implementation convenience. Real controls interact; double-counting must be addressed in an actuarily calibrated implementation.

## 4. Assessment output contract

Every assessment includes:

- Stable `assessment_id` derived from assessment input and pinned model/policy hashes.
- `input_sha256`, `trust_registry_sha256`, `manifest_sha256`, `result_sha256`.
- Results for one peril and coverage with reference and residual risk.
- Control decision states, eligible evidence IDs, evidence verification result codes and discrepancies.
- Evidence coverage as the fraction of three control facts resolved by eligible attestations.
- Research-only model and underwriting status.
- `null` risk score and premium, with explicitly unquantified uncertainty.

Determinism is tested for the same semantic JSON property order, same evidence array order, same registry and same manifest on the same JavaScript runtime semantics. Array reordering is not normalised. Numerical canonicalisation is a project-specific convention and will require protocol hardening.

The assessment does not persist or disclose the entire input payload. Reproduction requires lawful access to the original input, policy registry and model version.

## 5. Validation requirements

See `VALIDATION-PLAN.md` for evidence, software and actuarial separation.

The model MUST produce the following examples:

| Scenario | Reference EAL | Residual EAL | Expected effect |
|---|---:|---:|---|
| No qualifying evidence | 3000 | 3000 | Declared protection gives no credit |
| Eligible sprinklers only | 3000 | 1650 | Severity ×0.55 |
| Eligible smoke only | 3000 | 2550 | Severity ×0.85 |
| Eligible electrical inspection only | 3000 | 2400 | Frequency ×0.80 |
| Three eligible controls | 3000 | 1122 | Multiplicative modifiers |
| Expired or forged sprinkler evidence | 3000 | 3000 | No credit |
| Conflicting eligible sprinkler attestations | 3000 | 3000 | Disputed/no credit |

All numbers are AUD/year expected-loss *illustrations*, not premium prices.

## 6. Interface

`assess(input, {trustRegistry}) -> result`

`replayCheck(input, registry, previousResult) -> {matches, calculated_hash, previous_hash}`

`signEvidence(unsignedEvidence, privateKey) -> signedEvidence` is provided for development and test utilities only. Production issuers must sign outside the insurer's calculation service, with appropriate identity governance and key custody.

Loopback-only development server:

- `GET /health`
- `GET /v1/models/fire/manifest`
- `POST /v1/assessments`

For the POST, the trust registry must be preconfigured by the operator, never supplied as a caller-chosen trust policy.

## 7. Next feature boundary

Do not promote v0.1 scores into underwriting pricing. First implement storage and issuer policy lifecycle, choose a claims-linked outcome dataset, estimate and validate real peril factors, then add time effects and uncertainty. Future DR² implementations can add resilience, recovery, trajectory and insurability as distinct services rather than forcing these ideas into the fire model.
