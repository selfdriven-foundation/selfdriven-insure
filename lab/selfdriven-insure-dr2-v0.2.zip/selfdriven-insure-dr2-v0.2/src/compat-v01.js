'use strict';
// Migration from the v0.1 commercial-property fire prototype.
// Maps a v0.1 assessment input onto an SME buildings subject. Fields v0.1 never captured
// become explicit nulls (unknown); nothing is defaulted. See docs/V0.1-COMPATIBILITY.md.
function fromV01(v01, {policyTermsVersion = 'migrated-from-v0.1', periodStart, periodEnd} = {}) {
  const a = v01.asset, d = a.cope.protection.declared_controls;
  if (!periodStart || !periodEnd) throw new TypeError('fromV01 requires periodStart and periodEnd: v0.1 had no exposure period');
  return {
    schema_version: '0.2', as_of: v01.as_of, decision_use: 'research', requester_role: 'researcher',
    subject: {
      subject_id: a.asset_id, line: 'sme', jurisdiction: {country: 'AU', state: null},
      ownership: {scope: 'owner_occupier', status: 'unknown'},
      profile: {
        construction: {primary_material: a.cope.construction.primary_material, eps_panel: null},
        occupancy: {primary_use: a.cope.occupancy.primary_use, premises_tenure: null},
        exposure: {external_fire_hazard: a.cope.exposure.external_fire_hazard, flood_hazard_class: null, wind_region: null, theft_hazard_class: null},
        operations: {supplier_concentration: null, alternative_premises: null}
      },
      declared_controls: {sprinkler_system: d.sprinkler_system, smoke_detection: d.smoke_detection, electrical_inspection: d.electrical_inspection,
        monitored_intruder_alarm: null, business_continuity_plan_tested: null}
    },
    policy_terms: {version: policyTermsVersion, wording_ref: null, currency: 'AUD', period: {start: periodStart, end: periodEnd},
      coverages: [{coverage: 'buildings', sum_insured: a.sum_insured_aud, excess: 0, excluded_perils: ['storm', 'flood', 'escape_of_liquid'], sublimits: {}}]},
    // v0.1 signatures covered asset_id; v0.2 signs subject_id. Old signatures cannot be carried over.
    evidence: v01.evidence.map(e => ({evidence_id: e.evidence_id, subject_id: e.asset_id, predicate: e.predicate, value: e.value,
      issuer_id: e.issuer_id, method: e.method, observed_at: e.observed_at, valid_until: e.valid_until}))
  };
}
module.exports = {fromV01};
