'use strict';
const {HAZARD4, WIND, YEAR_BUILT, enumf} = require('./shared');
module.exports = {
  line: 'strata', title: 'Strata (owners corporation / body corporate)', context_profile: 'COPE', period_basis: 'annual',
  // Common property only. Lot-owner contents are a separate subject under home_contents.
  coverages: {
    common_property_building: {exposure: 'sum_insured'},
    common_contents: {exposure: 'sum_insured'}
  },
  perils: ['fire', 'bushfire', 'storm', 'flood', 'escape_of_liquid'],
  matrix: {
    common_property_building: ['fire', 'bushfire', 'storm', 'flood', 'escape_of_liquid'],
    common_contents: ['fire', 'storm', 'flood', 'escape_of_liquid']
  },
  factors: {
    'construction.frame_material': enumf(['concrete', 'masonry', 'steel', 'timber']),
    'construction.storeys_band': enumf(['low_rise_1_3', 'mid_rise_4_8', 'high_rise_9_plus']),
    'construction.year_built_band': enumf(YEAR_BUILT),
    'construction.external_cladding': enumf(['non_combustible', 'combustible_remediated', 'combustible_present']),
    'construction.known_defects': enumf(['none_reported', 'minor', 'major_unrectified']),
    'occupancy.use_mix': enumf(['residential', 'mixed_use_retail', 'mixed_use_hospitality']),
    'occupancy.lots_band': enumf(['l2_10', 'l11_50', 'l51_150', 'l151_plus']),
    'occupancy.short_stay_share': enumf(['low', 'moderate', 'high']),
    'exposure.bushfire_hazard_class': enumf(HAZARD4, {hazard: true}),
    'exposure.flood_hazard_class': enumf(HAZARD4, {hazard: true}),
    'exposure.wind_region': enumf(WIND, {hazard: true})
  },
  controls: ['sprinkler_system', 'annual_fire_safety_statement', 'plumbing_maintenance_program',
    'leak_detection_shutoff', 'roof_membrane_maintenance'],
  ownership_scopes: ['common_property']
};
