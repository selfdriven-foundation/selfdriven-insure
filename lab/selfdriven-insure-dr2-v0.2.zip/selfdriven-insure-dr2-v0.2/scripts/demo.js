#!/usr/bin/env node
'use strict';
// Walkthrough: the same SME and cyber subjects, first with declarations only, then with
// assertions signed in memory by an EPHEMERAL, FICTIONAL issuer key. Synthetic numbers throughout.
const {generateKeyPairSync} = require('node:crypto');
const {assess, signEvidence, replayCheck} = require('../src');
const {BUILDERS, trustPolicyFor, assertion} = require('./lib/examples');
const parameterSet = require('../params/synthetic-fixture-v0.2.json');

const {publicKey, privateKey} = generateKeyPairSync('ed25519');
const trustPolicy = trustPolicyFor('fictional-inspector-1', publicKey.export({type: 'spki', format: 'pem'}));
const sign = (id, name, n) => signEvidence(assertion(id, `control.${name}.operational`, true, n), privateKey);
const show = (label, r) => {
  const t = r.risk.totals.expected_claim_payment;
  console.log(`  ${label.padEnd(34)} status=${r.status.padEnd(22)} expected claim payment AUD ${t.point} (synthetic)  relativity=${r.risk.totals.relativity_to_reference_class}  controls credited=${r.evidence.coverage.credited_eligible_controls}  insurability=${r.insurability.status}`);
};

console.log('RESEARCH ONLY. Synthetic parameter fixture. Not a price, score or decision.\n');
for (const [line, names] of [['sme', ['sprinkler_system', 'smoke_detection', 'electrical_inspection', 'monitored_intruder_alarm']], ['cyber', ['mfa_remote_access', 'mfa_email', 'edr_deployed', 'offline_backups_tested']]]) {
  console.log(line);
  const declared = assess(BUILDERS[line](), {parameterSet, trustPolicy}); show('declarations only (no credit)', declared);
  const input = BUILDERS[line](); input.as_of = '2026-11-21T04:00:00Z';
  input.evidence = names.map((n, i) => sign(input.subject.subject_id, n, i + 1));
  input.prior_snapshot = declared.trajectory.snapshot_for_next_assessment;
  const evidenced = assess(input, {parameterSet, trustPolicy}); show('with eligible signed assertions', evidenced);
  console.log(`  trajectory=${evidenced.trajectory.direction}  replay matches=${replayCheck(input, {parameterSet, trustPolicy}, evidenced).matches}\n`);
}
for (const line of ['home_contents', 'strata', 'travel']) {
  const r = assess(BUILDERS[line](), {parameterSet}); const t = r.risk.totals.expected_claim_payment;
  console.log(`${line}\n  status=${r.status}  point=${t.point}  bounds=[${t.low}, ${t.high}]  insurability=${r.insurability.status}  action=${r.recommendation.action}\n`);
}
console.log('no parameter set\n  status=' + assess(BUILDERS.sme()).status);
