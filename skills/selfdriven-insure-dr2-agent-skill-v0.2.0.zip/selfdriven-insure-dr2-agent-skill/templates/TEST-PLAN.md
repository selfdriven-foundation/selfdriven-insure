# Risk engine test plan — <component>

## Contract
Given / When / Then with subject, peril, coverage, period, policy terms, model version.

## Core cases
- Schema valid/invalid/unknown vs zero; different currencies and basis.
- Missing, expired, untrusted, disputed and revoked evidence.
- Control effect linked to named mechanism, including no unrelated peril credit.
- Deductible/waiting periods at claim/event level.
- Multiple coverages for one event; no duplicated payment.
- Reproducible snapshots and source/model/terms version pinning.
- Extreme values, scenario changes, dependency correlation, calendar boundaries.
- Human referral when model inputs/authority are insufficient.

## Quantitative studies
Baseline, comparator, temporal holdout, segment calibration, stress, bias and uncertainty bounds.

## Review
Owner, independent validator, result, known gaps and production approval status.
