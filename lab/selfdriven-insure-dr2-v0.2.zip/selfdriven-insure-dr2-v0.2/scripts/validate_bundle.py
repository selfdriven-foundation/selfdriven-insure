#!/usr/bin/env python3
"""Bundle integrity check. Run from the package root: python3 scripts/validate_bundle.py

Checks that every JSON file parses, that each example validates against its schema, that the
synthetic parameter set covers every catalog (line, coverage, peril) triple, and that no
result carries a premium or a presentation score. This is a packaging check only. It says
nothing about predictive validity.
"""
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
errors = []


def load(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        errors.append(f"{path.relative_to(ROOT)}: {exc}")
        return None


docs = {p: load(p) for p in sorted(ROOT.glob("assets/**/*.json")) + sorted(ROOT.glob("params/*.json"))}
schemas = ROOT / "assets" / "schemas"
catalog = docs.get(ROOT / "assets" / "catalogs" / "lob-catalog.json")
params = docs.get(ROOT / "params" / "synthetic-fixture-v0.2.json")

if catalog and params:
    for line in catalog["lines"]:
        for cov in line["coverages"]:
            for peril in cov["perils"]:
                key = f'{line["line"]}.{cov["coverage"]}.{peril}'
                if key not in params["components"]:
                    errors.append(f"parameter set has no component {key}")
                if f'{line["line"]}.{peril}' not in params["events"]:
                    errors.append(f'parameter set has no event {line["line"]}.{peril}')
    if params["status"] != "synthetic_fixture" or params["approvals"]:
        errors.append("shipped parameter set must be an unapproved synthetic_fixture")

try:
    from jsonschema import Draft202012Validator
except ImportError:
    Draft202012Validator = None
    print("note: jsonschema not installed; schema validation of examples skipped")

if Draft202012Validator:
    pairs = [("assessment-input.schema.json", "assets/examples/*.input.json"),
             ("assessment-result.schema.json", "assets/examples/*.result.json"),
             ("parameter-set.schema.json", "params/*.json")]
    for schema_name, pattern in pairs:
        schema = docs.get(schemas / schema_name)
        if schema is None:
            errors.append(f"missing schema {schema_name}")
            continue
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(schema)
        for path in sorted(ROOT.glob(pattern)):
            for err in validator.iter_errors(docs[path]):
                errors.append(f"{path.relative_to(ROOT)}: {err.message[:200]}")

for path in sorted(ROOT.glob("assets/examples/*.result.json")):
    result = docs[path]
    if not result:
        continue
    rec = result["recommendation"]
    if rec["premium"] is not None or rec["presentation_score"] is not None or rec["may_bind"] or rec["may_set_premium"]:
        errors.append(f"{path.name}: result carries a premium, score or authority flag")
    if any(c["premium"] is not None for c in result["risk"]["components"]):
        errors.append(f"{path.name}: component carries a premium")

if errors:
    print("\n".join(errors))
    sys.exit(1)
print(f"bundle ok: {len(docs)} JSON files checked")
