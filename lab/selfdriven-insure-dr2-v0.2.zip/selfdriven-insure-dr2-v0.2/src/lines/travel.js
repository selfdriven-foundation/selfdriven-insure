'use strict';
const {enumf, intf} = require('./shared');
module.exports = {
  // No COPE. Assessment unit is a single trip, never an annualised rate.
  line: 'travel', title: 'Travel (single trip)', context_profile: 'travel_trip', period_basis: 'per_trip',
  coverages: {
    overseas_medical: {exposure: 'limit'},
    cancellation: {exposure: 'sum_insured'},
    luggage: {exposure: 'sum_insured'},
    travel_delay: {exposure: 'limit'}
  },
  perils: ['illness_injury', 'cancellation_cause', 'baggage_incident', 'transport_delay'],
  matrix: {
    overseas_medical: ['illness_injury'],
    cancellation: ['cancellation_cause'],
    luggage: ['baggage_incident'],
    travel_delay: ['transport_delay']
  },
  factors: {
    // Bands come from the insurer's own destination mapping, supplied with provenance.
    'trip.destination_medical_cost_band': enumf(['band_1', 'band_2', 'band_3', 'band_4'], {hazard: true}),
    'trip.destination_disruption_band': enumf(['low', 'moderate', 'high'], {hazard: true}),
    'trip.advisory_level': enumf(['level_1', 'level_2', 'level_3', 'level_4'], {hazard: true}),
    'trip.mode': enumf(['land_air', 'cruise']),
    'trip.activities': enumf(['standard', 'snow_sports', 'adventure']),
    'trip.duration_days': intf(1, 365, [[7, 'd1_7'], [14, 'd8_14'], [30, 'd15_30'], [90, 'd31_90'], [365, 'd91_365']]),
    'trip.lead_days': intf(0, 730, [[7, 'l0_7'], [30, 'l8_30'], [90, 'l31_90'], [730, 'l91_plus']]),
    'trip.travellers': intf(1, 20, [[1, 't1'], [2, 't2'], [5, 't3_5'], [20, 't6_plus']])
  },
  // Exposure quantities the engine needs as numbers; null blocks the dependent components.
  required_numerics: ['trip.duration_days', 'trip.travellers'],
  controls: [],
  // Age and health are deliberately NOT rating factors in this build (see docs/GOVERNANCE.md).
  sensitive_block: true,
  ownership_scopes: ['traveller_party']
};
