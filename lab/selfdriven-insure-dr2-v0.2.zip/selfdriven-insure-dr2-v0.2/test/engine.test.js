'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {generateKeyPairSync} = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const dr2 = require('../src');
const {BUILDERS, trustPolicyFor, assertion} = require('../scripts/lib/examples');
const parameterSet = require('../params/synthetic-fixture-v0.2.json');

const {assess, signEvidence, lognormal, layer, phi} = dr2;
const {publicKey, privateKey} = generateKeyPairSync('ed25519');
const pem = publicKey.export({type: 'spki', format: 'pem'});
const trustPolicy = trustPolicyFor('fictional-inspector-1', pem);
const clone = x => JSON.parse(JSON.stringify(x));
const run = (input, extra = {}) => assess(input, {parameterSet, trustPolicy, ...extra});
const comp = (r, key) => r.risk.components.find(c => c.key === key);
const signed = (subject, predicate, value, n, extra) => signEvidence(assertion(subject, predicate, value, n, extra), privateKey);
const control = (subject, name, value, n, extra) => signed(subject, `control.${name}.operational`, value, n, extra);
const close = (a, b, tol = 1e-6) => assert.ok(Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)), `${a} != ${b}`);
const codes = r => r.recommendation.referral_reasons.map(x => x.code);

// ---------- arithmetic ----------
test('normal CDF reference points', () => { close(phi(0), 0.5); close(phi(1.959964), 0.975, 1e-6); close(phi(-1.959964), 0.025, 1e-5); });
test('lognormal limited expected value agrees with independent numerical integration', () => {
  const mean = 20000, cv = 2.5, d = lognormal(mean, cv), s2 = Math.log(1 + cv * cv), s = Math.sqrt(s2), mu = Math.log(mean) - s2 / 2;
  for (const u of [500, 5000, 50000, 400000]) {
    // E[min(X,u)] = integral_0^u S(x) dx, midpoint rule on a log grid, using the engine-independent erf-free survival via phi.
    let acc = 0; const n = 200000, lo = Math.log(1e-6), hi = Math.log(u), h = (hi - lo) / n;
    for (let i = 0; i < n; i++) { const x = Math.exp(lo + (i + 0.5) * h); acc += (1 - phi((Math.log(x) - mu) / s)) * x * h; }
    close(d.lev(u), acc + 1e-6, 2e-4);
  }
  close(d.lev(Infinity), mean); assert.equal(d.lev(0), 0);
});
test('layer: no excess, no cap, no limit pays the mean; excess lowers payment but not gross', () => {
  const d = lognormal(1000, 1.5);
  close(layer(d, {}).expected_payment_per_event, 1000);
  const a = layer(d, {excess: 200}), b = layer(d, {excess: 800});
  assert.ok(a.expected_payment_per_event > b.expected_payment_per_event); close(a.expected_gross_loss_per_event, b.expected_gross_loss_per_event);
  assert.ok(a.probability_event_becomes_claim < 1 && a.probability_event_becomes_claim > b.probability_event_becomes_claim);
  assert.equal(layer(d, {excess: 100, limit: 0}).expected_payment_per_event, 0);
});

// ---------- scope and catalog ----------
test('catalog: five lines; COPE only for physical property', () => {
  const lines = Object.fromEntries(dr2.catalog().lines.map(l => [l.line, l]));
  assert.deepEqual(Object.keys(lines).sort(), ['cyber', 'home_contents', 'sme', 'strata', 'travel']);
  for (const l of ['home_contents', 'strata', 'sme']) assert.equal(lines[l].context_profile, 'COPE');
  assert.equal(lines.travel.context_profile, 'travel_trip'); assert.equal(lines.cyber.context_profile, 'cyber_organisation');
  assert.equal(lines.travel.period_basis, 'per_trip');
});
test('every example assesses, hashes and matches the shipped result file', () => {
  for (const [line, build] of Object.entries(BUILDERS)) {
    const r = assess(build(), {parameterSet});
    const shipped = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'assets', 'examples', `${line}.result.json`), 'utf8'));
    assert.equal(r.result_sha256, shipped.result_sha256, line);
    assert.equal(r.recommendation.premium, null); assert.equal(r.recommendation.presentation_score, null);
    assert.ok(r.risk.components.every(c => c.premium === null));
    assert.ok(['research_only', 'requires_human_review'].includes(r.status));
  }
});

// ---------- no fabricated numbers ----------
test('without a parameter set the engine returns model_unavailable and no loss figures', () => {
  const r = assess(BUILDERS.sme());
  assert.equal(r.status, 'model_unavailable'); assert.equal(r.model.status, 'model_unavailable');
  assert.ok(r.risk.components.every(c => c.status === 'model_unavailable' && !c.residual));
  assert.equal(r.risk.totals.expected_claim_payment.point, null); assert.equal(r.insurability.status, 'not_assessed');
});
test('unsupported jurisdiction is model_unavailable even with parameters', () => {
  const i = BUILDERS.home_contents(); i.subject.jurisdiction = {country: 'NZ', state: null};
  const r = run(i); assert.equal(r.status, 'model_unavailable'); assert.ok(r.risk.components.every(c => c.reason === 'jurisdiction_not_supported'));
});
test('synthetic parameters are always reported as research_only with no authority', () => {
  const r = run(BUILDERS.sme());
  assert.equal(r.model.status, 'research_only'); assert.equal(r.model.parameter_set.status, 'synthetic_fixture');
  for (const k of ['may_bind', 'may_decline', 'may_vary_or_cancel', 'may_set_premium']) assert.equal(r.recommendation[k], false);
  assert.match(r.caveats[0], /SYNTHETIC/);
});
test('pricing, bind, decline and vary requests are referred, never actioned', () => {
  for (const [use, code] of [['pricing', 'pricing_requested_without_calibrated_model'], ['bind', 'action_would_bind_decline_or_alter_cover'], ['decline', 'action_would_bind_decline_or_alter_cover'], ['vary_or_cancel', 'action_would_bind_decline_or_alter_cover']]) {
    const i = BUILDERS.sme(); i.decision_use = use; const r = run(i);
    assert.equal(r.status, 'requires_human_review'); assert.ok(codes(r).includes(code)); assert.equal(r.recommendation.premium, null);
  }
});

// ---------- hand-checked component values ----------
test('SME theft: frequency and severity follow the pinned tables', () => {
  const c = comp(run(BUILDERS.sme()), 'sme.contents.theft');
  close(c.residual.point.loss_event_frequency, 0.04 * 1 * 1.2); close(c.residual.point.conditional_mean_ground_up_severity, 0.05 * 400000);
  const L = layer(lognormal(20000, 1.5), {cap: 400000, excess: 1000, limit: 400000});
  close(c.residual.point.expected_claim_payment, 0.048 * L.expected_payment_per_event, 1e-4);
  assert.ok(c.residual.point.expected_claim_count < c.residual.point.loss_event_frequency, 'loss events below the excess are not claims');
  assert.ok(c.residual.point.expected_claim_payment < c.residual.point.gross_expected_loss);
});
test('annual lines scale frequency with the exposure period', () => {
  const i = BUILDERS.sme(); i.policy_terms.period.end = '2027-06-01T00:00:00Z'; // 182 days
  const full = comp(run(BUILDERS.sme()), 'sme.contents.theft').residual.point.loss_event_frequency;
  close(comp(run(i), 'sme.contents.theft').residual.point.loss_event_frequency, full * 182 / 365, 1e-6);
});

// ---------- evidence ----------
test('declared controls earn nothing; eligible signed evidence earns the pinned effect on the right mechanism', () => {
  const base = run(BUILDERS.sme()), b = comp(base, 'sme.buildings.fire');
  assert.equal(base.evidence.controls.sprinkler_system.state, 'unknown'); assert.equal(base.evidence.controls.sprinkler_system.declared, true);
  assert.equal(b.modelled_control_effect_on_expected_claim_payment, 0);
  const i = BUILDERS.sme(); const id = i.subject.subject_id;
  i.evidence = [control(id, 'sprinkler_system', true, 1), control(id, 'smoke_detection', true, 2), control(id, 'electrical_inspection', true, 3)];
  const r = run(i), c = comp(r, 'sme.buildings.fire');
  close(c.residual.point.loss_event_frequency, 0.015 * 0.8); // electrical inspection acts on frequency only
  close(c.residual.point.conditional_mean_ground_up_severity, 200000 * 0.55 * 0.85); // sprinkler and smoke act on severity only
  close(c.unmitigated.expected_claim_payment, b.residual.point.expected_claim_payment);
  assert.ok(c.modelled_control_effect_on_expected_claim_payment > 0);
  assert.equal(comp(r, 'sme.contents.theft').residual.point.expected_claim_payment, comp(base, 'sme.contents.theft').residual.point.expected_claim_payment, 'fire controls do not touch theft');
  assert.equal(r.evidence.coverage.credited_eligible_controls, 3);
});
const noCredit = (name, mutate, expectStatus, policy = trustPolicy) => test(`no credit: ${name}`, () => {
  const i = BUILDERS.sme(); let e = control(i.subject.subject_id, 'sprinkler_system', true, 1); e = mutate(e, i) || e; i.evidence = [e];
  const r = assess(i, {parameterSet, trustPolicy: policy});
  assert.equal(r.evidence.records[0].status, expectStatus);
  assert.notEqual(r.evidence.controls.sprinkler_system.state, 'verified_true');
  close(comp(r, 'sme.buildings.fire').residual.point.conditional_mean_ground_up_severity, 200000);
  return r;
});
noCredit('unsigned assertion', e => { delete e.signature_b64; delete e.digest_sha256; }, 'missing_or_invalid_digest');
noCredit('tampered value', e => ({...e, valid_until: '2029-01-01T00:00:00Z'}), 'missing_or_invalid_digest');
noCredit('forged signature', e => ({...e, signature_b64: Buffer.alloc(64, 7).toString('base64')}), 'missing_or_invalid_signature');
noCredit('expired', (e, i) => signed(i.subject.subject_id, e.predicate, true, 1, {valid_until: '2026-11-10T00:00:00Z'}), 'expired');
noCredit('observed in the future', (e, i) => signed(i.subject.subject_id, e.predicate, true, 1, {observed_at: '2026-12-01T00:00:00Z'}), 'future_observation');
noCredit('observed before the issuer was trusted', (e, i) => signed(i.subject.subject_id, e.predicate, true, 1, {observed_at: '2025-01-01T00:00:00Z', valid_until: '2028-01-01T00:00:00Z'}), 'issuer_not_valid_at_observation');
noCredit('older than max age', () => {}, 'stale', {...trustPolicy, max_evidence_age_days: {default: 5}});
noCredit('revoked evidence', () => {}, 'revoked_evidence', {...trustPolicy, revoked_evidence_ids: ['ev-1']});
noCredit('revoked issuer', () => {}, 'issuer_revoked', trustPolicyFor('fictional-inspector-1', pem, {revoked_at: '2026-11-15T00:00:00Z'}));
noCredit('method not accepted for issuer', (e, i) => signed(i.subject.subject_id, e.predicate, true, 1, {method: 'registry_lookup'}), 'unaccepted_method');
noCredit('predicate outside issuer scope', () => {}, 'predicate_outside_issuer_scope', trustPolicyFor('fictional-inspector-1', pem, {accepted_predicate_prefixes: ['fact.']}));
test('signed assertion without a trust anchor is referred, and a self-supplied key is never trusted', () => {
  const i = BUILDERS.sme(); i.evidence = [control(i.subject.subject_id, 'sprinkler_system', true, 1)];
  const r = assess(i, {parameterSet}); // no operator trust policy
  assert.equal(r.evidence.records[0].status, 'untrusted_issuer'); assert.ok(codes(r).includes('trust_anchor_missing_for_claimed_verification'));
  assert.throws(() => assess({...i, trust_policy: trustPolicy}, {parameterSet}), /unknown field/);
});
test('self_declaration can never be configured as a creditable method', () => {
  const p = clone(trustPolicy); p.issuers['fictional-inspector-1'].accepted_methods.push('self_declaration');
  assert.throws(() => assess(BUILDERS.sme(), {parameterSet, trustPolicy: p}), /accepted_methods/);
});
test('conflicting eligible assertions and declaration conflicts are disputed, uncredited and referred', () => {
  const i = BUILDERS.sme(), id = i.subject.subject_id;
  i.evidence = [control(id, 'sprinkler_system', true, 1), control(id, 'sprinkler_system', false, 2), control(id, 'business_continuity_plan_tested', true, 3)];
  const r = run(i);
  assert.equal(r.evidence.controls.sprinkler_system.state, 'disputed');
  assert.equal(r.evidence.controls.business_continuity_plan_tested.state, 'disputed', 'declared false vs eligible true');
  assert.equal(r.status, 'requires_human_review'); assert.equal(codes(r).filter(c => c === 'evidence_conflict').length, 2);
  close(comp(r, 'sme.buildings.fire').residual.point.conditional_mean_ground_up_severity, 200000);
});
test('verified_false is recorded, uncredited and distinct from unknown', () => {
  const i = BUILDERS.sme(); i.evidence = [control(i.subject.subject_id, 'sprinkler_system', false, 1)];
  const r = run(i); assert.equal(r.evidence.controls.sprinkler_system.state, 'verified_false');
  assert.equal(r.evidence.controls.smoke_detection.state, 'unknown'); assert.equal(r.evidence.coverage.resolved_controls, 1);
});

// ---------- unknown / not applicable ----------
test('unknown fact gives bounds, no point estimate and an information request', () => {
  const r = run(BUILDERS.home_contents()), c = comp(r, 'home_contents.building.flood');
  assert.equal(c.status, 'computed_bounds_only'); assert.equal(c.residual.point, null);
  assert.ok(c.residual.low.expected_claim_payment < c.residual.high.expected_claim_payment);
  close(c.residual.high.loss_event_frequency / c.residual.low.loss_event_frequency, 150, 1e-6);
  assert.equal(r.risk.totals.expected_claim_payment.point, null);
  assert.ok(r.recommendation.information_requests.some(x => x.item === 'fact.exposure.flood_hazard_class'));
  assert.equal(r.insurability.status, 'information_required'); assert.equal(c.uncertainty.status, 'unquantified');
  assert.equal(comp(r, 'home_contents.building.fire').status, 'computed', 'unknown flood class does not contaminate fire');
});
test('a known value falls inside the unknown bounds; eligible fact evidence can resolve an unknown', () => {
  const unknown = run(BUILDERS.home_contents()).risk.totals.expected_claim_payment;
  const i = BUILDERS.home_contents(); i.subject.profile.exposure.flood_hazard_class = 'high';
  const p = run(i).risk.totals.expected_claim_payment.point; assert.ok(p > unknown.low && p < unknown.high);
  const j = BUILDERS.home_contents(); j.evidence = [signed(j.subject.subject_id, 'fact.exposure.flood_hazard_class', 'high', 1)];
  const r = run(j); assert.equal(r.evidence.facts['exposure.flood_hazard_class'].state, 'verified'); assert.equal(r.risk.totals.expected_claim_payment.point, p);
});
test('fact evidence contradicting a declaration is disputed: bounds only and referral', () => {
  const i = BUILDERS.strata(); i.evidence = [signed(i.subject.subject_id, 'fact.construction.external_cladding', 'non_combustible', 1)];
  const r = run(i); assert.equal(r.evidence.facts['construction.external_cladding'].state, 'disputed');
  assert.equal(comp(r, 'strata.common_property_building.fire').residual.point, null); assert.ok(codes(r).includes('evidence_conflict'));
});
test('not_applicable is accepted only where defined and is not treated as unknown', () => {
  const i = BUILDERS.sme(); i.subject.profile.operations.alternative_premises = 'not_applicable';
  const c = comp(run(i), 'sme.loss_of_profits.fire'); assert.equal(c.status, 'computed');
  assert.equal(c.explanation.severity_factors.find(f => f.factor === 'operations.alternative_premises').state, 'not_applicable');
  const j = BUILDERS.sme(); j.subject.profile.construction.eps_panel = 'not_applicable';
  assert.throws(() => run(j), /not_applicable is not permitted/);
  const k = BUILDERS.sme(); delete k.subject.profile.construction.eps_panel;
  assert.throws(() => run(k), /required \(use null for unknown/);
});

// ---------- policy terms ----------
test('excluded peril: loss event still modelled, claim payment zero', () => {
  const i = BUILDERS.home_contents(); i.policy_terms.coverages[0].excluded_perils = ['bushfire'];
  const c = comp(run(i), 'home_contents.building.bushfire');
  assert.equal(c.status, 'excluded_by_policy_terms'); assert.equal(c.residual.point.expected_claim_payment, 0); assert.equal(c.residual.point.expected_claim_count, 0);
  assert.ok(c.residual.point.gross_expected_loss > 0);
});
test('sublimit caps the claim payment per event', () => {
  const i = BUILDERS.strata(), with_ = comp(run(i), 'strata.common_property_building.escape_of_liquid');
  i.policy_terms.coverages[0].sublimits = {}; const without = comp(run(i), 'strata.common_property_building.escape_of_liquid');
  assert.ok(with_.residual.point.expected_claim_payment < without.residual.point.expected_claim_payment);
  assert.equal(with_.terms_applied.payment_limit, 500000); close(with_.residual.point.gross_expected_loss, without.residual.point.gross_expected_loss);
});

// ---------- SME time element ----------
test('business interruption and loss of profits are never summed without an allocation rule', () => {
  const i = BUILDERS.sme(); delete i.policy_terms.overlap_allocation; const r = run(i);
  assert.ok(codes(r).includes('overlapping_covers_without_allocation_rule')); assert.equal(r.status, 'requires_human_review');
  assert.ok(r.risk.components.filter(c => /business_interruption|loss_of_profits/.test(c.key)).every(c => c.included_in_totals === false));
  assert.ok(!('business_interruption' in r.risk.totals.by_coverage) && !('loss_of_profits' in r.risk.totals.by_coverage));
  const a = run(BUILDERS.sme());
  assert.ok('loss_of_profits' in a.risk.totals.by_coverage && !('business_interruption' in a.risk.totals.by_coverage));
  assert.equal(comp(a, 'sme.business_interruption.fire').totals_exclusion_reason, 'overlap_allocated_to_primary_coverage');
});
test('time element: waiting days act as the excess, indemnity period as the cap, BCP acts on duration', () => {
  const r = run(BUILDERS.sme()), c = comp(r, 'sme.loss_of_profits.fire'), daily = 600000 / 365;
  close(c.terms_applied.daily_amount, daily, 1e-5); close(c.terms_applied.excess, daily * 2, 1e-5); close(c.terms_applied.loss_cap, 600000, 1e-6);
  close(c.residual.point.loss_event_frequency, 0.015 * 0.6); // shares the fire event with buildings
  close(c.residual.point.conditional_mean_ground_up_severity, daily * 60 * 1.2 * 1, 1e-6);
  const i = BUILDERS.sme(); i.subject.declared_controls.business_continuity_plan_tested = true; i.evidence = [control(i.subject.subject_id, 'business_continuity_plan_tested', true, 1)];
  const m = run(i); close(comp(m, 'sme.loss_of_profits.fire').residual.point.conditional_mean_ground_up_severity, daily * 60 * 1.2 * 0.8, 1e-6);
  assert.equal(comp(m, 'sme.buildings.fire').residual.point.expected_claim_payment, comp(r, 'sme.buildings.fire').residual.point.expected_claim_payment);
});

// ---------- strata ----------
test('strata: common property only; cladding drives referral separately from loss', () => {
  const i = BUILDERS.strata(); i.subject.ownership.scope = 'contents_only_lot_owner';
  assert.throws(() => run(i), /ownership.scope/);
  const r = run(BUILDERS.strata());
  assert.equal(r.insurability.status, 'refer'); assert.equal(r.insurability.decision, null); assert.equal(r.insurability.triggers[0].rule_id, 'ST-01');
  assert.ok(r.risk.totals.expected_claim_payment.point > 0, 'loss is still modelled when a constraint triggers');
  const j = BUILDERS.strata(); j.subject.profile.construction.external_cladding = 'non_combustible';
  assert.equal(run(j).insurability.status, 'no_constraint_triggered');
});

// ---------- travel ----------
test('travel is per trip: exposure follows trip days and travellers, not an annual period', () => {
  const r = run(BUILDERS.travel()), c = comp(r, 'travel.overseas_medical.illness_injury');
  close(c.residual.point.loss_event_frequency, 0.002 * 14 * 2); close(c.residual.point.conditional_mean_ground_up_severity, 4000 * 2);
  assert.equal(c.terms_applied.payment_limit, null); assert.equal(c.period_basis, 'per_trip'); assert.equal(c.exposure.trip_days, 14);
  const i = BUILDERS.travel(); i.subject.profile.trip.duration_days = 28;
  close(comp(run(i), 'travel.overseas_medical.illness_injury').residual.point.loss_event_frequency, 0.002 * 28 * 2);
  const j = BUILDERS.travel(); j.subject.profile.trip.duration_days = null; const u = run(j);
  assert.equal(comp(u, 'travel.overseas_medical.illness_injury').status, 'insufficient_data');
  assert.equal(comp(u, 'travel.cancellation.cancellation_cause').status, 'computed'); assert.equal(u.risk.totals.incomplete, true);
});
test('travel has no COPE and no controls; health and age detail is refused', () => {
  const i = BUILDERS.travel(); i.subject.profile.construction = {};
  assert.throws(() => run(i), /unknown field/);
  const j = BUILDERS.travel(); j.subject.sensitive.conditions = ['x'];
  assert.throws(() => run(j), /unknown field/);
  const k = BUILDERS.travel(); k.subject.profile.trip.traveller_age = 70;
  assert.throws(() => run(k), /unknown field/);
  assert.equal(run(BUILDERS.travel()).evidence.coverage.control_resolved_share, null);
});
test('medical screening without consent and lawful basis references is referred', () => {
  const i = BUILDERS.travel(); i.subject.sensitive.medical_screening_used = true;
  assert.ok(codes(run(i)).includes('medical_underwriting_consent_or_basis_unclear'));
  i.subject.sensitive.consent_ref = 'consent/1'; i.subject.sensitive.lawful_basis_ref = 'basis/1';
  assert.ok(!codes(run(i)).includes('medical_underwriting_consent_or_basis_unclear'));
});
test('elevated travel advisory is a referral, not a decline', () => {
  const i = BUILDERS.travel(); i.subject.profile.trip.advisory_level = 'level_4'; const r = run(i);
  assert.equal(r.insurability.status, 'refer'); assert.equal(r.recommendation.action, 'refer_to_human_underwriter'); assert.equal(r.recommendation.may_decline, false);
});

// ---------- cyber ----------
test('cyber: shared-cause event groups and dependency accumulation keys', () => {
  const r = run(BUILDERS.cyber()), g = r.risk.shared_cause.event_groups.find(x => x.event === 'cyber.ransomware');
  assert.deepEqual(g.components.sort(), ['cyber.cyber_business_interruption.ransomware', 'cyber.data_restoration.ransomware', 'cyber.incident_response.ransomware']);
  assert.deepEqual(r.risk.shared_cause.accumulation_keys.map(k => k.key), ['dependency:cloud_provider:fictional-cloud-a', 'dependency:managed_service_provider:fictional-msp-b']);
  const f = new Set(g.components.map(k => comp(r, k).explanation.frequency_factors.map(x => x.multiplier).join()));
  assert.equal(f.size, 1, 'one event frequency model per peril');
});
test('cyber controls act per peril and mechanism; MFA evidence of failure refers', () => {
  const base = run(BUILDERS.cyber()), i = BUILDERS.cyber(), id = i.subject.subject_id;
  i.evidence = [control(id, 'mfa_email', true, 1), control(id, 'offline_backups_tested', true, 2)];
  const r = run(i);
  close(comp(r, 'cyber.funds_transfer_fraud.business_email_compromise').residual.point.loss_event_frequency, comp(base, 'cyber.funds_transfer_fraud.business_email_compromise').residual.point.loss_event_frequency * 0.5, 1e-6);
  assert.equal(comp(r, 'cyber.incident_response.ransomware').residual.point.loss_event_frequency, comp(base, 'cyber.incident_response.ransomware').residual.point.loss_event_frequency, 'email MFA does not touch ransomware frequency');
  close(comp(r, 'cyber.cyber_business_interruption.ransomware').residual.point.conditional_mean_ground_up_severity, comp(base, 'cyber.cyber_business_interruption.ransomware').residual.point.conditional_mean_ground_up_severity * 0.5, 1e-5);
  assert.equal(base.insurability.status, 'information_required'); assert.equal(r.insurability.status, 'no_constraint_triggered');
  const j = BUILDERS.cyber(); j.evidence = [control(id, 'mfa_remote_access', false, 1)]; const f = run(j);
  assert.equal(f.insurability.status, 'refer'); assert.ok(f.evidence.issues.some(x => x.code === 'eligible_assertion_disagrees_with_declaration'));
});

// ---------- reproducibility ----------
test('deterministic replay; key order is irrelevant; any change moves the hash', () => {
  const i = BUILDERS.cyber(), a = run(i), rev = o => Object.fromEntries(Object.entries(o).reverse());
  const shuffled = rev({...clone(i), subject: rev(clone(i.subject)), policy_terms: rev(clone(i.policy_terms))});
  assert.notEqual(JSON.stringify(shuffled), JSON.stringify(i));
  assert.equal(run(shuffled).result_sha256, a.result_sha256);
  assert.equal(dr2.replayCheck(i, {parameterSet, trustPolicy}, a).matches, true);
  const p2 = clone(parameterSet); p2.events['cyber.ransomware'].base_rate = 0.031;
  const b = assess(i, {parameterSet: p2, trustPolicy});
  assert.notEqual(b.result_sha256, a.result_sha256); assert.notEqual(b.reproducibility.parameter_set_sha256, a.reproducibility.parameter_set_sha256); assert.notEqual(b.assessment_id, a.assessment_id);
  const j = clone(i); j.policy_terms.version = 'cyber-2026.2'; assert.notEqual(run(j).reproducibility.policy_terms_sha256, a.reproducibility.policy_terms_sha256);
  for (const k of ['input_sha256', 'trust_policy_sha256', 'parameter_set_sha256']) assert.match(a.reproducibility[k], /^[a-f0-9]{64}$/);
  assert.match(a.model.manifest_sha256, /^[a-f0-9]{64}$/); assert.equal(a.assessment_unit.policy_terms_version, 'cyber-2026.1');
});

// ---------- trajectory ----------
test('trajectory compares only comparable snapshots', () => {
  const first = run(BUILDERS.sme()); assert.equal(first.trajectory.direction, 'indeterminate');
  const i = BUILDERS.sme(); i.as_of = '2026-11-25T00:00:00Z'; i.prior_snapshot = first.trajectory.snapshot_for_next_assessment;
  i.evidence = [control(i.subject.subject_id, 'sprinkler_system', true, 1)];
  const second = run(i); assert.equal(second.trajectory.direction, 'improving'); assert.ok(second.trajectory.relative_change_in_expected_claim_payment < -0.05);
  assert.ok(second.trajectory.change_in_control_resolved_share > 0);
  const same = BUILDERS.sme(); same.as_of = '2026-11-25T00:00:00Z'; same.prior_snapshot = first.trajectory.snapshot_for_next_assessment;
  assert.equal(run(same).trajectory.direction, 'stable');
  const p2 = clone(parameterSet); p2.events['sme.fire'].base_rate = 0.03;
  assert.match(assess(same, {parameterSet: p2, trustPolicy}).trajectory.reason, /not_comparable/);
});

// ---------- parameter-set governance ----------
test('parameter set validation rejects unsafe or incomplete sets', () => {
  const bad = f => { const p = clone(parameterSet); f(p); assert.throws(() => assess(BUILDERS.sme(), {parameterSet: p}), dr2.ParameterSetError); };
  bad(p => { p.components['sme.buildings.fire'].controls.push({control: 'electrical_inspection', target: 'conditional_severity', multiplier: 0.9, effect_basis: 'x'}); }); // double count
  bad(p => { p.components['sme.buildings.fire'].controls[0].multiplier = 1.2; });
  bad(p => { delete p.components['sme.buildings.fire'].controls[0].effect_basis; });
  bad(p => { delete p.events['sme.fire'].factors[0].table.timber; });
  bad(p => { p.status = 'calibrated'; });
  bad(p => { p.components['travel.overseas_medical.illness_injury'].severity.basis = 'share_of_exposure'; });
  bad(p => { p.events['travel.illness_injury'].unit = 'per_year'; });
  bad(p => { p.insurability_rules[0].outcome = 'decline'; });
});
test('a missing component model is reported, not guessed, and totals are flagged incomplete', () => {
  const p = clone(parameterSet); delete p.components['sme.contents.theft'];
  const r = assess(BUILDERS.sme(), {parameterSet: p});
  assert.equal(comp(r, 'sme.contents.theft').status, 'model_unavailable'); assert.equal(r.risk.totals.incomplete, true);
  assert.ok(r.risk.totals.components_not_in_totals.some(x => x.key === 'sme.contents.theft'));
});

// ---------- other referral conditions ----------
test('disputed ownership and missing policy wording are referred', () => {
  const i = BUILDERS.home_contents(); i.subject.ownership.status = 'disputed'; i.policy_terms.wording_ref = null;
  const c = codes(run(i)); assert.ok(c.includes('identity_or_ownership_not_established') && c.includes('policy_terms_ambiguous'));
});
test('home: a lot owner or tenant cannot carry building cover without referral', () => {
  const i = BUILDERS.home_contents(); i.subject.ownership.scope = 'contents_only_lot_owner';
  assert.ok(codes(run(i)).includes('coverage_inconsistent_with_ownership_scope'));
  i.policy_terms.coverages = i.policy_terms.coverages.filter(c => c.coverage === 'contents');
  assert.ok(!codes(run(i)).includes('coverage_inconsistent_with_ownership_scope'));
});
test('hazard class without provenance prompts an information request', () => {
  const i = BUILDERS.sme(); delete i.subject.profile_provenance;
  assert.ok(run(i).recommendation.information_requests.some(x => x.item === 'profile_provenance.exposure.flood_hazard_class'));
});

// ---------- v0.1 migration ----------
test('v0.1 input migrates to an SME buildings fire assessment with unknowns kept explicit', () => {
  const v01 = {as_of: '2026-10-23T12:00:00Z', evidence: [], asset: {asset_id: 'AU-WAREHOUSE-001', currency: 'AUD', sum_insured_aud: 1000000,
    cope: {construction: {primary_material: 'steel'}, occupancy: {primary_use: 'warehouse'}, protection: {declared_controls: {sprinkler_system: true, smoke_detection: true, electrical_inspection: null}}, exposure: {external_fire_hazard: 'moderate'}}}};
  assert.throws(() => dr2.fromV01(v01), /periodStart/);
  const r = assess(dr2.fromV01(v01, {periodStart: '2026-10-23T12:00:00Z', periodEnd: '2027-10-23T12:00:00Z'}), {parameterSet});
  const fire = comp(r, 'sme.buildings.fire');
  assert.equal(fire.status, 'computed_bounds_only', 'eps_panel was never captured in v0.1, so it is unknown');
  close(fire.reference_class.loss_event_frequency, 0.015); close(fire.reference_class.conditional_mean_ground_up_severity, 200000); // the v0.1 reference point
  assert.equal(comp(r, 'sme.buildings.storm').status, 'excluded_by_policy_terms'); assert.equal(r.status, 'requires_human_review');
});
