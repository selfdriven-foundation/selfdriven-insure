# selfdriven.insure — DR² Reference Implementation v0.1

**Dynamic Risk & Resilience (DR²)** reference implementation for commercial property.

> **RESEARCH ONLY — NOT AN INSURANCE PRICING, BINDING, RISK ACCEPTANCE OR CLAIMS DECISION SYSTEM.**
> All hazard coefficients and mitigation factors are deliberately synthetic. The tool is an executable software prototype, **not** an actuarially validated model. A signed assertion establishes who signed it, not that the asserted control exists or functions correctly.

## What works

- COPE (Construction, Occupancy, Protection, Exposure) property schema.
- Validated AUD property insurance inputs with explicit assessment time.
- Single **fire / property damage** frequency × conditional-severity model.
- Three control assertions: operational sprinklers, operational smoke detection, and current electrical inspection.
- Evidence digest and **Ed25519** signature checks using a separately configured trust registry.
- Verification policies for accepted issuer methods, temporal validity and conflicting records.
- Separation of COPE declarations, signed attestation, eligibility for risk reduction, evidence completeness and assessed losses.
- Deterministic output hashes, pinned model manifest and registry-input fingerprints.
- Node CLI and loopback-only development HTTP service.
- **67 automated tests** at package creation time (rerun `npm test`).

## Requirements

Node.js **20+**. No npm packages or external runtime dependencies.

## Run now

```bash
cd selfdriven-insure-dr2-v0.1
npm test
npm run demo
node src/cli.js assess examples/assessment-unsigned.json
npm run server
```

The unsigned example intentionally receives **zero control credit** even though its COPE profile declares a sprinkler system and smoke detection. The demonstration generates a **new ephemeral synthetic Ed25519 keypair** and signs three mock inspection assertions in memory to show the verification flow; it does not ship real inspection credentials.

Request the development service:

```bash
curl -s http://127.0.0.1:8765/health
curl -s http://127.0.0.1:8765/v1/models/fire/manifest
curl -s -X POST http://127.0.0.1:8765/v1/assessments \
  -H 'content-type: application/json' \
  --data-binary @examples/assessment-unsigned.json
```

**Security:** this development server has no authentication, no persistence, no rate limiting and is bound to 127.0.0.1 only. Do not expose it on a network or use it for real customer data. Do not provide an issuer trust registry over the HTTP request body; it must be configured by the deployment operator using `DR2_TRUST_REGISTRY_FILE`.

## Conceptual assessment pipeline

```text
Risk object with COPE declarations
    |
    +-----------> Synthetic COE fire-frequency and severity factors
    |
Evidence records ---> Digest check ---> Ed25519 signature check
    |                                    + issuer policy / freshness / conflicts
    +-----------> Eligible operational controls (or unknown/disputed)
                           |
Reference fire risk ------> Verified mitigation calculation
                           |
              Residual expected annual loss
                           |
      Evidence coverage, warnings, model digest, result hash
```

**COPE P** is retained as declared protection characteristics. Protection affects the fire model **only** through eligible operational control attestations. This prevents an unverified declaration from being silently treated as an operationally effective control.

## Reference calculation

For a steel warehouse with moderate external fire hazard and $1,000,000 insured value:

- Reference annual claim probability: `0.015`.
- Reference conditional severity: `0.20 × sum_insured = AUD 200,000`.
- Reference EAL: `AUD 3,000`.
- With three trusted, non-conflicting, in-date synthetic attestations, apply:
  - Electrical inspection: frequency multiplier `0.80`.
  - Operational sprinklers: severity multiplier `0.55`.
  - Operational smoke detection: severity multiplier `0.85`.
- Result: `AUD 3,000 × 0.80 × 0.55 × 0.85 = AUD 1,122`.

All these multipliers are invented for the **software test harness**. They should never be used as property insurance risk or pricing assumptions without appropriate actuarial evidence and sign-off.

`evidence_coverage.percentage` describes the fraction of the three control facts resolved by eligible evidence. It is **not** a probabilistic confidence, credit rating or guarantee of safety.

## What has NOT been built

A calibrated risk score, risk trajectory, insurability rating, actuarial uncertainty estimates, catastrophe dependencies, business interruption, risk aggregation, binding, pricing, premiums, reinsurance, claims, multi-tenant security, durable evidence storage, identity credential issuance, revocation, secure time-stamping and governance approval workflows.

These intentionally remain absent or `null`, rather than presenting fictional precision.

## Directory structure

```text
src/
  index.js           library entry point
  validate.js        strict schema-oriented input checks
  canonical.js       sorted-JSON canonical encoding, digest/signature operations
  evidence.js        issuer checks, expiry, conflict resolution, control states
  model-fire.js      synthetic fire model and immutable manifest
  assess.js          deterministic assessment pipeline and replay test
  cli.js             developer CLI
  server.js          loopback-only HTTP service
schemas/
  asset.schema.json
  evidence.schema.json
  assessment-input.schema.json
examples/
  asset-warehouse.json
  assessment-unsigned.json
scripts/
  demo.js            synthetic runtime signer / verification walkthrough
test/
  engine.test.js

docs/
  REFERENCE-SPEC.md
  VALIDATION-PLAN.md
  SECURITY-AND-LIMITATIONS.md
  test-run.txt
```

## Next engineering steps

1. Agree the property/asset/peril/coverage ontology with partner underwriters.
2. Design approved issuer identity, inspection accreditation, attestation validity and revocation policies.
3. Replace synthetic peril and control factors with appropriately trained and validated loss models.
4. Establish a reproducible calibration dataset and temporal backtesting methodology.
5. Implement versioned persistence, controls on personal information, change approvals and a secure API gateway.
6. Run a shadow underwriting pilot before considering real-life customer-facing pricing or risk decisions.

See `docs/REFERENCE-SPEC.md` and `docs/VALIDATION-PLAN.md` for implementer and reviewer detail.
