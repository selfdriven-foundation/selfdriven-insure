#!/usr/bin/env node
'use strict';
// Loopback-only DEVELOPMENT server. No authentication, persistence, TLS or rate limiting.
// Trust policy and parameter set are operator configuration, never caller-supplied.
const http = require('node:http');
const fs = require('node:fs');
const {assess, modelManifest} = require('./engine');
const {LINES, catalog} = require('./lines');
const {ValidationError, validateTrustPolicy, EMPTY_TRUST_POLICY} = require('./validate');
const {validateParameterSet} = require('./params');
const {sha256} = require('./canonical');

const load = (env, check) => process.env[env] ? check(JSON.parse(fs.readFileSync(process.env[env], 'utf8'))) : null;
const trustPolicy = load('DR2_TRUST_POLICY_FILE', validateTrustPolicy) || EMPTY_TRUST_POLICY;
const parameterSet = load('DR2_PARAMETER_SET_FILE', validateParameterSet);
const send = (res, status, body) => { res.writeHead(status, {'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store'}); res.end(JSON.stringify(body)); };

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, {status: 'ok', mode: parameterSet ? parameterSet.status : 'model_unavailable', may_bind: false, may_set_premium: false});
  if (req.method === 'GET' && req.url === '/v1/catalog') return send(res, 200, catalog());
  const m = req.method === 'GET' && /^\/v1\/models\/([a-z_]+)\/manifest$/.exec(req.url);
  if (m) return Object.hasOwn(LINES, m[1])
    ? send(res, 200, {...modelManifest(m[1]), parameter_set: parameterSet ? {id: parameterSet.parameter_set_id, version: parameterSet.version, status: parameterSet.status, sha256: sha256(parameterSet)} : null})
    : send(res, 404, {error: 'unknown line'});
  if (req.method === 'POST' && req.url === '/v1/assessments') {
    if (!(req.headers['content-type'] || '').startsWith('application/json')) return send(res, 415, {error: 'content-type must be application/json'});
    let body = '', closed = false;
    req.on('data', chunk => { body += chunk; if (body.length > 262144 && !closed) { closed = true; send(res, 413, {error: 'request exceeds 256 KiB'}); req.destroy(); } });
    req.on('end', () => {
      if (closed) return;
      try { send(res, 200, assess(JSON.parse(body), {trustPolicy, parameterSet})); }
      catch (err) { send(res, err instanceof ValidationError ? 422 : 400, {error: err.message}); }
    });
    return;
  }
  send(res, 404, {error: 'not found'});
});
if (require.main === module) server.listen(Number(process.env.PORT || 8765), '127.0.0.1', () => console.log(`DR2 development server on http://127.0.0.1:${server.address().port}`));
module.exports = {server};
