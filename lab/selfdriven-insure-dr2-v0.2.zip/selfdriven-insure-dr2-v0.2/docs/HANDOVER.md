# DR² v0.2 — Implementation handover

20 November 2026

## What exists

A working, dependency-free Node.js engine that produces evidence-linked, reproducible risk
assessments for home & contents, strata, SME (buildings, contents, business interruption,
loss of profits), travel and cyber: 47 coverage/peril components over 24 shared event
models, with CLI, loopback development server, generated JSON Schemas, one example per
line, 54 passing tests and a bundle validator.

It meets the completion standard for a research prototype. It does not produce, and is not
fit to produce, a premium or an eligibility decision.

## Built from

`SKILL.md` v0.2.0 (invariants, workflow, stop conditions) and the v0.1 fire prototype.
The skill's `references/*.md`, `assets/`, `templates/`, `src/reference-math.mjs` and
`scripts/validate_bundle.py` were not in the supplied archive, which contained v0.1 only.
The line-specific design here follows the skill's invariants and v0.1's conventions; it has
not been checked against those reference files. Reconcile when they are available,
especially `LOB-*.md` vocabularies and `ARCHITECTURE-API.md`'s adapter contract.

## Design decisions worth reviewing

1. **Numbers live outside the engine.** One operator-supplied parameter set, validated and
   hashed. The shipped one is synthetic and labelled so in every result.
2. **Event, then coverage.** Frequency belongs to the (line, peril) event; each coverage has
   an involvement probability and its own severity. This keeps loss events separate from
   claim payments and makes shared cause explicit.
3. **Lognormal severity through policy terms.** Chosen so excess, sum insured, sublimits,
   waiting days and indemnity periods can be applied properly instead of to a mean. The
   family and CVs are assumptions.
4. **Unknown gives bounds, not a guess.** Point estimates disappear when an input is
   unknown or disputed.
5. **BI and loss of profits share one overlap group.** Both run on the same event and
   duration model and differ only in insured amount and valuation basis.
6. **Travel carries no age or health rating.** Deliberate, pending a lawful basis and data.
7. **Insurability is rule screening.** Thirteen placeholder rules stand in for an insurer's
   appetite.
8. **One control, one mechanism per peril.** Enforced when the parameter set loads.

## Known limitations

- All parameters synthetic. See `VALIDATION-REPORT.md` for blockers.
- Expected values only. No variance, tail, per-event aggregate limit, portfolio
  accumulation or catastrophe model. Cyber accumulation keys are emitted, not modelled.
- Factors are categorical and multiplicative. No interactions.
- Flat annual frequency; no seasonality. Travel cancellation ignores purchase date beyond
  the lead-time band.
- No liability covers, machinery breakdown, annual multi-trip travel or cyber extortion.
- Trajectory compares two snapshots under identical model, parameters and terms. It is not
  a forecast.
- Human overrides have a field in the result but no workflow.
- Canonical encoding is project-specific. Output is rounded; floating-point `exp`/`log`
  may differ across runtimes in the last digits.
- Development server has no authentication, TLS, persistence or rate limiting.
- Regulatory pointers in `GOVERNANCE.md` were not rechecked.

## Next actions

1. Reconcile with the skill's reference files and LOB vocabularies.
2. Agree the coverage/peril ontology and control list per line with a partner underwriter.
3. Obtain claims and exposure data for one line and one peril; fit and validate it out of
   time before widening. SME fire or home escape of liquid are the natural first cases.
4. Replace synthetic control effects with referenced effect models, one at a time.
5. Replace the placeholder insurability rules with the insurer's appetite rules.
6. Connect hazard class inputs to a governed hazard source with provenance.
7. Move evidence to KERI/ACDC credentials with issuer accreditation and revocation; adopt
   RFC 8785 or CESR-native digests with cross-language test vectors.
8. Add persistence, an append-only assessment log, authentication and tenant scoping.
9. Legal, privacy and fairness review before any pilot; shadow underwriting before any
   decision use.
