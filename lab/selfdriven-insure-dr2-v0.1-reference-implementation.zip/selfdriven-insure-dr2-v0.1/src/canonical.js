'use strict';
const {createHash, createPublicKey, sign, verify} = require('node:crypto');

// Restricted canonical encoding: JSON-compatible values only; sorted object keys.
// This is a project-specific canonicalisation convention, NOT RFC 8785 (JCS).
function canonical(value) {
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && Object.getPrototypeOf(value) === Object.prototype) {
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
  }
  throw new TypeError('Input must consist of JSON-compatible plain objects, arrays, finite numbers and literals');
}
const sha256 = value => createHash('sha256').update(canonical(value), 'utf8').digest('hex');
function payloadFromEvidence(evidence) {
  const {signature_b64, digest_sha256, ...payload} = evidence;
  return payload;
}
function signEvidence(unsignedEvidence, privateKey) {
  const payload = payloadFromEvidence(unsignedEvidence);
  const message = Buffer.from(canonical(payload), 'utf8');
  return {...payload, digest_sha256: sha256(payload), signature_b64: sign(null, message, privateKey).toString('base64')};
}
function checkEvidenceSignature(evidence, publicKeyPem) {
  const payload = payloadFromEvidence(evidence);
  const digestValid = evidence.digest_sha256 === sha256(payload);
  if (!digestValid) return {digest_valid:false, signature_valid:false};
  if (typeof evidence.signature_b64 !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(evidence.signature_b64))
    return {digest_valid:true, signature_valid:false};
  try {
    const signature = Buffer.from(evidence.signature_b64, 'base64');
    if (signature.length !== 64) return {digest_valid:true, signature_valid:false};
    const key = createPublicKey(publicKeyPem);
    if (key.asymmetricKeyType !== 'ed25519') return {digest_valid:true, signature_valid:false};
    return {digest_valid:true, signature_valid:verify(null, Buffer.from(canonical(payload),'utf8'), key, signature)};
  } catch (_err) {
    return {digest_valid:true, signature_valid:false};
  }
}
module.exports = {canonical, sha256, payloadFromEvidence, signEvidence, checkEvidenceSignature};
