'use strict';
const {checkEvidenceSignature} = require('./canonical');
const {controlNames} = require('./validate');

function verifyRecord(record, asOf, registry) {
  const issuer = Object.hasOwn(registry,record.issuer_id) ? registry[record.issuer_id] : undefined;
  if (!issuer) return {evidence_id:record.evidence_id, status:'untrusted_issuer'};
  const verified = checkEvidenceSignature(record,issuer.public_key_pem);
  if (!verified.digest_valid) return {evidence_id:record.evidence_id,status:'missing_or_invalid_digest'};
  if (!verified.signature_valid) return {evidence_id:record.evidence_id,status:'missing_or_invalid_signature'};
  if (!issuer.accepted_methods.includes(record.method)) return {evidence_id:record.evidence_id,status:'unaccepted_attestation_method'};
  if (Date.parse(record.observed_at)>Date.parse(asOf)) return {evidence_id:record.evidence_id,status:'future_observation'};
  if (Date.parse(record.valid_until)<=Date.parse(asOf)) return {evidence_id:record.evidence_id,status:'expired'};
  return {evidence_id:record.evidence_id,status:'verified_authentic_attestation'};
}

function evaluateControls(asset, records, asOf, registry) {
  const decisions=records.map(r=>verifyRecord(r,asOf,registry)).sort((a,b)=>a.evidence_id.localeCompare(b.evidence_id));
  const statuses=new Map(decisions.map(x=>[x.evidence_id,x.status]));
  const controls={};
  const issues=[];
  for (const name of controlNames) {
    const predicate=`control.${name}.operational`;
    const related=records.filter(r=>r.predicate===predicate);
    const eligible=related.filter(r=>statuses.get(r.evidence_id)==='verified_authentic_attestation');
    const values=new Set(eligible.map(r=>r.value));
    const declared=asset.cope.protection.declared_controls[name];
    let state='unknown';
    if (values.size>1) { state='disputed'; issues.push({control:name,code:'conflicting_verified_assertions'}); }
    else if (values.size===1) state=values.has(true)?'verified_true':'verified_false';
    if (state==='verified_true' && declared===false) {
      state='disputed'; issues.push({control:name,code:'verified_assertion_disagrees_with_cope_declaration'});
    } else if (state==='verified_false' && declared===true) {
      issues.push({control:name,code:'verified_assertion_disagrees_with_cope_declaration'});
    }
    controls[name]={state,evidence_ids:eligible.map(r=>r.evidence_id).sort(),declared,records_submitted:related.length};
  }
  const credited=controlNames.filter(c=>controls[c].state==='verified_true').length;
  return {
    records:decisions,
    controls,
    issues,
    evidence_coverage:{required_control_facts:controlNames.length,eligible_true_controls:credited,
      resolved_control_facts:controlNames.filter(c=>['verified_true','verified_false'].includes(controls[c].state)).length,
      // Coverage is a documentation metric, not a probabilistic confidence or risk score.
      percentage:100*controlNames.filter(c=>['verified_true','verified_false'].includes(controls[c].state)).length/controlNames.length}
  };
}
module.exports={verifyRecord,evaluateControls};
