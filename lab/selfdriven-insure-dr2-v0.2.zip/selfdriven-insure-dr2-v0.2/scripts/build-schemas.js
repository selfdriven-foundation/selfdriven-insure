#!/usr/bin/env node
'use strict';
// Generates assets/schemas/*.schema.json and assets/catalogs/lob-catalog.json from the line
// specifications in src/lines, so the schemas cannot drift from the runtime validators.
// JSON Schema 2020-12 contracts. Not a complete insurer policy ontology.
const fs = require('node:fs');
const path = require('node:path');
const {LINES, catalog} = require('../src/lines');
const {DECISION_USES, ROLES, AU_STATES, METHODS, CREDITABLE_METHODS, DEP_KINDS, NA} = require('../src/validate');

const ID = 'https://selfdriven.insure/schema/dr2/0.2/';
const S = (name, title, body) => ({$schema: 'https://json-schema.org/draft/2020-12/schema', $id: ID + name, title, ...body});
const O = (properties, required = Object.keys(properties)) => ({type: 'object', additionalProperties: false, required, properties});
const str = {type: 'string', minLength: 1, maxLength: 512}, strN = {type: ['string', 'null'], minLength: 1, maxLength: 512};
const time = {type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d{1,3})?Z$'};
const money = (min = 0) => ({type: 'number', minimum: min, maximum: 1e12});
const sha = {type: 'string', pattern: '^[a-f0-9]{64}$'};

function factorSchema(f) {
  if (f.type === 'int') return {type: ['integer', 'null'], minimum: f.min, maximum: f.max};
  return {enum: [...f.values, null, ...(f.na ? [NA] : [])]};
}
function subjectSchema(spec) {
  const groups = {};
  for (const [k, f] of Object.entries(spec.factors)) { const [g, a] = k.split('.'); (groups[g] ||= {})[a] = factorSchema(f); }
  const props = {
    subject_id: str, line: {const: spec.line},
    jurisdiction: O({country: {type: 'string', pattern: '^[A-Z]{2}$'}, state: {enum: [...AU_STATES, null]}}),
    ownership: O({scope: {enum: spec.ownership_scopes}, status: {enum: ['undisputed', 'disputed', 'unknown']}}),
    profile: O(Object.fromEntries(Object.entries(groups).map(([g, p]) => [g, O(p)]))),
    declared_controls: O(Object.fromEntries(spec.controls.map(c => [c, {enum: [true, false, null, NA]}]))),
    profile_provenance: {type: 'object', propertyNames: {enum: Object.keys(spec.factors)}, additionalProperties: O({source: str, as_at: time})}
  };
  const required = ['subject_id', 'line', 'jurisdiction', 'ownership', 'profile', 'declared_controls'];
  if (spec.dependencies) { props.dependencies = {type: 'array', maxItems: 200, items: O({dependency_id: str, kind: {enum: DEP_KINDS}, provider_ref: str, criticality: {enum: ['low', 'moderate', 'high']}})}; required.push('dependencies'); }
  if (spec.sensitive_block) {
    props.sensitive = {description: 'References only. Health or age detail must not be sent to this engine.', ...O({medical_screening_used: {type: 'boolean'}, consent_ref: strN, lawful_basis_ref: strN})};
    required.push('sensitive');
  }
  return O(props, required);
}
function coverageSchema(spec, coverage) {
  const kind = spec.coverages[coverage].exposure;
  const common = {coverage: {const: coverage}, excess: money(), excluded_perils: {type: 'array', items: {enum: spec.perils}},
    sublimits: {type: 'object', propertyNames: {enum: spec.perils}, additionalProperties: money()}};
  const limit = {type: ['number', 'null'], minimum: 0, maximum: 1e12, description: 'null = no monetary limit'};
  if (kind === 'sum_insured') return O({...common, sum_insured: money(1)});
  if (kind === 'limit') return O({...common, limit});
  return O({...common, excess: {const: 0}, insured_annual_amount: money(1), valuation_basis: {enum: spec.coverages[coverage].valuation_bases},
    indemnity_period_days: {type: 'number', minimum: 1, maximum: 1095}, waiting_days: {type: 'number', minimum: 0, maximum: 365}, limit});
}
function termsSchema(spec) {
  return O({
    version: str, wording_ref: strN, currency: {const: 'AUD'}, period: O({start: time, end: time}),
    coverages: {type: 'array', minItems: 1, maxItems: 20, items: {oneOf: Object.keys(spec.coverages).map(c => coverageSchema(spec, c))}},
    overlap_allocation: {type: 'array', items: O({group: str, rule: {const: 'primary'}, primary_coverage: {enum: Object.keys(spec.coverages)}})}
  }, ['version', 'wording_ref', 'currency', 'period', 'coverages']);
}
function evidenceSchema(spec) {
  const predicates = [...spec.controls.map(c => `control.${c}.operational`), ...Object.keys(spec.factors).map(k => `fact.${k}`)];
  return O({evidence_id: str, subject_id: str, predicate: predicates.length ? {enum: predicates} : false, value: {type: ['boolean', 'string', 'integer']},
    issuer_id: str, method: {enum: METHODS}, observed_at: time, valid_until: time, digest_sha256: sha, signature_b64: str},
  ['evidence_id', 'subject_id', 'predicate', 'value', 'issuer_id', 'method', 'observed_at', 'valid_until']);
}
const snapshot = O({assessment_id: str, as_of: time, comparability_sha256: sha, expected_claim_payment_total: {type: ['number', 'null'], minimum: 0}, evidence_resolved_share: {type: ['number', 'null'], minimum: 0, maximum: 1}});
const inputFor = spec => O({
  schema_version: {const: '0.2'}, as_of: time, decision_use: {enum: DECISION_USES}, requester_role: {enum: ROLES},
  subject: subjectSchema(spec), policy_terms: termsSchema(spec), evidence: {type: 'array', maxItems: 1000, items: evidenceSchema(spec)}, prior_snapshot: snapshot
}, ['schema_version', 'as_of', 'decision_use', 'requester_role', 'subject', 'policy_terms', 'evidence']);

const table = {type: 'object', additionalProperties: {type: 'number', exclusiveMinimum: 0, maximum: 100}};
const factorList = {type: 'array', items: O({factor: str, table})};
const controlList = targets => ({type: 'array', items: O({control: str, target: {enum: targets}, multiplier: {type: 'number', exclusiveMinimum: 0, maximum: 1}, effect_basis: str})});
const schemas = {
  'assessment-input.schema.json': S('assessment-input.schema.json', 'DR2 assessment input v0.2 (all lines)', {oneOf: Object.values(LINES).map(s => ({$ref: `#/$defs/${s.line}`})), $defs: Object.fromEntries(Object.values(LINES).map(s => [s.line, inputFor(s)]))}),
  'trust-policy.schema.json': S('trust-policy.schema.json', 'DR2 operator trust policy v0.2', O({
    policy_id: str, version: str,
    issuers: {type: 'object', additionalProperties: O({public_key_pem: {type: 'string', minLength: 1}, accepted_methods: {type: 'array', items: {enum: CREDITABLE_METHODS}},
      accepted_predicate_prefixes: {type: 'array', items: str}, valid_from: time, valid_until: {oneOf: [time, {type: 'null'}]}, revoked_at: {oneOf: [time, {type: 'null'}]}})},
    revoked_evidence_ids: {type: 'array', items: str}, max_evidence_age_days: {type: 'object', additionalProperties: {type: 'number', minimum: 1}}})),
  'parameter-set.schema.json': S('parameter-set.schema.json', 'DR2 parameter set v0.2', O({
    parameter_set_id: str, version: str, status: {enum: ['synthetic_fixture', 'calibrated']}, notice: {type: 'string'},
    approvals: {type: 'array', items: {type: 'object'}}, calibration: O({data_ref: strN, validation_report_ref: strN}),
    currency: {const: 'AUD'}, trajectory_tolerance: {type: 'number', exclusiveMinimum: 0, maximum: 1},
    events: {type: 'object', additionalProperties: O({unit: {enum: ['per_year', 'per_trip', 'per_trip_day']}, base_rate: {type: 'number', exclusiveMinimum: 0}, factors: factorList, controls: controlList(['frequency']), per_traveller: {type: 'boolean'}}, ['unit', 'base_rate', 'factors', 'controls'])},
    components: {type: 'object', additionalProperties: O({involvement_probability: {type: 'number', exclusiveMinimum: 0, maximum: 1},
      severity: O({basis: {enum: ['share_of_exposure', 'amount', 'duration_days']}, base: {type: 'number', exclusiveMinimum: 0}, cv: {type: 'number', exclusiveMinimum: 0}, factors: factorList}),
      controls: controlList(['conditional_severity', 'duration'])})},
    insurability_rules: {type: 'array', items: O({id: str, line: {enum: Object.keys(LINES)}, when: {type: 'object'}, outcome: {enum: ['refer', 'information_required']}, reason: str, rule_basis: str})}
  }, ['parameter_set_id', 'version', 'status', 'approvals', 'calibration', 'currency', 'trajectory_tolerance', 'events', 'components', 'insurability_rules'])),
  'assessment-result.schema.json': S('assessment-result.schema.json', 'DR2 assessment result v0.2 (top-level contract)', {
    type: 'object',
    required: ['assessment_schema_version', 'assessment_id', 'status', 'assessment_unit', 'model', 'reproducibility', 'risk', 'evidence', 'trajectory', 'insurability', 'recommendation', 'caveats', 'result_sha256'],
    properties: {
      assessment_schema_version: {const: '0.2'}, assessment_id: {type: 'string', pattern: '^dr2-[a-f0-9]{24}$'},
      status: {enum: ['model_unavailable', 'requires_human_review', 'research_only', 'assessed_for_underwriter_review']},
      risk: {type: 'object', required: ['currency', 'components', 'totals', 'shared_cause', 'overlap_groups'], properties: {components: {type: 'array', items: {type: 'object', required: ['key', 'coverage', 'peril', 'status', 'premium'],
        properties: {status: {enum: ['computed', 'computed_bounds_only', 'excluded_by_policy_terms', 'insufficient_data', 'model_unavailable']}, premium: {type: 'null'}}}}}},
      insurability: {type: 'object', required: ['status', 'triggers', 'decision'], properties: {status: {enum: ['not_assessed', 'no_constraint_triggered', 'information_required', 'refer']}, decision: {type: 'null'}}},
      recommendation: {type: 'object', required: ['action', 'referral_reasons', 'information_requests', 'may_bind', 'may_decline', 'may_vary_or_cancel', 'may_set_premium', 'premium', 'presentation_score'],
        properties: {may_bind: {const: false}, may_decline: {const: false}, may_vary_or_cancel: {const: false}, may_set_premium: {const: false}, premium: {type: 'null'}, presentation_score: {type: 'null'}}},
      result_sha256: sha
    }
  })
};
const root = path.join(__dirname, '..', 'assets');
for (const [name, schema] of Object.entries(schemas)) fs.writeFileSync(path.join(root, 'schemas', name), JSON.stringify(schema, null, 1) + '\n');
fs.writeFileSync(path.join(root, 'catalogs', 'lob-catalog.json'), JSON.stringify(catalog(), null, 1) + '\n');
console.log(`wrote ${Object.keys(schemas).length} schemas and lob-catalog.json`);
