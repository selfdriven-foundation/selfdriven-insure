'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
process.env.DR2_PARAMETER_SET_FILE = path.join(__dirname, '..', 'params', 'synthetic-fixture-v0.2.json');
const {server} = require('../src/server');
const body = fs.readFileSync(path.join(__dirname, '..', 'assets', 'examples', 'travel.input.json'), 'utf8');

async function withServer(fn) {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${server.address().port}`;
  try { await fn(url); } finally { await new Promise((resolve, reject) => server.close(err => err ? reject(err) : resolve())); }
}
const post = (url, b, type = 'application/json') => fetch(url + '/v1/assessments', {method: 'POST', headers: {'content-type': type}, body: b});

test('health reports mode and no authority', () => withServer(async url => {
  const j = await (await fetch(url + '/health')).json(); assert.equal(j.mode, 'synthetic_fixture'); assert.equal(j.may_bind, false);
}));
test('catalog and per-line manifest', () => withServer(async url => {
  assert.equal((await (await fetch(url + '/v1/catalog')).json()).lines.length, 5);
  const m = await (await fetch(url + '/v1/models/cyber/manifest')).json(); assert.match(m.manifest_sha256, /^[a-f0-9]{64}$/); assert.equal(m.parameter_set.status, 'synthetic_fixture');
  assert.equal((await fetch(url + '/v1/models/marine/manifest')).status, 404);
}));
test('POST assessment matches the shipped example result', () => withServer(async url => {
  const r = await post(url, body); assert.equal(r.status, 200);
  const shipped = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'assets', 'examples', 'travel.result.json'), 'utf8'));
  assert.equal((await r.json()).result_sha256, shipped.result_sha256);
}));
test('caller cannot supply trust policy or parameters; bad requests are rejected', () => withServer(async url => {
  const withPolicy = JSON.stringify({...JSON.parse(body), trust_policy: {}});
  assert.equal((await post(url, withPolicy)).status, 422);
  assert.equal((await post(url, '{}')).status, 422);
  assert.equal((await post(url, '{')).status, 400);
  assert.equal((await post(url, '{}', 'text/plain')).status, 415);
  assert.equal((await fetch(url + '/v1/unknown')).status, 404);
}));
