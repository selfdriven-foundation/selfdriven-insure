'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('../src/server');
const {readFileSync}=require('node:fs');
const {join}=require('node:path');
const input=readFileSync(join(__dirname,'../examples/assessment-unsigned.json'),'utf8');
async function withServer(fn) {
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const url=`http://127.0.0.1:${server.address().port}`;
  try {await fn(url)} finally {await new Promise((resolve,reject)=>server.close(err=>err?reject(err):resolve()));}
}
test('GET health returns research-only mode',async()=>withServer(async url=>{
  const r=await fetch(url+'/health');assert.equal(r.status,200);assert.equal((await r.json()).mode,'research_only');
}));
test('GET model manifest exposes synthetic status and hash',async()=>withServer(async url=>{
  const r=await fetch(url+'/v1/models/fire/manifest');assert.equal(r.status,200);const j=await r.json();assert.equal(j.status,'unvalidated_synthetic');assert.match(j.manifest_sha256,/^[0-9a-f]{64}$/);
}));
test('POST assessment returns exactly the known reference EAL',async()=>withServer(async url=>{
  const r=await fetch(url+'/v1/assessments',{method:'POST',headers:{'content-type':'application/json'},body:input});assert.equal(r.status,200);assert.equal((await r.json()).perils[0].residual.expected_annual_loss_aud,3000);
}));
test('POST invalid data rejects with validation code',async()=>withServer(async url=>{
  const r=await fetch(url+'/v1/assessments',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,422);
}));
test('POST non-JSON content type rejected',async()=>withServer(async url=>{
  const r=await fetch(url+'/v1/assessments',{method:'POST',headers:{'content-type':'text/plain'},body:'{}'});assert.equal(r.status,415);
}));
test('unknown API path rejected',async()=>withServer(async url=>{
  const r=await fetch(url+'/v1/unknown');assert.equal(r.status,404);
}));
