# Line module — Travel

## Canonical units
Subject = insured traveller/group, trip and itinerary legs, travel dates, destinations, pre-purchased costs, insured activities and selected covers. Exposure is normally **per trip, person-trip, leg or person-day**, never automatically per year. Recalculate when destinations and policy declarations change.

## Context profile (NOT COPE)
- Trip timing, length and seasonality; region, transit points and transport types.
- Prepaid non-refundable travel costs and booking conditions.
- Activities, equipment, baggage values, trip purpose and relevant declared facts.
- Assistance network, evacuation access and infrastructure disruption dependencies.
- Travel advisories, weather and event information with source and as-of date.

## Coverage/peril matrix
| Coverage | Candidate event | Unit |
|---|---|---|
| Cancellation / curtailment | covered reason preventing/shortening trip | trip |
| Overseas medical / evacuation | covered illness, injury or emergency | person-day / trip |
| Baggage/personal effects | theft, damage, loss | trip / item-event |
| Travel delay / missed connection | covered transport disruption | leg / trip |
| Rental car excess | insured rental damage subject to policy | rental period |
| Personal liability | covered third-party event | trip |

## Medical and personal data
Health declarations may be sensitive information subject to consent, access and legal limitations. Do not infer disabilities, age proxies or medical status from telemetry or unrelated sources. An agent must not make medical eligibility/cover decisions. Pre-existing condition terms are product-specific and require an authorised human/policy workflow.

## Important dependencies
Travel advisory change may matter for covered claim triggers only according to booking, purchase, departure and event dates. Weather disruptions may affect many legs in the same event. Cancellation and curtailment are not necessarily additive for the same trip cost. Medical, evacuation and disruption expenses may overlap with assistance benefits; use explicit allocation.

## Tests
1. 3-day vs 30-day trip: correct exposure units and non-linear risk where applicable.
2. Advisory issued after policy purchase: evaluate purchase/booking/known-event dates per contract.
3. One airline disruption affects three legs: one causal event, separate policy effects without double-counting.
4. Cancellation with full airline refund: apply claim/payment basis rather than original booking price.
5. Unverified destination or medical declaration: refer and preserve uncertainty; never assume safety.
6. Trip change mid-policy: preserve prior snapshot and reassess new itinerary.

## Calibration needs
Person-trip / person-day denominators, destination and season histories, covered cancellation causes, paid/incurred claims by cost category, assistance event data, supplier refunds, medical inflation, deductibles, policy exclusions and claims reporting delay. Assess bias introduced by destination/traveller mix.
