'use strict';
// Shared property hazard vocabularies. Hazard classes are INPUTS supplied by the
// insurer's own hazard mapping with provenance; this package ships no geographic data.
const HAZARD4 = ['low', 'moderate', 'high', 'extreme'];
const HAZARD3 = ['low', 'moderate', 'high'];
const WIND = ['non_cyclonic', 'intermediate', 'cyclonic', 'severe_cyclonic'];
const YEAR_BUILT = ['pre_1960', 'y1960_1989', 'y1990_2009', 'y2010_plus'];
const enumf = (values, extra = {}) => ({type: 'enum', values, ...extra});
const intf = (min, max, bands, extra = {}) => ({type: 'int', min, max, bands, ...extra});
module.exports = {HAZARD4, HAZARD3, WIND, YEAR_BUILT, enumf, intf};
