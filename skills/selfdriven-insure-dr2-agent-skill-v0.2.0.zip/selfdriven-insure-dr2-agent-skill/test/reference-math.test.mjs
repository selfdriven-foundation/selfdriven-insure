import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import {frequencySeverityExpectedLoss, illustrativeClaimPayment, applyApprovedControlEffect,
        stableJson, sha256Json, checkEd25519Signature, sumDistinctAllocations, noModelAvailable} from '../src/reference-math.mjs';

test('expected loss uses matching claim frequency and mean severity',()=> {
 assert.equal(frequencySeverityExpectedLoss(0.02,100000),2000);
 assert.equal(frequencySeverityExpectedLoss(0,100000),0);
});
test('invalid frequencies and severities fail closed',()=> {
 for(const x of [-1,NaN,Infinity,'0.2',null]) assert.throws(()=>frequencySeverityExpectedLoss(x,1000));
 assert.throws(()=>frequencySeverityExpectedLoss(0.1,-1));
});
test('claim-level excess and limit, not annual EAL',()=> {
 assert.equal(illustrativeClaimPayment(100,200,1000),0);
 assert.equal(illustrativeClaimPayment(1000,200,300),300);
 assert.equal(illustrativeClaimPayment(150,50,200),100);
});
test('approved effect is opt-in with bounded effect',()=> {
 assert.equal(applyApprovedControlEffect(1000,0.25,true),750);
 assert.throws(()=>applyApprovedControlEffect(1000,0.25,false));
 for (const v of [-0.1,1.01,NaN]) assert.throws(()=>applyApprovedControlEffect(1000,v,true));
});
test('stable JSON order and equal digest for same values',()=> {
 assert.equal(stableJson({b:2,a:{y:1,x:0}}),stableJson({a:{x:0,y:1},b:2}));
 assert.equal(sha256Json({b:2,a:1}),sha256Json({a:1,b:2}));
 assert.notEqual(sha256Json({a:1}),sha256Json({a:2}));
});
test('unsupported JSON values are not silently encoded',()=> {
 assert.throws(()=>stableJson({x:undefined}));
 assert.throws(()=>stableJson({x:Infinity}));
});
test('trusted ED25519 signature validates bytes, tampering fails',()=> {
 const {publicKey,privateKey}=generateKeyPairSync('ed25519');
 const bytes=Buffer.from('research demo\n');
 const sig=sign(null,bytes,privateKey).toString('base64');
 const pem=publicKey.export({format:'pem',type:'spki'}).toString();
 assert.equal(checkEd25519Signature(bytes,sig,pem),true);
 assert.equal(checkEd25519Signature(Buffer.from('modified'),sig,pem),false);
 assert.equal(checkEd25519Signature(bytes,'invalid',pem),false);
});
test('no trust key means no verified status',()=> {
 assert.equal(checkEd25519Signature(Buffer.from('abc'),'abc',null),false);
});
test('economic loss may not be double counted',()=> {
 assert.equal(sumDistinctAllocations([{economicLossId:'building-1',amount:200},{economicLossId:'contents-1',amount:100}]),300);
 assert.throws(()=>sumDistinctAllocations([{economicLossId:'BI-profit-1',amount:100},{economicLossId:'BI-profit-1',amount:100}]));
});
test('model unavailable is not represented as a zero loss',()=> {
 const result=noModelAvailable({coverage_id:'medical',peril_id:'covered_illness_or_injury',exposure_unit:'trip'});
 assert.equal(result.model_status,'model_unavailable');
 assert.equal(result.expected_loss,null);
 assert.throws(()=>noModelAvailable({coverage_id:'medical'}));
});
