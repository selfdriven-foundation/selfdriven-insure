# DR² v0.1 — Requirements Traceability

This table describes verifiable requirements for the v0.1 research MVP. The automated test cases can be located by searching their descriptive names in `test/engine.test.js` and `test/server.test.js`.

| ID | Requirement | Implementation | Acceptance evidence |
|---|---|---|---|
| R-01 | Represent COPE groups explicitly | `schemas/asset.schema.json`, `src/validate.js` | Schema checks and invalid-class tests |
| R-02 | Distinguish missing protection from false | `declared_controls` and `src/evidence.js` | Unknown controls; null declaration tests |
| R-03 | Support peril-specific fire EAL | `src/model-fire.js` | Baseline and COPE multiplier tests |
| R-04 | Separate frequency and severity controls | `src/model-fire.js` | Individual control effect tests |
| R-05 | Require authenticated evidence for credit | `src/canonical.js`, `src/evidence.js` | Signed vs unsigned tests |
| R-06 | Enforce issuer/method trust policy | `src/evidence.js` | Untrusted issuer and method tests |
| R-07 | Reject stale/future evidence | `src/evidence.js` | Expiry and future observation tests |
| R-08 | Flag inconsistent assertions | `src/evidence.js` | Contradictory verified attestations |
| R-09 | Prevent unvalidated pricing decisions | `src/assess.js` | Null premium and underwriting status |
| R-10 | Preserve model and registry fingerprints | `src/assess.js`, `src/model-fire.js` | Manifest and registry hash tests |
| R-11 | Support deterministic replay | `src/canonical.js`, `src/assess.js` | Replay match/tampering tests |
| R-12 | Expose development API | `src/server.js` | API health, manifest, assessment, 4xx tests |
| R-13 | Strictly validate input classes and dates | `src/validate.js` | Type, unknown field and malformed dates |
| R-14 | Supply reproducible synthetic worked example | `scripts/demo.js` | Three controls AUD 1,122 and replay true |

## Definition of done

- All tests pass on Node 20+ without downloading dependencies.
- Baseline reference result is AUD 3,000 EAL for the supplied asset.
- The mock signed three-control scenario produces AUD 1,122 EAL.
- Untrusted, expired, forged or disputed controls receive no risk reduction.
- No insurance premium or customer risk grade is returned.
- A third party can reproduce the source calculations from `REFERENCE-SPEC.md`.

## Exclusions

Actuarial correctness, real-world attester identity, operational security, deployed multi-tenant authorization, historical pricing calibration, model governance approval and customer suitability are **not** certified by passing these tests.
